"""Phase B5.2 — B->C mastery adapter (SPEC §A.10/§C, schema v2.1).

Builds the narrow B->C edge payload: exactly the seven ``mastery_<skill>`` estimate fields
plus envelope/identity metadata, nothing else. Certification, error-class distribution,
timing/RT, hints, BKT internals (``posterior_l``, ``P(G/S/T)``, ``plausibility_floor``),
sequencing/``selection_reason``, ``population``/``dd_subtype``, ``curriculum_node_id``, and
hidden truth are all forbidden on this edge (they are valid, where applicable, only on the
wider B->3 edge built in B5.3). This module builds no B->3 adapter and no per-edge
serialization/allow-list enforcement layer (that is B5.4) — it reuses the existing
``BToCMasteryPayload`` contract model and ``validators.contract_validators.validate_payload``
(which already rejects the B->C-prohibited field set) rather than re-implementing either.

Session/enrollment semantics (one B-session's worth of mastery, mapped to one intervention
session):

- **Combined** (both B and C enrolled/present for the intervention session): the B->C mastery
  snapshot is emitted.
- **B-only** (B present, C absent): no C payload is emitted — there is no C side to receive it.
- **C-only** (B absent, C present): B emits nothing and caches nothing; the estimates are not
  read, transformed, or held onto for a later emission.

Mastery values are the B3 *estimate* (``SkillMasteryUpdate.mastery_after`` /
``BBKTSkillState.p_l``) — never the hidden simulation truth, which this module never reads.
"""

from __future__ import annotations

from datetime import datetime
from typing import Mapping, Optional

from models.contracts import SKILLS, BToCMasteryPayload
from validators.contract_validators import validate_payload


def build_b_to_c_payload(
    student_id: str,
    intervention_session_id: str,
    intervention_session_number: int,
    skill_mastery_estimates: Mapping[str, float],
    *,
    b_present: bool,
    c_present: bool,
    production_timestamp: Optional[datetime] = None,
) -> Optional[BToCMasteryPayload]:
    """Build the B->C mastery payload for one intervention session, or ``None`` when the
    session/enrollment semantics mean no payload is emitted (B-only or C-only).

    ``skill_mastery_estimates`` must map every skill in ``SKILLS`` to its current B3 mastery
    *estimate*; no partial/derived computation happens here. Pure and deterministic: no seed,
    no mutation of ``skill_mastery_estimates``, no caching of any kind.
    """
    if not (b_present and c_present):
        # B-only: no C side to receive it. C-only: B has nothing to emit or cache.
        return None

    missing = set(SKILLS) - set(skill_mastery_estimates)
    if missing:
        raise ValueError(f"skill_mastery_estimates missing skills: {sorted(missing)}")

    payload = {
        "schema_version": "2.1",
        "student_id": student_id,
        "intervention_session_id": intervention_session_id,
        "intervention_session_number": intervention_session_number,
        "component_source": "B",
        "production_timestamp": production_timestamp,
        **{f"mastery_{skill}": skill_mastery_estimates[skill] for skill in SKILLS},
    }
    return validate_payload(payload, "b_to_c")
