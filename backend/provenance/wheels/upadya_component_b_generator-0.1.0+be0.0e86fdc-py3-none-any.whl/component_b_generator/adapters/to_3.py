"""Phase B5.3 — B->3 adapter (SPEC §A.10/§C, schema v2.1).

Builds the wider B->3 edge payload: the seven ``mastery_<skill>`` estimates, the nested
``mastery_certified``/``mastery_slope_w4``/``opportunities_w4`` per-skill roll-ups,
``error_class_dist``, ``guess_guard_triggered``, session totals, first-attempt accuracy, RT
stats, ``hint_requests``, and ``selection_reason`` — the B->3 allow-list, and nothing beyond
it. Unlike the narrow B->C edge (B5.2), certification, guard, and timing detail ARE valid here.

RT timing fields are nullable (SPEC §I0, resolved): an attended session whose every first
attempt is a timeout has no valid RT observation (B5.1's ``_response_time_stats`` correctly
returns ``None`` for all three), and this adapter passes that ``None`` straight through
(``_sec_or_none``) rather than dividing it — the row is still emitted, with mastery/accuracy/
error/hint data intact; only the timing fields go null.

``b_answer_changes`` is B-internal only (B-Q11) and is never read or exported by this module.
Cross-edge-forbidden fields — ``population``, ``dd_subtype``, hidden truth, BKT internals
(``posterior_l``, ``P(G/S/T)``, ``plausibility_floor``), ``curriculum_node_id`` — are never
read here either. This module reuses the existing ``BToComponent3Payload`` contract model and
``validators.contract_validators.validate_payload`` (which already enforces
``B_TO_3_PROHIBITED_FIELDS``/``COMMON_PROHIBITED_FIELDS``) rather than reimplementing
validation, and it adds no per-edge serialization/allow-list-enforcement module (that is B5.4).

Inputs are B5.1 aggregates (``SessionSummary`` / ``SessionAggregateStats`` /
``SkillSessionRollup``), B3 certification (already decided per skill on each
``SkillSessionRollup.certified``) and Guess-Guard status (``bkt.guess_guard.GuessGuardStatus``,
externally supplied per skill), and a B4 ``selection_reason`` category (externally supplied —
this module performs no selection/categorization of its own).

Slope semantics (``mastery_slope_w4_<skill>``, nested under ``mastery_slope_w4``): null until at
least 4 chronological mastery observations exist for that skill; computed fresh from whatever
history is supplied on each call (an OLS slope over the last 4 observations), so there is no
carry-forward — a skill whose available history later drops below 4 observations reports null
again on the next call, never a stale prior value.

**Mastery-slope fail-soft export policy (release-hardening).** The raw w4 OLS slope
(:func:`_w4_slope`) is left **completely unchanged** — it always computes the true, unclipped
value from whatever history it is given, and remains available internally for anything that needs
the real number (e.g. future audit/diagnostic use). Separately, ``models.contracts.Slope`` bounds
the *exported* field to ``[-0.2, 0.2]``: a real BKT cold-start property (a skill's first practice
session can move its estimate far enough from its ``P(L0)`` prior in one session that a 4-point
w4-window slope exceeds that bound) can make the raw value fall outside it. Previously this made
:func:`build_b_to_3_payload` raise (``pydantic.ValidationError``) and crash the pipeline. The
*exported* ``mastery_slope_w4_<skill>`` field now uses :func:`_exportable_w4_slope`: below 4
observations, or whenever the raw slope would violate the contract bound, it exports ``None`` —
never clipped to the boundary, never raised, never fabricated. This matches the exact "null is the
honest value" pattern :func:`_sec_or_none` already uses for RT fields in this same adapter. The
contract's ``[-0.2, 0.2]`` bound is **not** relaxed, and no BKT parameter is adjusted to avoid this
— out-of-bound evidence is reported as absent (``None``), not hidden by changing the rule or the
science.
"""

from __future__ import annotations

from datetime import date
from typing import Literal, Mapping, Optional, Sequence

from models.contracts import ERROR_CLASSES, SKILLS
from component_b_generator.aggregation.session import SessionAggregateStats, SkillSessionRollup
from component_b_generator.bkt.guess_guard import GuessGuardStatus, guess_guard_triggered_count
from component_b_generator.models.opportunity import SessionSummary
from validators.contract_validators import validate_payload

SelectionReasonCategory = Literal[
    "mastery_gap", "prereq_gap", "spaced_review", "recommendation_override"
]

_ERROR_BEARING_CLASSES = tuple(c for c in ERROR_CLASSES if c != "correct")
_W4_WINDOW = 4
# Mirrors models.contracts.Slope's Field(ge=-0.2, le=0.2) -- the exported-field fail-soft bound.
_SLOPE_EXPORT_BOUND = 0.2


def _sec_or_none(value_ms: Optional[float]) -> Optional[float]:
    """Convert ms -> sec, or pass ``None`` through unchanged (SPEC §I0, resolved): an
    all-timeout attended session has no valid RT observation, and null is the honest value —
    never a fabricated number. The row is still emitted; only the timing fields go null."""
    return None if value_ms is None else value_ms / 1000.0


def _w4_slope(history: Sequence[float]) -> Optional[float]:
    """OLS slope over the last 4 chronological observations; ``None`` below 4 observations.
    Pure function of ``history`` — no persisted state, so no carry-forward is possible."""
    if len(history) < _W4_WINDOW:
        return None
    window = list(history[-_W4_WINDOW:])
    n = len(window)
    xs = list(range(n))
    mean_x = sum(xs) / n
    mean_y = sum(window) / n
    denominator = sum((x - mean_x) ** 2 for x in xs)
    if denominator == 0:
        return 0.0
    numerator = sum((x - mean_x) * (y - mean_y) for x, y in zip(xs, window))
    return numerator / denominator


def _exportable_w4_slope(history: Sequence[float]) -> Optional[float]:
    """The ``mastery_slope_w4_<skill>`` value as actually exported on the B->3 payload.

    Calls the unmodified :func:`_w4_slope` for the raw value, then applies the contract's
    ``[-0.2, 0.2]`` bound (``models.contracts.Slope``) as a fail-soft gate: ``None`` below 4
    observations (unchanged prior behaviour) OR whenever the raw slope falls outside the bound.
    Never clips the value into range and never raises -- an out-of-bound raw slope is real,
    honest evidence of a fast mastery change that this field's declared range cannot represent,
    so it is reported as absent rather than distorted or fabricated.
    """
    raw = _w4_slope(history)
    if raw is None:
        return None
    if raw < -_SLOPE_EXPORT_BOUND or raw > _SLOPE_EXPORT_BOUND:
        return None
    return raw


def _full_error_class_dist(
    total_opportunities: int,
    total_correct_first_attempt: int,
    error_bearing_fractions: Mapping[str, float],
) -> dict[str, float]:
    """Expand B5.1's error-bearing-only distribution (fractions among errors, summing to 1.0)
    into the full 8-class distribution the B->3 contract requires (fractions of ALL first
    attempts, including ``correct``, summing to 1.0). ``correct_fraction +
    (1 - correct_fraction) * sum(error_bearing_fractions) == 1.0`` by construction."""
    correct_fraction = total_correct_first_attempt / total_opportunities
    error_total_fraction = 1.0 - correct_fraction
    dist = {"correct": correct_fraction}
    for cls in _ERROR_BEARING_CLASSES:
        dist[cls] = error_total_fraction * error_bearing_fractions.get(cls, 0.0)
    return dist


def build_b_to_3_payload(
    summary: SessionSummary,
    stats: SessionAggregateStats,
    skill_rollups: Sequence[SkillSessionRollup],
    *,
    intervention_session_id: str,
    intervention_session_number: int,
    intervention_session_date: date,
    skill_mastery_history: Mapping[str, Sequence[float]],
    guard_statuses: Optional[Mapping[str, GuessGuardStatus]] = None,
    selection_reason: Optional[SelectionReasonCategory] = None,
):
    """Build the B->3 payload for one attended B-session. Pure and deterministic: no seed, no
    mutation of any input.

    ``skill_mastery_history`` must map every skill in ``SKILLS`` to its chronological B3
    mastery *estimates* (most recent last) — the current estimate is ``history[-1]``; the slope
    window and ``opportunities_w4`` are both derived from the same history, fresh on every call.
    ``guard_statuses`` (optional) drives ``guess_guard_triggered``; without it the field is
    ``None`` (honestly absent, not fabricated as zero). ``mastery_certified_<skill>`` is read
    from each ``SkillSessionRollup.certified``; a skill with no rollup this session or an
    undecided (``None``) certification reports ``False`` (no positive certification evidence),
    never ``True`` without one.
    """
    if summary.status != "attended":
        raise ValueError("build_b_to_3_payload requires an attended session (missed sessions have no rows)")

    missing = set(SKILLS) - set(skill_mastery_history)
    if missing:
        raise ValueError(f"skill_mastery_history missing skills: {sorted(missing)}")
    empty = [skill for skill in SKILLS if not skill_mastery_history[skill]]
    if empty:
        raise ValueError(f"skill_mastery_history has no observations for: {sorted(empty)}")

    rollup_by_skill = {r.skill_id: r for r in skill_rollups}

    mastery_certified = {
        skill: bool(rollup_by_skill[skill].certified) if skill in rollup_by_skill and rollup_by_skill[skill].certified is not None else False
        for skill in SKILLS
    }
    mastery_slope_w4 = {skill: _exportable_w4_slope(skill_mastery_history[skill]) for skill in SKILLS}
    opportunities_w4 = {
        skill: min(len(skill_mastery_history[skill]), _W4_WINDOW) for skill in SKILLS
    }

    guess_guard_triggered = (
        guess_guard_triggered_count(guard_statuses.values()) if guard_statuses is not None else None
    )

    error_class_dist = _full_error_class_dist(
        summary.total_opportunities,
        summary.total_correct_first_attempt,
        stats.error_class_distribution,
    )

    payload = {
        "schema_version": "2.1",
        "student_id": summary.student_id,
        "b_session_id": summary.session_id,
        "b_session_number": summary.b_session_index,
        "intervention_session_id": intervention_session_id,
        "intervention_session_number": intervention_session_number,
        "intervention_session_date": intervention_session_date,
        "component_source": "B",
        "total_questions": summary.total_opportunities,
        "correct_responses": summary.total_correct_first_attempt,
        "accuracy_rate": stats.first_attempt_accuracy,
        # DF-02 (models.contracts.BToComponent3Payload): hint_requests <= total_questions --
        # this counts opportunities that received >=1 hint, never the raw hint-event total
        # (SessionSummary.total_hints_requested), which can exceed total_questions when one
        # opportunity accumulates hints across multiple retry attempts.
        "hint_requests": stats.hint_bearing_opportunities,
        "b_mean_item_response_time_sec": _sec_or_none(stats.response_time_mean_ms),
        "b_median_item_response_time_sec": _sec_or_none(stats.response_time_median_ms),
        "b_item_response_time_std_sec": _sec_or_none(stats.response_time_std_ms),
        "mastery_certified": mastery_certified,
        "error_class_dist": error_class_dist,
        "mastery_slope_w4": mastery_slope_w4,
        "opportunities_w4": opportunities_w4,
        "guess_guard_triggered": guess_guard_triggered,
        "selection_reason": selection_reason,
        **{f"mastery_{skill}": skill_mastery_history[skill][-1] for skill in SKILLS},
    }
    return validate_payload(payload, "b_to_3")
