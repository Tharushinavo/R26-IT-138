"""Phase B5.4 — per-edge allow-listed serialization (SPEC §A.10).

The B->C/B->3 pipeline is: internal records -> edge-specific adapter (``to_c.py`` B5.2 /
``to_3.py`` B5.3) -> strict contract model (``extra="forbid"``) -> ``serialize_contract`` ->
edge allow-list check -> payload. This module is the last of those steps: it does not build
payloads (no new fields, no adapter logic) and it is not a bypass of the strict models — it is
an *additional*, fail-closed gate that only a key already vetted by the model can pass through.

Per SPEC §A.10 there is **no single universal forbidden-key rule**: enforcement is per-edge.
``B_TO_C_ALLOWED`` is the narrow set (exactly the seven ``mastery_<skill>`` fields plus the
B->C envelope) and ``B_TO_3_ALLOWED`` is the wider set (the same seven mastery fields plus the
B->3 envelope and the certification/guard/timing/error/selection data fields from B5.3). A key
valid on one edge (e.g. ``mastery_certified``, only meaningful on B->3) is rejected on the
other. The truly cross-edge-forbidden keys — ``population``, ``dd_subtype``, hidden truth, BKT
internals (``posterior_l``, ``P(G/S/T)``, ``plausibility_floor``), ``curriculum_node_id``,
``b_answer_changes`` — never appear in *either* allow-list, so they are denied on both edges by
construction, not by a separate blocklist check.

Both allow-lists are the positive complement of the existing prohibited-field sets in
``validators.contract_validators`` (``B_TO_C_PROHIBITED_FIELDS`` / ``B_TO_3_PROHIBITED_FIELDS`` /
``COMMON_PROHIBITED_FIELDS``) — asserted disjoint at import time below — rather than a second,
independently-maintained rule that could drift out of sync with the validators.

Serialization is deterministic: a fixed canonical key order per edge, no seed, no mutation of
the input model/mapping.
"""

from __future__ import annotations

from collections import OrderedDict
from typing import Any, Literal, Mapping, Union

from pydantic import BaseModel

from models.contracts import SKILLS, BToCMasteryPayload, BToComponent3Payload
from validators.contract_validators import (
    B_TO_3_PROHIBITED_FIELDS,
    B_TO_C_PROHIBITED_FIELDS,
    COMMON_PROHIBITED_FIELDS,
)

Edge = Literal["b_to_c", "b_to_3"]


class SerializationError(ValueError):
    """Raised when a payload cannot be serialized on the requested edge (fail-closed)."""


# --- canonical field order, per edge ---------------------------------------------------

_ENVELOPE_B_TO_C: tuple[str, ...] = (
    "schema_version",
    "student_id",
    "intervention_session_id",
    "intervention_session_number",
    "component_source",
    "production_timestamp",
)

_ENVELOPE_B_TO_3: tuple[str, ...] = (
    "schema_version",
    "student_id",
    "b_session_id",
    "b_session_number",
    "intervention_session_id",
    "intervention_session_number",
    "intervention_session_date",
    "component_source",
)

_MASTERY_KEYS: tuple[str, ...] = tuple(f"mastery_{skill}" for skill in SKILLS)

# Fields meaningful only on the wider B->3 edge (certification/guard/timing/error/selection) —
# forbidden on the narrow B->C edge (SPEC §F: certification/errors/timing/hints/sequencing all
# denied on B->C).
_B_TO_3_DATA_KEYS: tuple[str, ...] = (
    "total_questions",
    "correct_responses",
    "accuracy_rate",
    "hint_requests",
    "b_mean_item_response_time_sec",
    "b_median_item_response_time_sec",
    "b_item_response_time_std_sec",
    "mastery_certified",
    "error_class_dist",
    "mastery_slope_w4",
    "opportunities_w4",
    "guess_guard_triggered",
    "selection_reason",
)

B_TO_C_ALLOWED: tuple[str, ...] = _ENVELOPE_B_TO_C + _MASTERY_KEYS
B_TO_3_ALLOWED: tuple[str, ...] = _ENVELOPE_B_TO_3 + _MASTERY_KEYS + _B_TO_3_DATA_KEYS

# Sanity: the allow-lists are the positive complement of the existing prohibited-field sets —
# no key appears in both an allow-list and a prohibited set for the same (or the common) edge.
assert not (set(B_TO_C_ALLOWED) & B_TO_C_PROHIBITED_FIELDS)
assert not (set(B_TO_C_ALLOWED) & COMMON_PROHIBITED_FIELDS)
assert not (set(B_TO_3_ALLOWED) & B_TO_3_PROHIBITED_FIELDS)
assert not (set(B_TO_3_ALLOWED) & COMMON_PROHIBITED_FIELDS)

_CANONICAL_ORDER: dict[str, tuple[str, ...]] = {
    "b_to_c": B_TO_C_ALLOWED,
    "b_to_3": B_TO_3_ALLOWED,
}
_MODEL_TYPE: dict[str, type[BaseModel]] = {
    "b_to_c": BToCMasteryPayload,
    "b_to_3": BToComponent3Payload,
}


def serialize_contract(model: Union[BaseModel, Mapping[str, Any]], edge: str) -> "OrderedDict[str, Any]":
    """Serialize ``model`` (a strict contract model instance, or an equivalent mapping) into a
    canonically-ordered dict for ``edge``, enforcing that edge's allow-list.

    Fails closed: an unknown ``edge``, a key absent from the edge's allow-list, or a payload
    missing one of the edge's required keys all raise ``SerializationError`` rather than
    silently dropping or defaulting anything. Deterministic: same input -> same output, key
    order always matches the edge's canonical tuple.
    """
    if edge not in _CANONICAL_ORDER:
        raise SerializationError(f"unknown edge {edge!r}; must be one of {tuple(_CANONICAL_ORDER)}")

    expected_type = _MODEL_TYPE[edge]
    if isinstance(model, BaseModel) and not isinstance(model, expected_type):
        raise SerializationError(
            f"model type {type(model).__name__} does not match the {edge} contract model {expected_type.__name__}"
        )

    data = model.model_dump() if isinstance(model, BaseModel) else dict(model)

    allowed = _CANONICAL_ORDER[edge]
    allowed_set = set(allowed)

    extra_keys = set(data) - allowed_set
    if extra_keys:
        raise SerializationError(f"key(s) not on the {edge} allow-list: {sorted(extra_keys)}")

    missing_keys = allowed_set - set(data)
    if missing_keys:
        raise SerializationError(f"payload missing required {edge} key(s): {sorted(missing_keys)}")

    return OrderedDict((key, data[key]) for key in allowed)
