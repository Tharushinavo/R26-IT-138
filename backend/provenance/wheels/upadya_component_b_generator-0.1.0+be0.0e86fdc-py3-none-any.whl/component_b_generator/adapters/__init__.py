"""component_b_generator.adapters

Derive frozen B->C v2.1 and B->3 v2.1 payloads from internal canonical records (SPEC 6.11). Phase B4 — placeholder. Phase B1 emits no boundary payloads.
"""
