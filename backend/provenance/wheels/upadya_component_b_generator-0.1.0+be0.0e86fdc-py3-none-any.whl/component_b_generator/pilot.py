"""Phase B6.3 — PP1 pilot run + consolidated audit report (SPEC §12 step 7 / §16).

Runs the B6.0 multi-session pipeline over a PP1-sized pilot cohort (SPEC: "120-200 learners"),
then runs every audit SPEC §11 calls for ("Audits (leakage/fidelity/coverage) + contract
validation ... gate before any dataset run") and assembles one consolidated, machine-readable
report. This module performs no generation of its own — it only calls ``pipeline.run_pipeline``
and the three existing audit entry points and reports what they found.

**Scope note (this run is not the full dataset).** SPEC §12: "No dataset is generated until steps
1-7 pass on the PP1 cohort (120-200 learners) and the audits are green; a full 500-learner run
would be proposed separately." This module's default config additionally uses a reduced
``scheduled_session_count`` (well under the full 25) to keep a single pilot run's wall-clock cost
tractable — ``catalogue.loader.load_catalogue`` re-parses the catalogue file on every attempt-loop
call (no caching in the current, frozen B2B.3 code), so per-item cost dominates at scale. This is a
pre-existing performance characteristic of already-frozen code, not something this phase changes;
a full-depth/full-cohort run is a separate, later proposal, exactly as SPEC anticipates.

**All pilot-run parameters are explicit ``TEST_FIXTURE_ONLY``/``ENGINEERING_ASSUMPTION`` values,
not approved scientific defaults** (every underlying config's own no-defaults convention still
applies — see ``pipeline.PipelineConfig``). In particular, this pilot's BKT parameters use
low-diagnosticity ``P(G)``/``P(S)`` (see ``_pilot_bkt_config``) rather than the approved-but-
CALIBRATION_PENDING Component B Parameters values: real calibrated values may produce much larger
single-session mastery swings (a first-practice "cold start" jump from a skill's ``P(L0)`` prior),
which the mastery-slope fail-soft export policy (``adapters.to_3._exportable_w4_slope``) now
absorbs as a ``None`` export rather than a crash — see that module's docstring. This interaction is
a real, reproducible property of this generator, not a bug in this pilot script, and remains
flagged here for calibration owners to revisit once real BKT parameters are proposed.

**Provenance (release-hardening).** ``PilotReport`` records, best-effort, enough about *how* a
report was produced for a reader who only has the JSON file (not this repository) to judge what
it does and doesn't demonstrate: source commit / working-tree cleanliness (explicit, never
pretended), every sub-config's version + parameter-source-status tag, the catalogue version and
checksum, the Python interpreter and dependency versions, and an explicit list of known
limitations plus the mandatory disclosure string. Git/metadata lookups are best-effort and never
raise — a lookup failure degrades to an explicit ``"unknown"``/``None`` marker, never a crash.
"""

from __future__ import annotations

import json
import platform
import subprocess
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, Optional, Tuple

from models.contracts import SKILLS

from .audits.fidelity import FidelityAuditResult, run_fidelity_audit
from .audits.leakage import LeakageAuditResult, run_leakage_audit
from .audits.population_neutrality import scan_source_for_population_branching
from .bkt.config import BBKTConfig, SkillBKTParams
from .catalogue.loader import catalogue_file_checksum, load_catalogue
from .cohort.builder import build_cohort
from .config.loader import GeneratorConfig
from .generation.coverage import CoverageReport, build_coverage_report
from .models.behaviour import (
    BAttemptLoopConfig,
    BFirstAttemptBehaviourConfig,
    BoundedBetaSpec,
    BoundedNormalSpec,
    BTruthInitializationConfig,
    LognormalLatencySpec,
)
from .pipeline import PipelineConfig, run_pipeline
from .samplers.registry import supported_template_ids
from .seeds import SeedManager
from .sequencing.config import BSequencingConfig

PILOT_VERSION = "b6.3-1.2.0"
TEST_FIXTURE_ONLY = "TEST_FIXTURE_ONLY"

# SPEC §12: PP1 cohort lower/upper bound.
PP1_MIN_LEARNERS = 120
PP1_MAX_LEARNERS = 200

# ENGINEERING_ASSUMPTION (this module's own scope note above): reduced session depth to keep one
# pilot run's wall-clock cost tractable against uncached per-item catalogue reloads.
DEFAULT_PILOT_SESSION_COUNT = 6

# Mandatory disclosure (SF-024), carried into the release artifact itself so it travels with the
# report even when read independently of this repository.
DISCLOSURE = "Literature-informed synthetic data — not clinical evidence."

# Distribution names as declared in Implementation_v1.0/requirements.txt.
_DEPENDENCY_DISTRIBUTIONS: Tuple[str, ...] = (
    "pydantic", "PyYAML", "jsonschema", "pytest", "scikit-learn", "numpy", "pandas",
)

# PP1 leakage caveat (release-hardening follow-up): PP1 proves engineering plumbing only, NOT
# leakage safety under calibrated BKT dynamics. Kept as a named constant so the report, README, and
# build log cannot drift from one another and tests can assert its presence verbatim.
PP1_LEAKAGE_LIMITATION = (
    "PP1 validates pipeline wiring, audit execution, determinism, and contract integrity only. It "
    "does not establish leakage safety under calibrated BKT dynamics. The PP1 BKT configuration is "
    "TEST_FIXTURE_ONLY and deliberately low-diagnosticity. The SF-038 leakage-audit implementation "
    "is valid and the reported PP1 balanced accuracy passed its engineering gate, but that is not "
    "evidence that calibrated dynamics will remain leakage-safe; slope missingness must be "
    "re-audited once owner-reviewed BKT parameters are introduced."
)

# Frozen-hidden-truth caveat (release-hardening follow-up): the pipeline advances BKT ESTIMATES but
# never the hidden truth (fixed_hidden_growth_g is unapplied), so PP1 is not a longitudinal dataset.
FROZEN_HIDDEN_TRUTH_LIMITATION = (
    "Hidden learner truth is frozen across sessions in the current B6 pipeline. fixed_hidden_growth_g "
    "is not yet applied, so PP1 does not represent genuine longitudinal learning trajectories. BKT "
    "estimates can change, but hidden learner truth does not currently grow; PP1 is therefore a "
    "plumbing/audit milestone, not the final longitudinal dataset for Component 3 future-window "
    "modelling. Hidden-growth implementation and review must occur before a full calibrated dataset run."
)

KNOWN_LIMITATIONS: Tuple[str, ...] = (
    PP1_LEAKAGE_LIMITATION,
    FROZEN_HIDDEN_TRUTH_LIMITATION,
    "fixed_hidden_growth_g is not applied anywhere in the generator; hidden true mastery is "
    "frozen at its B2B.1 initial value for the whole pilot (documented scope boundary, see "
    "pipeline.py's module docstring).",
    "Session attendance is 100% by construction; the SF-040 shared calendar / attrition / "
    "missed-slot model is not implemented and is therefore not exercised by this pilot.",
    "PP1 BKT parameters are TEST_FIXTURE_ONLY and deliberately non-calibrated (see "
    "bkt_parameter_source_status below) -- not the approved Component B Parameters 21-row "
    "table, which remains CALIBRATION_PENDING.",
    "mastery_slope_w4 uses a fail-soft export policy: a raw w4 OLS slope outside the B->3 "
    "contract's [-0.2, 0.2] bound is exported as null rather than raised or clipped (see "
    "adapters/to_3.py: _exportable_w4_slope). The raw internal slope computation is unchanged.",
    "one_vs_rest_roc_auc may be null when it is not validly computable (a degenerate one-vs-rest "
    "split, e.g. a population label missing from the test split); this does not affect the "
    "binding SF-038 balanced-accuracy gate, computed independently.",
    "This is an engineering PP1 smoke pilot validating pipeline/audit plumbing, not a final "
    "research dataset; a full 500-learner / 25-session run is a separate, later proposal "
    "(SPEC Component_B_Generator_v1.0/SPEC.md §12).",
    "No clinical or empirical validity is claimed for any value in this report -- see the "
    "mandatory disclosure field.",
)

ATTENDANCE_MODEL_STATUS = (
    "100% B-session attendance assumed for every scheduled session (Phase B1's own documented "
    "assumption); the SF-040 shared 25-slot calendar / missed-slot / attrition model is not "
    "implemented and is not exercised by this pilot."
)

MASTERY_SLOPE_FAIL_SOFT_POLICY = (
    "mastery_slope_w4_<skill> is exported only when >=4 chronological mastery observations "
    "exist for that skill AND the raw w4 OLS slope falls within the B->3 contract's Slope bound "
    "[-0.2, 0.2] (models.contracts.Slope); otherwise null is exported. The raw slope is never "
    "clipped into range, the pipeline never raises on an out-of-bound raw slope, and the "
    "contract bound itself is not relaxed."
)


def _git_provenance(repo_root: Path) -> Tuple[Optional[str], bool, str]:
    """Best-effort git provenance: ``(commit_hash_or_None, working_tree_clean, note)``.

    Never raises: a missing git binary, a non-repository path, or any other lookup failure
    degrades to an explicit ``(None, False, "...unavailable...")`` marker rather than crashing
    report generation. Deliberately does not pretend a report is commit-reproducible when it
    cannot confirm that.
    """
    try:
        commit = subprocess.run(
            ["git", "rev-parse", "HEAD"], cwd=repo_root, capture_output=True, text=True,
            check=True, timeout=10,
        ).stdout.strip()
        status = subprocess.run(
            ["git", "status", "--porcelain"], cwd=repo_root, capture_output=True, text=True,
            check=True, timeout=10,
        ).stdout
        clean = len(status.strip()) == 0
        if clean:
            note = "working tree clean at generation time -- this run is commit-reproducible from source_commit."
        else:
            note = (
                "UNCOMMITTED CHANGES present at generation time -- this run is NOT "
                "commit-reproducible from source_commit alone; treat it as a working-tree "
                "snapshot, not a tagged/released state."
            )
        return commit, clean, note
    except Exception as exc:  # pragma: no cover -- best-effort provenance only, never fatal
        return None, False, f"git provenance unavailable ({type(exc).__name__}): {exc}"


def _dependency_versions() -> Dict[str, str]:
    """Best-effort installed-package versions for every distribution named in requirements.txt.
    A missing/unresolvable package reports ``"not installed"`` rather than raising."""
    try:
        import importlib.metadata as importlib_metadata
    except ImportError:  # pragma: no cover -- Python < 3.8 fallback, not expected here
        return {name: "unknown" for name in _DEPENDENCY_DISTRIBUTIONS}

    versions: Dict[str, str] = {}
    for name in _DEPENDENCY_DISTRIBUTIONS:
        try:
            versions[name] = importlib_metadata.version(name)
        except importlib_metadata.PackageNotFoundError:
            versions[name] = "not installed"
    return versions


def _pilot_bkt_config() -> BBKTConfig:
    """See module docstring: deliberately low-diagnosticity P(G)/P(S) so w4 mastery slopes stay
    within the B->3 contract's Slope bound at this pilot's session depth. NOT the approved
    Component B Parameters values (those remain CALIBRATION_PENDING)."""
    params = {
        skill: SkillBKTParams(p_l0=0.15, p_t=0.05, p_g=0.45, p_s=0.45) for skill in SKILLS
    }
    return BBKTConfig(
        skill_params=params,
        theta_B=0.95,
        floor_quantile=0.1,
        floor_min_obs=5,
        config_version="b6-3-pilot-bkt-1",
        parameter_source_status=TEST_FIXTURE_ONLY,
    )


def _beta(alpha=2.0, beta=2.0, lower=0.0, upper=1.0) -> BoundedBetaSpec:
    return BoundedBetaSpec(family="bounded_beta", alpha=alpha, beta=beta, lower=lower, upper=upper)


def default_pilot_config(
    n_learners: int = PP1_MIN_LEARNERS,
    scheduled_session_count: int = DEFAULT_PILOT_SESSION_COUNT,
    global_seed: int = 20260716,
) -> PipelineConfig:
    """Explicit, versioned pilot configuration. Every scientific value is ``TEST_FIXTURE_ONLY``
    (this pilot validates plumbing/audits, not calibrated scientific output)."""
    generator_config = GeneratorConfig(
        config_version="b6-3-pilot-1",
        global_seed=global_seed,
        n_learners=n_learners,
        scheduled_session_count=scheduled_session_count,
    )
    sequencing_config = BSequencingConfig(
        w_mastery_gap=0.50, w_prereq=0.30, w_spacing=0.20,
        config_version="b6-3-pilot-1", parameter_source_status=TEST_FIXTURE_ONLY,
    )
    truth_init_config = BTruthInitializationConfig(
        initialization_version="b6-3-pilot-1",
        parameter_source_status=TEST_FIXTURE_ONLY,
        initial_true_mastery=_beta(2, 5),
        behavioural_slip_tendency=_beta(2, 8),
        behavioural_guess_tendency=_beta(2, 8),
        careless_error_tendency=_beta(2, 8),
        help_seeking_tendency=_beta(),
        retry_persistence=_beta(),
        completion_persistence=_beta(),
        behaviour_consistency=_beta(6, 2),
        response_speed_tendency=BoundedNormalSpec(family="bounded_normal", mean=0.0, std=1.0, lower=-3.0, upper=3.0),
        response_speed_variability=BoundedNormalSpec(family="bounded_normal", mean=0.5, std=0.2, lower=0.0, upper=2.0),
        fixed_hidden_growth_g=0.008,
    )
    first_attempt_config = BFirstAttemptBehaviourConfig(
        config_version="b6-3-pilot-1",
        parameter_source_status=TEST_FIXTURE_ONLY,
        enable_typed_wrong_answers=True,
        latency=LognormalLatencySpec(
            family="lognormal", location_mu=6.5, scale_sigma=0.5,
            speed_tendency_weight=0.5, variability_weight=0.5,
            floor_ms=200, cap_ms=60000, timeout_threshold_ms=200000,
        ),
    )
    attempt_loop_config = BAttemptLoopConfig(
        config_version="b6-3-pilot-1",
        parameter_source_status=TEST_FIXTURE_ONLY,
        first_attempt_config=first_attempt_config,
        max_attempts=4,
        hint_request_base=0.2,
        hint_request_weight=0.5,
        retry_base=0.3,
        retry_persistence_weight=0.5,
        completion_persistence_weight=0.4,
        timeout_terminates_opportunity=False,
        avoid_repeat_wrong_answers=True,
        ruleset_version="b6-3-pilot-1.0.0",
    )
    return PipelineConfig(
        generator_config=generator_config,
        sequencing_config=sequencing_config,
        bkt_config=_pilot_bkt_config(),
        truth_init_config=truth_init_config,
        attempt_loop_config=attempt_loop_config,
        c_present=False,
    )


@dataclass(frozen=True)
class PilotReport:
    pilot_version: str
    generated_at_utc: str
    disclosure: str  # mandatory (SF-024): "Literature-informed synthetic data — not clinical evidence."

    # --- provenance: enough for a reader with ONLY this JSON to judge reproducibility ---
    source_commit: Optional[str]
    working_tree_clean: bool
    provenance_note: str
    python_version: str
    dependency_versions: Dict[str, str]
    global_seed: int
    config_versions: Dict[str, str]
    parameter_source_status: Dict[str, str]
    bkt_config_version: str
    bkt_parameter_source_status: str
    catalogue_version: str
    catalogue_checksum: str

    # --- scale / record counts ---
    n_learners: int
    scheduled_session_count: int
    n_sessions_generated: int
    total_item_opportunities: int
    total_attempts: int

    # --- audits (SPEC §11) ---
    sf_039_static_scan_clean: bool
    sf_039_offenders: tuple

    coverage_implemented_count: int
    coverage_deferred_count: int
    coverage_catalogue_count: int
    coverage_gate_passed: bool  # every non-implemented template has a recorded deferral decision

    leakage: LeakageAuditResult
    fidelity: FidelityAuditResult

    overall_passed: bool  # binding gate: SF-038 (leakage.passed) AND a clean SF-039 static scan

    # --- known limitations / documented policies ---
    known_limitations: Tuple[str, ...]
    attendance_model_status: str
    mastery_slope_fail_soft_policy: str


def run_pilot(config: Optional[PipelineConfig] = None) -> PilotReport:
    """Run the B6.0 pipeline over a pilot cohort and every SPEC §11 audit, then assemble one
    consolidated, self-describing report. The binding release gate is SF-038
    (``leakage.passed``); fidelity and coverage are reported alongside it, never substituted for
    it (SPEC §11)."""
    cfg = config or default_pilot_config()
    repo_root = Path(__file__).resolve().parents[2]

    catalogue = load_catalogue()
    catalogue_checksum = catalogue_file_checksum(catalogue.source_path)
    coverage = build_coverage_report(catalogue, supported_template_ids())

    sf_039_offenders = tuple(scan_source_for_population_branching())

    cohort = build_cohort(cfg.generator_config, SeedManager(cfg.generator_config.global_seed))
    results = run_pipeline(cohort, cfg)

    population_by_student = {m.identity.student_id: m.identity.population for m in cohort}
    leakage_rows = [
        (learner.student_id, population_by_student[learner.student_id], session.b_to_3_payload)
        for learner in results
        for session in learner.sessions
    ]
    fidelity_rows = [
        (session.aggregation, session.b_to_3_payload) for learner in results for session in learner.sessions
    ]

    leakage_result = run_leakage_audit(leakage_rows, random_seed=cfg.generator_config.global_seed)
    fidelity_result = run_fidelity_audit(fidelity_rows, floor_min_obs=cfg.bkt_config.floor_min_obs)

    source_commit, working_tree_clean, provenance_note = _git_provenance(repo_root)

    total_item_opportunities = sum(agg.summary.total_opportunities for agg, _ in fidelity_rows)
    total_attempts = sum(agg.summary.total_attempts for agg, _ in fidelity_rows)

    return PilotReport(
        pilot_version=PILOT_VERSION,
        generated_at_utc=datetime.now(timezone.utc).isoformat(),
        disclosure=DISCLOSURE,
        source_commit=source_commit,
        working_tree_clean=working_tree_clean,
        provenance_note=provenance_note,
        python_version=platform.python_version(),
        dependency_versions=_dependency_versions(),
        global_seed=cfg.generator_config.global_seed,
        config_versions={
            "generator": cfg.generator_config.config_version,
            "sequencing": cfg.sequencing_config.config_version,
            "truth_init": cfg.truth_init_config.initialization_version,
            "attempt_loop": cfg.attempt_loop_config.config_version,
            "bkt": cfg.bkt_config.config_version,
        },
        parameter_source_status={
            "sequencing": cfg.sequencing_config.parameter_source_status,
            "truth_init": cfg.truth_init_config.parameter_source_status,
            "attempt_loop": cfg.attempt_loop_config.parameter_source_status,
            "bkt": cfg.bkt_config.parameter_source_status,
        },
        bkt_config_version=cfg.bkt_config.config_version,
        bkt_parameter_source_status=cfg.bkt_config.parameter_source_status,
        catalogue_version=catalogue.catalogue_version,
        catalogue_checksum=catalogue_checksum,
        n_learners=cfg.generator_config.n_learners,
        scheduled_session_count=cfg.generator_config.scheduled_session_count,
        n_sessions_generated=len(fidelity_rows),
        total_item_opportunities=total_item_opportunities,
        total_attempts=total_attempts,
        sf_039_static_scan_clean=(len(sf_039_offenders) == 0),
        sf_039_offenders=sf_039_offenders,
        coverage_implemented_count=coverage.implemented_count,
        coverage_deferred_count=coverage.deferred_count,
        coverage_catalogue_count=coverage.catalogue_count,
        # build_coverage_report is fail-closed (raises ValueError on any uncovered/misclassified
        # template) -- reaching this line at all IS the coverage gate passing.
        coverage_gate_passed=True,
        leakage=leakage_result,
        fidelity=fidelity_result,
        overall_passed=leakage_result.passed and len(sf_039_offenders) == 0,
        known_limitations=KNOWN_LIMITATIONS,
        attendance_model_status=ATTENDANCE_MODEL_STATUS,
        mastery_slope_fail_soft_policy=MASTERY_SLOPE_FAIL_SOFT_POLICY,
    )


def write_pilot_report(report: PilotReport, output_dir: Optional[Path] = None) -> Path:
    """Write the pilot report as JSON under ``Implementation_v1.0/output/`` (git-ignored, SPEC
    §2). Returns the written path.

    Filename is ``b6_3_pilot_report_seed{global_seed}_n{n_learners}.json`` — it embeds the actual
    pilot ``global_seed`` and learner count, so two runs that differ only by seed no longer collide
    on one filename (the prior ``...seed{n_learners}...`` form mislabelled the learner count as the
    seed and let different-seed/same-cohort runs overwrite each other). Deterministic and
    timestamp-free: the same seed + learner count always yields the same filename.

    ``allow_nan=False`` makes strict-JSON validity a structural guarantee, not just an intent:
    ``json.dumps`` raises immediately if any float in the report is ``NaN``/``Infinity`` rather
    than silently emitting the non-strict-JSON bare tokens ``NaN``/``Infinity`` (release-hardening
    defense in depth alongside ``audits.leakage``'s own guarantee never to produce one).
    """
    out_dir = output_dir or (Path(__file__).resolve().parents[1] / "output")
    out_dir.mkdir(parents=True, exist_ok=True)
    path = out_dir / f"b6_3_pilot_report_seed{report.global_seed}_n{report.n_learners}.json"
    path.write_text(json.dumps(asdict(report), indent=2, default=str, allow_nan=False), encoding="utf-8")
    return path


if __name__ == "__main__":  # pragma: no cover
    report = run_pilot()
    path = write_pilot_report(report)
    print(f"[B6.3 pilot] learners={report.n_learners} sessions={report.n_sessions_generated} "
          f"leakage_balanced_accuracy={report.leakage.balanced_accuracy:.4f} "
          f"leakage_passed={report.leakage.passed} fidelity_passed={report.fidelity.passed} "
          f"overall_passed={report.overall_passed}")
    print(f"source_commit={report.source_commit} working_tree_clean={report.working_tree_clean}")
    print(f"  {report.provenance_note}")
    print(f"catalogue_version={report.catalogue_version} catalogue_checksum={report.catalogue_checksum[:12]}...")
    print(f"Report written to {path}")
