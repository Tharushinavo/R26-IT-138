"""component_b_generator.sequencing

Adaptive weighted-sum item sequencing (SPEC §6.8, B-022).

Phase B4.0 — contracts & config: ``BSequencingConfig`` (FROZEN, pinned weights
w_mastery_gap=0.50 / w_prereq=0.30 / w_spacing=0.20; deterministic, no seed) and
``SequencingCandidate`` (one eligible node/template candidate shape).

Phase B4.1 — eligibility: ``eligible_candidates`` (grade gate HARD + deferred fail-closed +
availability; prerequisites soft/deferred per B-Q4 -- not hard-excluded here).

Phase B4.2 — feature computation: ``compute_features`` / ``SequencingFeatures``
(mastery_gap, prerequisite_readiness, spacing_due; estimate-only, soft prerequisites).

Phase B4.3 — scoring & selection: ``score_candidate`` (FROZEN weighted sum, B-022),
``rank_candidates`` / ``select_target`` (canonical, seedless tie-break; B-internal
``SelectionReason``).

Phase B4.4 — two-stage task-instance integration: ``select_item_within_skill`` (Stage 2,
difficulty_band-ordered, in-skill only) + ``build_task_instance_via_sequencing`` (wires through
the existing, unmodified ``build_task_instance()``; additive -- Phase B1's own generation entry
point is untouched).
"""

from __future__ import annotations

from .config import B4_VERSION, W_MASTERY_GAP, W_PREREQ, W_SPACING, BSequencingConfig
from .eligibility import difficulty_band_for_template, eligible_candidates
from .features import SPACING_DUE_SATURATION_SESSIONS, SequencingFeatures, compute_features
from .models import SequencingCandidate
from .score import (
    ScoredCandidate,
    SelectionReason,
    SelectionResult,
    rank_candidates,
    score_candidate,
    select_target,
)
from .select_item import build_task_instance_via_sequencing, select_item_within_skill

__all__ = [
    "B4_VERSION",
    "W_MASTERY_GAP",
    "W_PREREQ",
    "W_SPACING",
    "BSequencingConfig",
    "SequencingCandidate",
    "eligible_candidates",
    "difficulty_band_for_template",
    "SequencingFeatures",
    "compute_features",
    "SPACING_DUE_SATURATION_SESSIONS",
    "score_candidate",
    "ScoredCandidate",
    "rank_candidates",
    "select_target",
    "SelectionResult",
    "SelectionReason",
    "select_item_within_skill",
    "build_task_instance_via_sequencing",
]
