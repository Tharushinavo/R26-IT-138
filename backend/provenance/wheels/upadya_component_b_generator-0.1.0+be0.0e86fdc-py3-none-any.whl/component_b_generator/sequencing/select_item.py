"""Two-stage task-instance integration (Phase B4.4).

**Stage 1** (B4.3 ``select_target``) scores candidates and picks the winning *skill* (via the
winning candidate's ``skill_id``) -- B4.1's ``eligible_candidates`` features/score are skill-level
signals (mastery_gap/prerequisite_readiness/spacing_due depend only on ``skill_id``), so several
same-skill candidates score identically; the B4.3 tie-break only picks an arbitrary template.

**Stage 2** (this module) re-selects the actual item *within* that winning skill, deterministically
ordered by the sequencing-only ``difficulty_band`` (then lexicographic ``item_template_id`` as the
canonical tie-break). ``difficulty_band`` is never a correctness parent: it is not read anywhere
on the canonical correctness path (``build_task_instance`` sources correctness only from
``correct_answer_rule``/the sampler -- ``template.difficulty_level`` there is metadata on the
built instance, never an input to answer/distractor/guard computation).

The selected template is instantiated through the existing, unmodified
:func:`generation.task_instances.build_task_instance` -- there is no parallel build path. The
sequencing rationale is recorded on :class:`models.opportunity.GeneratedItemOpportunity`'s
existing ``selection_reason_internal`` field (B-internal; B->3 export is a later slice, B5).

This wiring is purely additive: :mod:`generation.item_opportunities` (Phase B1's own
seeded-random selection) is untouched, so every existing non-sequencing generation entry point
keeps producing byte-identical output.
"""

from __future__ import annotations

from typing import Sequence

from ..generation.task_instances import build_task_instance
from ..models.catalogue import LoadedCatalogue
from ..models.opportunity import GeneratedItemOpportunity
from ..models.session import SeedLineage
from ..models.task_instance import GeneratedItemInstance
from .models import SequencingCandidate
from .score import SelectionReason


def select_item_within_skill(
    selected_skill: str, in_skill_candidates: Sequence[SequencingCandidate]
) -> SequencingCandidate:
    """Deterministic within-skill item choice: lowest ``difficulty_band`` first, then
    lexicographic ``item_template_id`` (canonical tie-break). No seed, no RNG.

    ``difficulty_band`` is a sequencing-only in-skill ordering hint -- never a correctness
    parent. Fail-closed: raises ``ValueError`` on an empty (or wrong-skill-only) candidate set
    rather than fabricating a selection.
    """
    candidates = [c for c in in_skill_candidates if c.skill_id == selected_skill]
    if not candidates:
        raise ValueError(
            f"select_item_within_skill: no eligible candidate for skill {selected_skill!r} "
            "(empty in-skill candidate set)"
        )
    return min(candidates, key=lambda c: (c.difficulty_band, c.item_template_id))


def _selection_reason_internal(
    stage1_reason: SelectionReason, selected: SequencingCandidate
) -> str:
    """Deterministic, human-readable rationale string recorded B-internally on
    ``GeneratedItemOpportunity.selection_reason_internal``. Not exported to Component C/3 in
    this slice (that adapter wiring is B5)."""
    return (
        "b4.4_adaptive_sequencing:"
        f"stage1_skill={stage1_reason.winning_skill_id};"
        f"stage1_score={stage1_reason.score:.6f};"
        f"stage1_tie_broken={stage1_reason.tie_broken};"
        f"stage2_selected_template={selected.item_template_id};"
        f"stage2_difficulty_band={selected.difficulty_band}"
    )


def build_task_instance_via_sequencing(
    *,
    item_opportunity_id: str,
    student_id: str,
    grade: int,
    scheduled_session_number: int,
    b_session_index: int,
    item_index: int,
    event_order: int,
    seed_lineage: SeedLineage,
    stage1_reason: SelectionReason,
    in_skill_candidates: Sequence[SequencingCandidate],
    catalogue: LoadedCatalogue,
    catalogue_version: str,
    catalogue_status: str,
    catalogue_checksum: str,
) -> tuple[GeneratedItemOpportunity, GeneratedItemInstance]:
    """Two-stage adaptive selection wired into the canonical build path.

    Stage 1's winning skill (``stage1_reason.winning_skill_id``) is taken as-is; Stage 2
    (:func:`select_item_within_skill`) picks the actual item within that skill from
    ``in_skill_candidates`` (typically B4.1's ``eligible_candidates``, filtered/passed by the
    caller). The selected template is instantiated via the existing, unmodified
    :func:`generation.task_instances.build_task_instance` -- no parallel build logic.
    """
    selected = select_item_within_skill(stage1_reason.winning_skill_id, in_skill_candidates)
    template = catalogue.by_id(selected.item_template_id)
    if template is None:
        raise ValueError(f"selected template {selected.item_template_id!r} not found in catalogue")

    opportunity = GeneratedItemOpportunity(
        item_opportunity_id=item_opportunity_id,
        student_id=student_id,
        grade=grade,
        scheduled_session_number=scheduled_session_number,
        b_session_index=b_session_index,
        item_index=item_index,
        event_order=event_order,
        item_template_id=selected.item_template_id,
        skill_id=selected.skill_id,
        curriculum_node_id=template.curriculum_node_id,
        selection_reason_internal=_selection_reason_internal(stage1_reason, selected),
        seed_lineage=seed_lineage,
        generation_phase="B4",
    )

    instance = build_task_instance(
        opportunity, template, catalogue_version, catalogue_status, catalogue_checksum
    )
    return opportunity, instance
