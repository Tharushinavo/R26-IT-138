"""Sequencing eligibility gates (Phase B4.1).

Produces the eligible candidate set from exactly two hard gates plus the existing
implementation/availability policy — nothing else:

1. **Grade gate (HARD).** A template not eligible for the learner's grade is excluded.
2. **Deferred-template fail-closed.** A template with no registered implementation strategy
   (SPEC coverage §B2A.2) is excluded.
3. **Availability**, as already exposed by the existing activation policy
   (:func:`generation.activation.decide_activation`): curriculum-active (not RETIRED/DEFERRED)
   and a recognized catalogue status.

These three checks are exactly what :func:`generation.activation.decide_activation` already
computes — this module reuses it rather than re-deriving the grade gate or the
implemented/deferred partition.

**B-Q4 (explicit scope boundary).** Hard prerequisite-DAG edges are deferred to a later
approval. In v1, prerequisites are *soft*: they influence scoring in B4.2
(``prerequisite_readiness``) but never hard-exclude a candidate here. This module does not read
``template.prerequisite_nodes`` for exclusion purposes.

No BKT/mastery read, no feature computation, no scoring — this slice returns eligibility only.
"""

from __future__ import annotations

import re

from models.contracts import SKILLS

from ..generation.activation import decide_activation
from ..models.catalogue import ItemTemplate, LoadedCatalogue
from ..models.identity import LearnerAuditIdentity
from ..samplers.registry import supported_template_ids
from .models import SequencingCandidate

__all__ = ["eligible_candidates", "difficulty_band_for_template"]

_SKILL_ORDER = {skill: idx for idx, skill in enumerate(SKILLS)}

_DIFFICULTY_LEVEL_RE = re.compile(r"^L(\d+)$")

# Documented deterministic fallback for a difficulty_level string that does not match the
# catalogue's observed "L<n>" convention (e.g. "L1"/"L2"/"L3"). This is a sequencing-only
# ordering hint, never fabricated as a correctness input -- an unparsed level simply sorts
# first (lowest band) rather than raising, since ordering (not correctness) is all that is at
# stake here.
_UNPARSED_DIFFICULTY_BAND_DEFAULT = 0


def difficulty_band_for_template(template: ItemTemplate) -> int:
    """Deterministic sequencing-only difficulty band, sourced from the catalogue's
    ``difficulty_level`` field (observed values: ``"L1"``/``"L2"``/``"L3"``). Never a correctness
    input -- purely an in-skill ordering hint for later scoring (B4.2/B4.3).
    """
    match = _DIFFICULTY_LEVEL_RE.match(template.difficulty_level.strip())
    if match is None:
        return _UNPARSED_DIFFICULTY_BAND_DEFAULT
    return int(match.group(1))


def eligible_candidates(
    learner: LearnerAuditIdentity, catalogue: LoadedCatalogue
) -> list[SequencingCandidate]:
    """The eligible candidate set for one learner: grade gate + deferred fail-closed +
    availability only (B-Q4: no prerequisite exclusion). Deterministic, canonically ordered
    (skill order, then template id) -- no seed, no RNG.
    """
    supported = supported_template_ids()

    eligible: list[SequencingCandidate] = []
    for template in catalogue.templates:
        decision = decide_activation(
            template=template,
            supported_template_ids=supported,
            grade=learner.grade,
            catalogue_status=catalogue.catalogue_status,
        )
        if not decision.active:
            continue
        eligible.append(
            SequencingCandidate(
                skill_id=template.skill_id,
                item_template_id=template.item_template_id,
                difficulty_band=difficulty_band_for_template(template),
            )
        )

    eligible.sort(key=lambda c: (_SKILL_ORDER.get(c.skill_id, len(_SKILL_ORDER)), c.item_template_id))
    return eligible
