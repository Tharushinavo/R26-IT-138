"""Phase B6.2 — SPEC §11 fidelity audit (Component_B_Generator_v1.0/SPEC.md §11).

Reports overlap/range fidelity checks on already-generated session data (SF-039: overlap/range,
**not** per-group bands — population is never read, filtered, or branched on here). This module
is diagnostic/reporting, not a release gate: the SPEC is explicit that "the binding release gate
is SF-038" (``balanced_accuracy < 0.70`` — see ``audits.leakage``); fidelity checks are archived
alongside it, never substituted for it, and this module's overall ``passed`` flag is informational
only (a caller may still choose to block a dataset run on it, but SF-038 is what SPEC §12 step 7
actually gates on).

Several of these checks are already structurally **guaranteed** by the B->3 pydantic contract
itself (``models.contracts.BToComponent3Payload``): RT bounds ``(0, 90]`` and
``median <= mean * 1.5`` (``PositiveTiming``, ``RG-04``), ``error_class_dist`` summing to ``1.0``
(``DF-03``), and the ``accuracy_rate`` identity (``DF-01``) can never be violated by a row that
passed contract validation. This module still reports them (with an expected zero-violation
count) as a live regression confirmation, rather than silently trusting the contract never to
regress.

**Item-count range** and the **NB attempt-mean reference targets** are true overlap/range checks
(SPEC: "overlap reported, not enforced as hard group bands") — reported as fractions/means against
the approved reference figures (item count global range `~10-30`; attempt-mean NB reference
targets `1.08/1.28/1.72`, Component B Parameters §5.4-5.7), never gated per learner or per
population group. **Population-adjusted PSD tests remain outstanding** (SPEC §11: "audit gates,
not asserted here") and are out of scope for this module.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional, Sequence, Tuple

from component_b_generator.aggregation.session import SessionAggregationResult
from models.contracts import BToComponent3Payload

FIDELITY_AUDIT_VERSION = "b6.2-1.0.0"

# SPEC §11: item counts fall within the global reference range (~10-30), TD/MLD/DD figures used
# only as reference priors (not enforced as hard per-group bands).
ITEM_COUNT_REFERENCE_RANGE: Tuple[int, int] = (10, 30)

# SPEC §11 / Component B Parameters §5.5: NB attempt-mean reference targets (TD/MLD/DD), reported
# as overlapping distributions -- context only, never a per-learner or per-group gate.
ATTEMPT_MEAN_REFERENCE_TARGETS: Tuple[float, float, float] = (1.08, 1.28, 1.72)

# SPEC §11 / register B-030: random-error-class share fidelity check.
RANDOM_ERROR_SHARE_BUDGET = 0.25

# Contract-enforced bound (PositiveTiming), reconfirmed here rather than silently trusted.
RT_UPPER_BOUND_SEC = 90.0


@dataclass(frozen=True)
class FidelityAuditResult:
    audit_version: str
    n_sessions: int

    item_count_mean: float
    item_count_in_reference_range_fraction: float
    item_count_reference_range: Tuple[int, int]

    mean_attempts_per_item: float
    attempt_mean_reference_targets: Tuple[float, float, float]

    rt_out_of_bounds_count: int  # expected 0 (contract-enforced); reported, not silently trusted
    rt_median_exceeds_mean_1_5x_count: int  # expected 0 (contract-enforced RG-04)

    random_error_share_mean: float
    random_error_share_within_budget_fraction: float
    random_error_share_budget: float

    accuracy_rate_identity_violations: int  # expected 0 (contract-enforced DF-01)
    error_class_dist_sum_violations: int  # expected 0 (contract-enforced DF-03)

    premature_certification_count: int  # certified True while evidence < floor_min_obs
    mastery_slope_null_below_four_observations_violations: int  # expected 0 (adapter-enforced)

    passed: bool  # informational only -- SF-038 (audits.leakage) is the binding release gate


def run_fidelity_audit(
    sessions: Sequence[Tuple[SessionAggregationResult, BToComponent3Payload]],
    *,
    floor_min_obs: int,
) -> FidelityAuditResult:
    """Compute the SPEC §11 fidelity report over a set of ``(aggregation, b_to_3_payload)`` pairs
    for already-generated, contract-validated attended sessions.

    ``floor_min_obs`` is the Guess-Guard minimum-observation threshold (``BBKTConfig.floor_min_obs``)
    used only for the warm-up check below — this module reads no population/dd_subtype anywhere.
    """
    if not sessions:
        raise ValueError("run_fidelity_audit requires at least one session")

    n = len(sessions)

    item_counts = [payload.total_questions for _, payload in sessions]
    item_count_mean = sum(item_counts) / n
    in_range = sum(
        1 for c in item_counts if ITEM_COUNT_REFERENCE_RANGE[0] <= c <= ITEM_COUNT_REFERENCE_RANGE[1]
    )
    item_count_in_reference_range_fraction = in_range / n

    attempts_per_item = [
        agg.summary.total_attempts / agg.summary.total_opportunities
        for agg, _ in sessions
        if agg.summary.total_opportunities
    ]
    mean_attempts_per_item = sum(attempts_per_item) / len(attempts_per_item) if attempts_per_item else 0.0

    rt_out_of_bounds = 0
    rt_median_violations = 0
    for _, payload in sessions:
        rts = (
            payload.b_mean_item_response_time_sec,
            payload.b_median_item_response_time_sec,
            payload.b_item_response_time_std_sec,
        )
        if any(rt is not None and not (0.0 < rt <= RT_UPPER_BOUND_SEC) for rt in rts):
            rt_out_of_bounds += 1
        mean_rt, median_rt = payload.b_mean_item_response_time_sec, payload.b_median_item_response_time_sec
        if mean_rt is not None and median_rt is not None and median_rt > mean_rt * 1.5:
            rt_median_violations += 1

    random_shares = [payload.error_class_dist.random for _, payload in sessions]
    random_error_share_mean = sum(random_shares) / n
    random_within_budget = sum(1 for r in random_shares if r <= RANDOM_ERROR_SHARE_BUDGET)
    random_error_share_within_budget_fraction = random_within_budget / n

    accuracy_violations = sum(
        1
        for _, payload in sessions
        if abs(payload.accuracy_rate - payload.correct_responses / payload.total_questions) > 1e-6
    )
    error_sum_violations = sum(
        1
        for _, payload in sessions
        if abs(sum(payload.error_class_dist.model_dump().values()) - 1.0) > 1e-6
    )

    premature_certification = 0
    slope_violations = 0
    for _, payload in sessions:
        for skill in payload.mastery_certified.model_dump():
            certified = getattr(payload.mastery_certified, skill)
            observations = getattr(payload.opportunities_w4, skill)
            slope = getattr(payload.mastery_slope_w4, skill)
            if certified and observations < floor_min_obs:
                premature_certification += 1
            if observations < 4 and slope is not None:
                slope_violations += 1

    passed = (
        rt_out_of_bounds == 0
        and rt_median_violations == 0
        and accuracy_violations == 0
        and error_sum_violations == 0
        and slope_violations == 0
    )

    return FidelityAuditResult(
        audit_version=FIDELITY_AUDIT_VERSION,
        n_sessions=n,
        item_count_mean=item_count_mean,
        item_count_in_reference_range_fraction=item_count_in_reference_range_fraction,
        item_count_reference_range=ITEM_COUNT_REFERENCE_RANGE,
        mean_attempts_per_item=mean_attempts_per_item,
        attempt_mean_reference_targets=ATTEMPT_MEAN_REFERENCE_TARGETS,
        rt_out_of_bounds_count=rt_out_of_bounds,
        rt_median_exceeds_mean_1_5x_count=rt_median_violations,
        random_error_share_mean=random_error_share_mean,
        random_error_share_within_budget_fraction=random_error_share_within_budget_fraction,
        random_error_share_budget=RANDOM_ERROR_SHARE_BUDGET,
        accuracy_rate_identity_violations=accuracy_violations,
        error_class_dist_sum_violations=error_sum_violations,
        premature_certification_count=premature_certification,
        mastery_slope_null_below_four_observations_violations=slope_violations,
        passed=passed,
    )
