"""Population-neutrality audits (SF-039) — Phase B1.

Two complementary checks:

1. **Behavioural** — generation output is a pure function of ``(catalogue, grade, student_id,
   seeds, config)``; ``population`` / ``dd_subtype`` are never read. Proven by regenerating the
   same cohort with rotated population labels and asserting identical ``b_item_opportunities``.

2. **Static** — a narrow source scan that flags the truly forbidden constructs: branching on
   ``population``/``dd_subtype`` equality, or indexing a collection by the label (a TD/MLD/DD
   runtime selector). The permitted cohort-composition weights are an ordered tuple, never
   indexed by a population variable, so they do not match.
"""

from __future__ import annotations

import re
from pathlib import Path
from typing import List, Tuple

from ..config.loader import GeneratorConfig
from ..cohort.builder import CohortMember, build_cohort
from ..generation.item_opportunities import generate_item_opportunities
from ..models.catalogue import LoadedCatalogue
from ..models.identity import LearnerAuditIdentity
from ..seeds import SeedManager

_PACKAGE_DIR = Path(__file__).resolve().parents[1]

_FORBIDDEN_PATTERNS: Tuple[re.Pattern, ...] = (
    re.compile(r"\b(if|elif)\b[^\n#]*\b(population|dd_subtype)\b[^\n#]*=="),
    re.compile(r"\[\s*(population|dd_subtype)\s*\]"),
)

_ROTATE = {"TD": "MLD", "MLD": "DD", "DD": "TD"}


def _opps_signature(opps) -> Tuple:
    return tuple(
        (o.item_opportunity_id, o.item_template_id, o.skill_id, o.curriculum_node_id, o.grade, o.event_order)
        for o in opps
    )


def opportunities_population_independent(catalogue: LoadedCatalogue, config: GeneratorConfig) -> bool:
    """True iff rotating every learner's (audit-only) population label leaves the generated
    ``b_item_opportunities`` unchanged."""
    seeds = SeedManager(config.global_seed)
    base = build_cohort(config, seeds)

    rotated: List[CohortMember] = []
    for m in base:
        new_pop = _ROTATE[m.identity.population]
        rotated_identity = LearnerAuditIdentity(
            student_id=m.identity.student_id,
            grade=m.identity.grade,
            population=new_pop,  # type: ignore[arg-type]
            dd_subtype=m.identity.dd_subtype,
        )
        rotated.append(CohortMember(identity=rotated_identity, b_local_state=m.b_local_state))

    base_opps = generate_item_opportunities(catalogue, base, config, seeds)
    rotated_opps = generate_item_opportunities(catalogue, rotated, config, seeds)
    return _opps_signature(base_opps) == _opps_signature(rotated_opps)


def scan_source_for_population_branching(package_dir: Path | None = None) -> List[str]:
    """Return a list of ``path:line`` offenders (empty if clean). Skips comment lines."""
    root = package_dir or _PACKAGE_DIR
    offenders: List[str] = []
    for py in sorted(root.rglob("*.py")):
        if py.resolve() == Path(__file__).resolve():
            continue  # this audit module references the tokens by design
        for lineno, line in enumerate(py.read_text(encoding="utf-8").splitlines(), start=1):
            if line.lstrip().startswith("#"):
                continue
            for pat in _FORBIDDEN_PATTERNS:
                if pat.search(line):
                    offenders.append(f"{py.relative_to(root.parent)}:{lineno}: {line.strip()}")
    return offenders
