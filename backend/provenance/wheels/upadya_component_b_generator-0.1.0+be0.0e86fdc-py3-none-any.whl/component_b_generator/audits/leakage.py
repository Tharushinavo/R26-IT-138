"""Phase B6.1 — SF-038 population-leakage audit (Component_B_Generator_v1.0/SPEC.md §11).

Trains a depth-4 ``sklearn.tree.DecisionTreeClassifier`` to predict the audit-only ``population``
label from the deployable B->3 feature set. **Primary pass/fail gate: ``balanced_accuracy < 0.70``**
(a value ``>= 0.70`` FAILS — population must not be reconstructable from output that never
carries it). Also reports raw accuracy, the majority-class baseline, macro-F1, one-vs-rest
ROC-AUC, and the confusion matrix (owner decision 2026-07-12, Shared Foundation Decision Register
v0.3.3): raw accuracy alone is uninformative under a 70% TD cohort majority — a trivial
"always predict TD" classifier already scores ~70% raw accuracy, which is why balanced accuracy is
the decisive metric.

**Group split by ``student_id`` (SF-028).** Every row from one learner goes entirely into train or
entirely into test, never split across both — otherwise the classifier could trivially exploit
per-student identity/continuity rather than genuine population-conditioned structure.

This module is a **read-only, after-the-fact probe** over already-generated, contract-validated
``BToComponent3Payload`` rows — the exact SPEC §11 audit. It never reads ``population``/
``dd_subtype`` to generate anything (those fields are not even present on the payload, by
construction — SF-031/032); the population label is supplied here only as the audit's external,
out-of-band prediction *target*, joined by ``student_id``.

**ROC-AUC robustness (release-hardening).** One-vs-rest macro ROC-AUC is undefined when a
one-vs-rest binarization of the (grouped, randomly split) test set degenerates to a single class
— e.g. a population label entirely absent from the test split, or present in every test row. In
that condition scikit-learn does not raise: it emits ``UndefinedMetricWarning`` via
``warnings.warn`` and returns a non-finite (``NaN``) score for that binarization, which would
otherwise silently propagate into ``one_vs_rest_roc_auc`` as ``NaN`` — not a valid ``float`` per
this field's own ``Optional[float]`` contract, not valid strict JSON (RFC 8259 has no ``NaN``
token), and a value for which ``NaN != NaN`` defeats any downstream equality/determinism check.
``run_leakage_audit`` therefore promotes that specific warning to a catchable exception for the
duration of the call (``warnings.catch_warnings`` + ``simplefilter("error", ...)``, restored
immediately after) and additionally verifies the result is finite before accepting it — belt and
suspenders. Either path yields ``one_vs_rest_roc_auc = None``, never ``NaN``/``inf``. This never
touches the classifier, the grouped train/test split, or the balanced-accuracy computation (the
binding SF-038 gate) — it only hardens the auxiliary ROC-AUC metric in the required reporting
suite.
"""

from __future__ import annotations

import math
import warnings
from dataclasses import dataclass
from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np
from sklearn.exceptions import UndefinedMetricWarning
from sklearn.metrics import (
    accuracy_score,
    balanced_accuracy_score,
    confusion_matrix as sk_confusion_matrix,
    f1_score,
    roc_auc_score,
)
from sklearn.model_selection import GroupShuffleSplit
from sklearn.tree import DecisionTreeClassifier

from models.contracts import ERROR_CLASSES, SKILLS, BToComponent3Payload

LEAKAGE_AUDIT_VERSION = "b6.1-1.0.0"

# SF-038 (RESOLVED, owner decision 2026-07-12): primary release gate. A value >= this FAILS.
BALANCED_ACCURACY_GATE = 0.70

# Depth is FROZEN by SF-038's resolution (Shared Foundation Decision Register v0.3.3) — not a
# tunable audit parameter.
TREE_MAX_DEPTH = 4

# Audit-only imputation for nullable numeric fields (e.g. an all-timeout session's RT stats).
# This never touches generation — it only lets the leakage probe's feature matrix be dense; a
# missing value is itself a legitimate (and reported) signal to the classifier, not a fabricated
# generation output.
_MISSING_SENTINEL = -1.0


def _or_missing(value: Optional[float]) -> float:
    return _MISSING_SENTINEL if value is None else float(value)


def leakage_feature_names() -> Tuple[str, ...]:
    """The stable, ordered column names of the deployable B->3 feature set used by this audit."""
    names: List[str] = [
        "b_session_number",
        "total_questions",
        "correct_responses",
        "accuracy_rate",
        "hint_requests",
        "b_mean_item_response_time_sec",
        "b_median_item_response_time_sec",
        "b_item_response_time_std_sec",
        "guess_guard_triggered",
    ]
    for skill in SKILLS:
        names.append(f"mastery_{skill}")
        names.append(f"mastery_certified_{skill}")
        names.append(f"mastery_slope_w4_{skill}")
        names.append(f"opportunities_w4_{skill}")
    for cls in ERROR_CLASSES:
        names.append(f"error_class_{cls}")
    return tuple(names)


def _flatten_payload(payload: BToComponent3Payload) -> Dict[str, float]:
    """Flatten one already-generated, contract-validated B->3 row into a numeric feature dict.
    Reads only fields already present on ``BToComponent3Payload`` (SPEC §11's "deployable B->3
    feature set") — adds no field, reads no forbidden field."""
    features: Dict[str, float] = {
        "b_session_number": float(payload.b_session_number),
        "total_questions": float(payload.total_questions),
        "correct_responses": float(payload.correct_responses),
        "accuracy_rate": float(payload.accuracy_rate),
        "hint_requests": float(payload.hint_requests),
        "b_mean_item_response_time_sec": _or_missing(payload.b_mean_item_response_time_sec),
        "b_median_item_response_time_sec": _or_missing(payload.b_median_item_response_time_sec),
        "b_item_response_time_std_sec": _or_missing(payload.b_item_response_time_std_sec),
        "guess_guard_triggered": _or_missing(
            float(payload.guess_guard_triggered) if payload.guess_guard_triggered is not None else None
        ),
    }
    for skill in SKILLS:
        features[f"mastery_{skill}"] = float(getattr(payload, f"mastery_{skill}"))
        features[f"mastery_certified_{skill}"] = float(getattr(payload.mastery_certified, skill))
        features[f"mastery_slope_w4_{skill}"] = _or_missing(getattr(payload.mastery_slope_w4, skill))
        features[f"opportunities_w4_{skill}"] = float(getattr(payload.opportunities_w4, skill))
    for cls in ERROR_CLASSES:
        features[f"error_class_{cls}"] = float(getattr(payload.error_class_dist, cls))
    return features


@dataclass(frozen=True)
class LeakageAuditResult:
    """SF-038 audit outcome. ``passed`` is the single binding release gate; every other field is
    the required reporting suite (register v0.3.3), archived alongside it — never used to
    override the primary gate."""

    audit_version: str
    tree_max_depth: int
    balanced_accuracy: float
    passed: bool  # balanced_accuracy < BALANCED_ACCURACY_GATE
    raw_accuracy: float
    majority_class_baseline: float
    macro_f1: float
    one_vs_rest_roc_auc: Optional[float]  # None only when the test split has < 2 classes present
    confusion_matrix: Tuple[Tuple[int, ...], ...]
    class_labels: Tuple[str, ...]  # row/column order of confusion_matrix
    n_train_rows: int
    n_test_rows: int
    n_train_learners: int
    n_test_learners: int
    feature_names: Tuple[str, ...]


def _safe_one_vs_rest_roc_auc(
    y_test: np.ndarray, proba: np.ndarray, classes: Sequence[str]
) -> Optional[float]:
    """One-vs-rest macro ROC-AUC, or ``None`` when it is not validly computable.

    Never returns ``NaN``/``inf`` (release-hardening, see module docstring). Two independent
    guards: (1) the degenerate-binarization warning sklearn emits internally is promoted to a
    catchable exception only for this call, so a one-vs-rest split with a missing or single
    present class in ``y_test`` cleanly yields ``None`` instead of a silent ``NaN``; (2) even if
    a finite-looking exception-free path somehow produced a non-finite value, it is rejected
    before being returned. Pure function of its inputs — no seed, no mutation.
    """
    try:
        with warnings.catch_warnings():
            warnings.simplefilter("error", category=UndefinedMetricWarning)
            score = roc_auc_score(
                y_test, proba, multi_class="ovr", average="macro", labels=list(classes)
            )
    except (ValueError, UndefinedMetricWarning):
        # Degenerate one-vs-rest split (a class missing from, or the only class present in,
        # y_test) -- ROC-AUC is undefined here, not fabricated as NaN.
        return None

    score = float(score)
    if not math.isfinite(score):
        # Defense in depth: never surface a non-finite value even if some other sklearn code
        # path returns one without warning/raising.
        return None
    return score


def run_leakage_audit(
    rows: Sequence[Tuple[str, str, BToComponent3Payload]],
    *,
    random_seed: int,
    test_size: float = 0.30,
) -> LeakageAuditResult:
    """Run the SF-038 leakage audit over a set of ``(student_id, population, payload)`` rows.

    ``population`` is the learner's audit-only cohort label (never present on ``payload`` itself)
    supplied here purely as the external prediction target for this after-the-fact probe.
    Grouped by ``student_id`` (SF-028): the same learner's rows never appear in both train and
    test. Deterministic for a fixed ``random_seed`` + fixed input rows.
    """
    if len(rows) < 4:
        raise ValueError("run_leakage_audit requires at least 4 rows to form a train/test split")

    feature_names = leakage_feature_names()
    X = np.array(
        [[_flatten_payload(payload)[name] for name in feature_names] for _, _, payload in rows]
    )
    y = np.array([population for _, population, _ in rows])
    groups = np.array([student_id for student_id, _, _ in rows])

    splitter = GroupShuffleSplit(n_splits=1, test_size=test_size, random_state=random_seed)
    train_idx, test_idx = next(splitter.split(X, y, groups))

    X_train, X_test = X[train_idx], X[test_idx]
    y_train, y_test = y[train_idx], y[test_idx]

    clf = DecisionTreeClassifier(max_depth=TREE_MAX_DEPTH, random_state=random_seed)
    clf.fit(X_train, y_train)
    y_pred = clf.predict(X_test)

    # Benign, expected multiclass edge case (distinct from the ROC-AUC case above): when the
    # tree predicts a class absent from this test split's true labels, sklearn still returns a
    # correct, finite balanced-accuracy value (per-class recall is nanmean'd over classes
    # genuinely present in y_test) but also emits a UserWarning -- which is not an error
    # condition and does not affect the SF-038 gate value, so it is suppressed rather than
    # escalated. The computed balanced_accuracy value and BALANCED_ACCURACY_GATE comparison are
    # completely unchanged.
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=UserWarning)
        balanced_accuracy = float(balanced_accuracy_score(y_test, y_pred))
    raw_accuracy = float(accuracy_score(y_test, y_pred))
    majority_label, majority_count = max(
        ((label, int((y_test == label).sum())) for label in np.unique(y_test)),
        key=lambda pair: pair[1],
    )
    majority_class_baseline = majority_count / len(y_test)
    macro_f1 = float(f1_score(y_test, y_pred, average="macro", zero_division=0))

    class_labels = tuple(sorted(clf.classes_.tolist()))
    cm = sk_confusion_matrix(y_test, y_pred, labels=list(class_labels))
    confusion = tuple(tuple(int(v) for v in row) for row in cm)

    proba = clf.predict_proba(X_test)
    one_vs_rest_roc_auc = _safe_one_vs_rest_roc_auc(y_test, proba, clf.classes_.tolist())

    return LeakageAuditResult(
        audit_version=LEAKAGE_AUDIT_VERSION,
        tree_max_depth=TREE_MAX_DEPTH,
        balanced_accuracy=balanced_accuracy,
        passed=balanced_accuracy < BALANCED_ACCURACY_GATE,
        raw_accuracy=raw_accuracy,
        majority_class_baseline=majority_class_baseline,
        macro_f1=macro_f1,
        one_vs_rest_roc_auc=one_vs_rest_roc_auc,
        confusion_matrix=confusion,
        class_labels=class_labels,
        n_train_rows=len(train_idx),
        n_test_rows=len(test_idx),
        n_train_learners=len(set(groups[train_idx].tolist())),
        n_test_learners=len(set(groups[test_idx].tolist())),
        feature_names=feature_names,
    )
