"""Generator audits (Phase B1: population neutrality; Phase B6.1: SF-038 leakage; Phase B6.2:
fidelity)."""

from __future__ import annotations

from .fidelity import FidelityAuditResult, run_fidelity_audit
from .leakage import (
    BALANCED_ACCURACY_GATE,
    LeakageAuditResult,
    leakage_feature_names,
    run_leakage_audit,
)
from .population_neutrality import (
    opportunities_population_independent,
    scan_source_for_population_branching,
)

__all__ = [
    "opportunities_population_independent",
    "scan_source_for_population_branching",
    "BALANCED_ACCURACY_GATE",
    "LeakageAuditResult",
    "leakage_feature_names",
    "run_leakage_audit",
    "FidelityAuditResult",
    "run_fidelity_audit",
]
