"""Phase B6.0 — multi-session pipeline orchestrator.

Chains B4 (adaptive item selection) -> B2A (task-instance build) -> B2B.3 (attempt loop) -> B3
(BKT update + Guess-Guard + certification) -> B5 (session aggregation + B->C/B->3 adapters),
looping scheduled sessions ``1..scheduled_session_count`` in order for each learner and carrying
forward that learner's B-internal state (BKT mastery estimates, spacing-due history, Guess-Guard
RT history, mastery-slope history) session-to-session. No existing module did this: every prior
phase's tests exercise one session/one opportunity in isolation (B1-B5 freeze tests). This module
reuses every existing pure/typed building block unmodified — it adds no new generation, scoring,
or contract logic of its own.

**Hidden truth stays frozen (documented scope boundary, not an invention).**
``fixed_hidden_growth_g`` (B2B spec §13) is a versioned configuration constant with a recorded
owner-decision value (Simulator Owner Decision 4: ``g=0.008``), but its *opportunity-eligibility
rule* is explicitly ``CALIBRATION_PENDING``, and no B2B.0-3 module applies it — each is documented
as reading ``learner_truth`` unmutated ("no hidden growth", see e.g.
``behaviour.attempt_loop.generate_opportunity_attempts``). Applying it would be new hidden-mastery-
dynamics logic, not orchestration glue, so it is out of scope here: every learner's
``BInitialLearnerSkillTruth`` (initialized once, B2B.1) is reused unchanged across every session
in this pilot pipeline. This matches, byte-for-byte, the existing frozen behaviour of every
attempt-loop call in B2B.2/B2B.3 — a limitation to record, not a gap to silently paper over.

**Attendance stays at Phase B1's existing assumption**: every scheduled session is B-attended.
The SF-040 calendar/attrition model is explicitly a shared-simulator concern outside Component B's
scope (SF-041) and is not implemented here — see ``models.session.ScheduledSessionContext``'s own
docstring. Every session in this pipeline is therefore ``status="attended"``.

**Three ENGINEERING_ASSUMPTION plumbing choices** (not scientific values — see also SPEC §13's own
"ENGINEERING_ASSUMPTION" tag on the Grade-2/3 split default for the same status tier), recorded
here because no existing slice defines multi-session granularity:

1. **Spacing history is session-grained.** ``sequencing.features.compute_features`` wants "sessions
   since last practice" per skill; this pipeline updates that count once per session (from state as
   of session start), so every item selected within one session sees the same ``spacing_due`` inputs
   — items already practised earlier in the same session do not retroactively change it.
2. **Guess-Guard RT history accumulates raw first-attempt seconds, per skill, across sessions**
   (matching ``bkt.guess_guard.plausibility_floor``'s own docstring: "the learner's valid
   first-attempt response times"). Each session's floor is computed from history strictly *before*
   that session (no self-referential floor), evaluated against that session's own per-skill median
   RT (reusing the existing type-7 ``bkt.guess_guard._quantile``, the same statistic B5.1 already
   uses for the session-wide median) — then that session's RTs are appended for future sessions.
3. **Mastery-slope history appends once per session, for every skill**, using each skill's current
   BKT estimate (``BBKTSkillState.p_l``) — the latest posterior whether or not that skill was
   practised this session. This keeps ``adapters.to_3.build_b_to_3_payload``'s
   ``skill_mastery_history`` non-empty for all seven skills from session 1 onward (it raises
   otherwise); ``BBKTSkillState`` is pre-populated with each skill's prior ``P(L0)`` before any
   opportunity, so an unpractised skill's "observation" is honestly just its still-unrevised prior.

**No real intervention calendar exists (SF-040 not yet built).** ``intervention_session_id``/
``intervention_session_number`` are 1:1 with the B-session index (matching 100% attendance above);
``intervention_session_date`` uses a fixed, deterministic weekly-cadence synthetic anchor
(``_SYNTHETIC_CALENDAR_ANCHOR``) purely to satisfy the B->3 contract's required date field — it is
not a claim about real study dates.

**No Component C in this pilot.** ``PipelineConfig.c_present`` defaults to ``False``: Component C
is not implemented, so every B->C payload this pipeline builds is honestly ``None``
(``adapters.to_c.build_b_to_c_payload``'s documented "B-only: no C side to receive it" semantics) —
never fabricated.

**Session-level ``selection_reason`` is left ``None``.** B4 produces one adaptive-selection
rationale per *item*, but ``adapters.to_3.build_b_to_3_payload`` accepts one categorical
``selection_reason`` per *session*. No existing slice defines how to roll many per-item rationales
into one session-level category, so this pipeline reports it honestly absent rather than inventing
an aggregation rule.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date, timedelta
from typing import Dict, List, Optional, Sequence, Tuple

from models.contracts import SKILLS, BToCMasteryPayload, BToComponent3Payload

from .adapters.to_3 import build_b_to_3_payload
from .adapters.to_c import build_b_to_c_payload
from .aggregation.session import SessionAggregationResult, SessionIdentity, aggregate_session
from .behaviour.attempt_loop import generate_opportunity_attempts
from .behaviour.initialization import initialize_learner_truth_for_all_skills
from .bkt.config import BBKTConfig
from .bkt.guess_guard import GuessGuardStatus, _quantile, evaluate_guess_guard
from .bkt.orchestrator import update_skill_mastery
from .bkt.state import BBKTSkillState
from .catalogue.loader import catalogue_file_checksum, load_catalogue
from .cohort.builder import CohortMember
from .config.loader import GeneratorConfig
from .generation.item_opportunities import _draw_item_count
from .models.behaviour import BAttemptLoopConfig, BInitialLearnerSkillTruth, BTruthInitializationConfig
from .models.catalogue import LoadedCatalogue
from .seeds import SeedManager, rng_from
from .sequencing.config import BSequencingConfig
from .sequencing.eligibility import eligible_candidates
from .sequencing.features import compute_features
from .sequencing.score import ScoredCandidate, score_candidate, select_target
from .sequencing.select_item import build_task_instance_via_sequencing

PIPELINE_VERSION = "b6.0-1.0.0"

# ENGINEERING_ASSUMPTION (plumbing, not a scientific value — see module docstring point 4): a
# deterministic synthetic weekly intervention-calendar anchor, used only because SF-040's real
# shared 25-slot calendar is not yet implemented. Shared by every learner so session dates are
# internally comparable; not a claim about real study dates.
_SYNTHETIC_CALENDAR_ANCHOR = date(2026, 1, 5)
_SYNTHETIC_SESSION_INTERVAL_DAYS = 7


@dataclass(frozen=True)
class PipelineConfig:
    """Bundles every sub-phase config this pipeline needs. No defaults: every field is a
    scientific/version parameter that must be supplied explicitly (CALIBRATION_PENDING or a
    clearly-tagged fixture), matching every underlying config's own no-defaults convention."""

    generator_config: GeneratorConfig
    sequencing_config: BSequencingConfig
    bkt_config: BBKTConfig
    truth_init_config: BTruthInitializationConfig
    attempt_loop_config: BAttemptLoopConfig
    c_present: bool = False  # B-only pilot: Component C is not implemented/run.


@dataclass(frozen=True)
class SessionPipelineResult:
    session_number: int
    aggregation: SessionAggregationResult
    b_to_c_payload: Optional[BToCMasteryPayload]
    b_to_3_payload: BToComponent3Payload


@dataclass(frozen=True)
class LearnerPipelineResult:
    student_id: str
    sessions: Tuple[SessionPipelineResult, ...]


@dataclass
class _LearnerRunState:
    """Mutable, in-run-only carry-forward state for one learner. Never exported/serialized —
    only the typed, contract-validated per-session outputs leave this module."""

    bkt_states: Dict[str, BBKTSkillState]
    truths: Dict[str, BInitialLearnerSkillTruth]
    last_practiced_session: Dict[str, int] = field(default_factory=dict)
    rt_history_sec: Dict[str, List[float]] = field(default_factory=lambda: {s: [] for s in SKILLS})
    mastery_history: Dict[str, List[float]] = field(default_factory=lambda: {s: [] for s in SKILLS})


def _initial_bkt_states(student_id: str, bkt_config: BBKTConfig) -> Dict[str, BBKTSkillState]:
    return {
        skill: BBKTSkillState(
            student_id=student_id,
            skill_id=skill,
            p_l=bkt_config.skill_params[skill].p_l0,
            observation_count=0,
        )
        for skill in SKILLS
    }


def _run_session(
    member: CohortMember,
    session_number: int,
    catalogue: LoadedCatalogue,
    catalogue_checksum: str,
    config: PipelineConfig,
    seeds: SeedManager,
    state: _LearnerRunState,
) -> SessionPipelineResult:
    sid = member.identity.student_id
    grade = member.identity.grade

    count_rng = rng_from(seeds.component_b_session(sid, session_number, session_number))
    item_count = _draw_item_count(count_rng, config.generator_config)

    candidates = eligible_candidates(member.identity, catalogue)
    if not candidates:
        raise RuntimeError(f"No eligible candidates for {sid} grade {grade}; catalogue defect.")

    opportunity_summaries = []
    mastery_updates = []
    session_rt_by_skill: Dict[str, List[float]] = {}

    for item_index in range(1, item_count + 1):
        scored: List[ScoredCandidate] = []
        for c in candidates:
            feats = compute_features(
                c, state.bkt_states, catalogue, state.last_practiced_session, config.bkt_config
            )
            scored.append(ScoredCandidate(c, feats, score_candidate(feats, config.sequencing_config)))

        selection = select_target(scored)
        winning_skill = selection.candidate.skill_id
        in_skill = [c for c in candidates if c.skill_id == winning_skill]

        lineage = seeds.item_opportunity(sid, session_number, session_number, item_index)
        opportunity, instance = build_task_instance_via_sequencing(
            item_opportunity_id=f"{sid}-B{session_number:03d}-I{item_index:03d}",
            student_id=sid,
            grade=grade,
            scheduled_session_number=session_number,
            b_session_index=session_number,
            item_index=item_index,
            event_order=item_index,
            seed_lineage=lineage,
            stage1_reason=selection.selection_reason,
            in_skill_candidates=in_skill,
            catalogue=catalogue,
            catalogue_version=catalogue.catalogue_version,
            catalogue_status=catalogue.catalogue_status,
            catalogue_checksum=catalogue_checksum,
        )

        learner_truth = state.truths[opportunity.skill_id]
        session_id_str = f"{sid}-B-{session_number:03d}"
        attempt_result = generate_opportunity_attempts(
            instance, learner_truth, config.attempt_loop_config, session_id_str
        )

        bkt_state = state.bkt_states[opportunity.skill_id]
        update = update_skill_mastery(bkt_state, attempt_result, config.bkt_config)
        state.bkt_states[opportunity.skill_id] = BBKTSkillState(
            student_id=sid,
            skill_id=opportunity.skill_id,
            p_l=update.mastery_after,
            observation_count=bkt_state.observation_count + 1,
        )

        opportunity_summaries.append(attempt_result.summary)
        mastery_updates.append(update)

        if attempt_result.summary.first_attempt_error_pattern != "timeout_no_response":
            session_rt_by_skill.setdefault(opportunity.skill_id, []).append(
                attempt_result.summary.first_attempt_response_time_ms / 1000.0
            )

    # Guess-Guard per practised skill: floor from history strictly BEFORE this session,
    # evaluated against this session's own per-skill median RT (point 2, module docstring).
    guard_statuses: Dict[str, GuessGuardStatus] = {}
    for skill, rts in session_rt_by_skill.items():
        prior_history = state.rt_history_sec[skill]
        session_median = _quantile(sorted(rts), 0.5)
        guard_statuses[skill] = evaluate_guess_guard(
            p_l=state.bkt_states[skill].p_l,
            median_item_response_time_sec=session_median,
            rt_history=prior_history,
            theta_B=config.bkt_config.theta_B,
            q=config.bkt_config.floor_quantile,
            n_min=config.bkt_config.floor_min_obs,
        )
        state.rt_history_sec[skill].extend(rts)

    identity = SessionIdentity(
        student_id=sid,
        b_session_index=session_number,
        scheduled_session_number=session_number,
        status="attended",
    )
    agg = aggregate_session(
        identity,
        opportunity_summaries,
        mastery_updates,
        guard_statuses=guard_statuses,
        theta_B=config.bkt_config.theta_B,
    )

    practiced_skills = {u.skill_id for u in mastery_updates}
    for skill in practiced_skills:
        state.last_practiced_session[skill] = session_number
    for skill in SKILLS:
        state.mastery_history[skill].append(state.bkt_states[skill].p_l)

    intervention_session_id = f"{sid}-I-{session_number:03d}"
    intervention_date = _SYNTHETIC_CALENDAR_ANCHOR + timedelta(
        days=_SYNTHETIC_SESSION_INTERVAL_DAYS * (session_number - 1)
    )

    b_to_c = build_b_to_c_payload(
        sid,
        intervention_session_id,
        session_number,
        {skill: state.bkt_states[skill].p_l for skill in SKILLS},
        b_present=True,
        c_present=config.c_present,
    )
    b_to_3 = build_b_to_3_payload(
        agg.summary,
        agg.stats,
        agg.skill_rollups,
        intervention_session_id=intervention_session_id,
        intervention_session_number=session_number,
        intervention_session_date=intervention_date,
        skill_mastery_history=state.mastery_history,
        guard_statuses=guard_statuses,
        selection_reason=None,
    )

    return SessionPipelineResult(
        session_number=session_number, aggregation=agg, b_to_c_payload=b_to_c, b_to_3_payload=b_to_3
    )


def run_pipeline_for_learner(
    member: CohortMember,
    catalogue: LoadedCatalogue,
    catalogue_checksum: str,
    config: PipelineConfig,
    seeds: SeedManager,
) -> LearnerPipelineResult:
    """Run every scheduled session for one learner, in order, carrying B-internal state forward."""
    sid = member.identity.student_id
    truths = {
        t.skill_id: t
        for t in initialize_learner_truth_for_all_skills(sid, seeds.learner(sid), config.truth_init_config)
    }
    state = _LearnerRunState(bkt_states=_initial_bkt_states(sid, config.bkt_config), truths=truths)

    sessions = tuple(
        _run_session(member, session_number, catalogue, catalogue_checksum, config, seeds, state)
        for session_number in range(1, config.generator_config.scheduled_session_count + 1)
    )
    return LearnerPipelineResult(student_id=sid, sessions=sessions)


def run_pipeline(
    cohort: Sequence[CohortMember],
    config: PipelineConfig,
    catalogue_path: Optional[str] = None,
) -> Tuple[LearnerPipelineResult, ...]:
    """Run the full multi-session pipeline for a cohort. Deterministic learner order (by
    ``student_id``) — output does not depend on cohort iteration order (each learner's seeds
    derive only from ``(global_seed, student_id, ...)``, never from position)."""
    catalogue = load_catalogue(catalogue_path)
    catalogue_checksum = catalogue_file_checksum(catalogue.source_path)
    seeds = SeedManager(config.generator_config.global_seed)
    return tuple(
        run_pipeline_for_learner(member, catalogue, catalogue_checksum, config, seeds)
        for member in sorted(cohort, key=lambda m: m.identity.student_id)
    )
