"""Minimal, deterministic cohort initialization (SPEC §4) — Phase B1.

Assigns each synthetic learner a ``student_id``, a **grade** (independent of population),
and an **audit-only** population label sampled from the cohort composition control
(SF-008 / S6 — the one permitted population use: membership sampling, not behaviour). The
B-local latent traits are left as ``CALIBRATION_PENDING`` placeholders (drawn later).

SF-039: population is **not** used to drive any generation behaviour. It is drawn *after*
grade, from the learner's own seed, so grade is independent of population and no learner's
output depends on cohort ordering.
"""

from __future__ import annotations

from typing import List, Tuple

from pydantic import BaseModel, ConfigDict

from ..config.loader import GeneratorConfig
from ..models.identity import LearnerAuditIdentity
from ..models.state import LearnerBLocalState
from ..seeds import SeedManager, rng_from


class CohortMember(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    identity: LearnerAuditIdentity
    b_local_state: LearnerBLocalState


def student_id_for(index: int) -> str:
    """Deterministic id: 1 -> STU-0001 (index is 1-based)."""
    return f"STU-{index:04d}"


def _assign_population(u: float, weights: Tuple[Tuple[str, float], ...]) -> str:
    """Bucket a uniform draw into an ordered (label, weight) cohort split."""
    cumulative = 0.0
    for label, weight in weights:
        cumulative += weight
        if u < cumulative:
            return label
    return weights[-1][0]  # numerical-edge fallback


def build_cohort(config: GeneratorConfig, seed_manager: SeedManager) -> List[CohortMember]:
    members: List[CohortMember] = []
    for i in range(1, config.n_learners + 1):
        student_id = student_id_for(i)
        learner_lineage = seed_manager.learner(student_id)
        rng = rng_from(learner_lineage)

        # Grade first (independent of population), then population (audit-only membership).
        grade = 2 if rng.random() < config.grade_2_fraction else 3
        population = _assign_population(rng.random(), config.population_cohort_weights)

        identity = LearnerAuditIdentity(student_id=student_id, grade=grade, population=population)  # type: ignore[arg-type]
        state = LearnerBLocalState(student_id=student_id, learner_seed=learner_lineage.seed)
        members.append(CohortMember(identity=identity, b_local_state=state))

    return members
