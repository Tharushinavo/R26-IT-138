"""BKT update orchestration for one opportunity (Phase B3.2).

Folds a single opportunity's **first-attempt-only** observation into a learner's per-skill BKT
state, producing a ``SkillMasteryUpdate`` record. Reuses the existing pure
``derive_opportunity_response_summary`` for the observation and the pure ``bkt_predict`` /
``bkt_posterior`` / ``bkt_update`` functions (B3.1) for the math — no new formulas here.

Scope: one opportunity, one skill, no state advancement/persistence across a session (that is a
later slice), no Guess-Guard, no certification, no export to Component C/3.
"""

from __future__ import annotations

from ..behaviour.derivation import derive_opportunity_response_summary
from ..models.behaviour import BOpportunityAttemptResult
from ..models.opportunity import SkillMasteryUpdate
from .config import BBKTConfig
from .state import BBKTSkillState
from .update import bkt_posterior, bkt_predict, bkt_update


class SkillMismatchError(ValueError):
    """Raised when an opportunity's skill does not match the BKT state's skill (fail-closed)."""


def update_skill_mastery(
    state: BBKTSkillState,
    opportunity: BOpportunityAttemptResult,
    config: BBKTConfig,
) -> SkillMasteryUpdate:
    """Fold one opportunity's first-attempt observation into ``state`` and return the update.

    Pure: does not mutate ``state`` (frozen) or ``opportunity``; the caller advances/persists
    state in a later slice. The observation is first-attempt-only — assisted/retry successes on
    attempts >= 2 are never read as extra observations, and a timeout on attempt 1 folds in as
    ``correct=False`` (FROZEN §6.10), both guaranteed by re-deriving the summary from
    ``opportunity.attempts`` via the existing pure ``derive_opportunity_response_summary``.
    """
    summary = derive_opportunity_response_summary(opportunity.attempts)

    if summary.skill_id != state.skill_id:
        raise SkillMismatchError(
            f"opportunity skill {summary.skill_id!r} does not match BKT state skill {state.skill_id!r} "
            "(single-skill only, no cross-skill transfer)"
        )

    params = config.skill_params[state.skill_id]
    first_attempt_correct = summary.first_attempt_correct

    predicted = bkt_predict(state.p_l, params.p_g, params.p_s)
    posterior = bkt_posterior(state.p_l, first_attempt_correct, params.p_g, params.p_s)
    after = bkt_update(state.p_l, first_attempt_correct, params.p_g, params.p_s, params.p_t)

    return SkillMasteryUpdate(
        student_id=state.student_id,
        skill_id=state.skill_id,
        b_session_index=summary.scheduled_session_index,
        generation_phase="B3.2",
        mastery_before=state.p_l,
        predicted_correct_probability=predicted,
        posterior_l=posterior,
        mastery_after=after,
    )
