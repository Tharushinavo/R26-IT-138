"""component_b_generator.bkt

Latent-truth trajectory, estimator-only BKT, guess-guard, certification (SPEC 6.10).

Phase B3.0 — contracts & config: ``BBKTConfig`` / ``SkillBKTParams`` (skill-keyed,
population-neutral) and ``BBKTSkillState`` (immutable per-skill mastery estimate).

Phase B3.1 — pure BKT math: ``bkt_predict`` / ``bkt_posterior`` / ``bkt_update`` (Parameters
§8.1, FROZEN).

Phase B3.2 — update orchestration: ``update_skill_mastery`` folds one opportunity's
first-attempt-only observation into a ``SkillMasteryUpdate`` record (no state persistence).

Phase B3.3 — Guess-Guard: ``evaluate_guess_guard`` / ``plausibility_floor`` /
``guess_guard_triggered_count`` (3-valued status; floor is B-internal, never exported).

Phase B3.4 — certification: ``certify_skill`` (SPEC §A.5, resolved: withheld on thin timing
evidence; not sticky, recomputed each evaluation; not exported to Component C).
"""

from __future__ import annotations

from .certification import certify_skill
from .config import B3_VERSION, BBKTConfig, SkillBKTParams
from .guess_guard import (
    GuessGuardStatus,
    evaluate_guess_guard,
    guess_guard_triggered_count,
    plausibility_floor,
)
from .orchestrator import SkillMismatchError, update_skill_mastery
from .state import BBKTSkillState
from .update import bkt_posterior, bkt_predict, bkt_update

__all__ = [
    "B3_VERSION",
    "BBKTConfig",
    "SkillBKTParams",
    "BBKTSkillState",
    "bkt_predict",
    "bkt_posterior",
    "bkt_update",
    "update_skill_mastery",
    "SkillMismatchError",
    "GuessGuardStatus",
    "plausibility_floor",
    "evaluate_guess_guard",
    "guess_guard_triggered_count",
    "certify_skill",
]
