"""Deterministic mathematical task-instance engine (Phase B2A).

Builds :class:`GeneratedItemInstance` records on top of Phase-B1 ``GeneratedItemOpportunity``
records: sample operands -> recompute correct answer -> equivalents -> distractor candidates
-> run hard guards -> emit a validated instance. Content is seeded from a **task-instance
child lineage** branched off the opportunity seed, so instance content is reproducible and
independent of learner/cohort order.

Unsupported templates are never fabricated: :func:`build_task_instance` raises
``UnsupportedTemplateError``; the batch :func:`generate_task_instances` reports the set of
unimplemented templates it skipped.
"""

from __future__ import annotations

import platform
import subprocess
from datetime import datetime, timezone
from pathlib import Path
from typing import List, Optional, Tuple

from pydantic import BaseModel, ConfigDict

from .. import GENERATOR_PACKAGE_VERSION
from ..answers.registry import ANSWER_REGISTRY_VERSION, allowed_equivalent_answers, correct_answer_raw
from ..answers.rules import normalize_answer
from ..catalogue.loader import catalogue_file_checksum, load_catalogue
from ..config.loader import GeneratorConfig, compute_config_hash, default_b1_config
from ..distractors.registry import DISTRACTOR_REGISTRY_VERSION, generate_distractors
from ..models.catalogue import ItemTemplate, LoadedCatalogue
from ..models.opportunity import GeneratedItemOpportunity
from ..models.task_instance import GeneratedItemInstance, TaskInstanceRunManifest
from ..runner import run_phase_b1
from ..samplers.registry import SAMPLER_REGISTRY_VERSION, get_sampler, supported_template_ids
from ..seeds import derive_child_lineage, rng_from
from .activation import decide_activation
from .coverage import CoverageReport, build_coverage_report
from .errors import TaskInstanceValidationError, UnsupportedTemplateError
from .guards import GUARD_REGISTRY_VERSION, GuardContext, run_guards

PHASE_B2A = "B2A.2"


def build_task_instance(
    opportunity: GeneratedItemOpportunity,
    template: ItemTemplate,
    catalogue_version: str,
    catalogue_status: str,
    catalogue_checksum: str,
) -> GeneratedItemInstance:
    """Build one validated task instance for a supported, active template.

    Raises ``UnsupportedTemplateError`` if no strategy is implemented for the template, and
    ``TaskInstanceValidationError`` if the template is not active for the opportunity's grade
    or any hard guard fails.
    """
    sampler = get_sampler(opportunity.item_template_id)
    if sampler is None:
        raise UnsupportedTemplateError(
            f"no Phase-B2A strategy for template {opportunity.item_template_id!r}"
        )

    decision = decide_activation(template, supported_template_ids(), opportunity.grade, catalogue_status)
    if not decision.active:
        raise TaskInstanceValidationError(f"template not active: {decision.reason}")

    # Content seed = child lineage branched off the opportunity seed (traceable, order-free).
    instance_lineage = derive_child_lineage(opportunity.seed_lineage, "item_instance", "1")
    rng = rng_from(instance_lineage)

    content = sampler.sample(rng, opportunity.grade)
    correct_raw = correct_answer_raw(opportunity.item_template_id, content.operands)
    correct_norm = normalize_answer(correct_raw)
    equivalents = allowed_equivalent_answers(opportunity.item_template_id, content.operands)
    distractors, distractor_rule_ids = generate_distractors(
        opportunity.item_template_id, content.operands, correct_raw,
        required=sampler.required_distractors,
    )

    ctx = GuardContext(
        item_template_id=opportunity.item_template_id,
        task_type=sampler.task_type,
        skill_id=sampler.skill_id,
        grade=opportunity.grade,
        eligible_grades=template.eligible_grades,
        operands=content.operands,
        correct_raw=correct_raw,
        correct_norm=correct_norm,
        distractors=distractors,
    )
    applied_guard_ids = run_guards(sampler.guard_ids, ctx)

    return GeneratedItemInstance(
        item_instance_id=f"{opportunity.item_opportunity_id}-X001",
        item_opportunity_id=opportunity.item_opportunity_id,
        learner_id=opportunity.student_id,
        scheduled_session_index=opportunity.scheduled_session_number,
        item_index=opportunity.item_index,
        item_template_id=opportunity.item_template_id,
        task_type=sampler.task_type,
        skill_id=sampler.skill_id,
        curriculum_node_id=opportunity.curriculum_node_id,
        grade=opportunity.grade,
        difficulty_level=template.difficulty_level,
        representation_type=template.representation_type,
        response_format=sampler.response_format,
        generated_operands=dict(content.operands),
        prompt=dict(content.prompt),
        correct_answer=correct_norm,
        allowed_equivalent_answers=tuple(equivalents),
        distractor_candidates=distractors,
        distractor_rule_ids=distractor_rule_ids,
        generation_seed=instance_lineage.seed,
        seed_lineage=instance_lineage,
        catalogue_version=catalogue_version,
        catalogue_checksum=catalogue_checksum,
        validity_status="VALID",
        applied_guard_ids=applied_guard_ids,
        generation_phase=PHASE_B2A,
    )


def generate_task_instances(
    opportunities: List[GeneratedItemOpportunity],
    catalogue: LoadedCatalogue,
    catalogue_checksum: str,
    strict: bool = False,
) -> Tuple[List[GeneratedItemInstance], Tuple[str, ...], Tuple[str, ...]]:
    """Generate instances for every opportunity whose template is implemented.

    Returns ``(instances, implemented_template_ids, unsupported_template_ids)``. In ``strict``
    mode the first unsupported template raises ``UnsupportedTemplateError`` (no fabrication);
    otherwise unsupported opportunities are skipped and reported (still no fabrication).
    """
    instances: List[GeneratedItemInstance] = []
    implemented: set[str] = set()
    unsupported: set[str] = set()

    for opp in opportunities:
        template = catalogue.by_id(opp.item_template_id)
        if template is None:
            raise TaskInstanceValidationError(f"opportunity references unknown template {opp.item_template_id!r}")
        if get_sampler(opp.item_template_id) is None:
            if strict:
                raise UnsupportedTemplateError(
                    f"no Phase-B2A strategy for template {opp.item_template_id!r}"
                )
            unsupported.add(opp.item_template_id)
            continue
        instances.append(
            build_task_instance(
                opp, template, catalogue.catalogue_version, catalogue.catalogue_status, catalogue_checksum
            )
        )
        implemented.add(opp.item_template_id)

    return instances, tuple(sorted(implemented)), tuple(sorted(unsupported))


# --------------------------------------------------------------------------------------
# Provenance helpers (metadata only)
# --------------------------------------------------------------------------------------


def _python_version() -> str:
    return platform.python_version()


def _git_commit() -> Optional[str]:
    """Best-effort short git commit of the repo; ``None`` when git/checkout is unavailable."""
    try:
        repo_root = Path(__file__).resolve().parents[3]
        out = subprocess.run(
            ["git", "rev-parse", "--short", "HEAD"],
            cwd=str(repo_root),
            capture_output=True,
            text=True,
            timeout=5,
        )
        commit = out.stdout.strip()
        return commit or None
    except Exception:  # pragma: no cover - environment dependent
        return None


def _timestamp_metadata() -> str:
    """UTC ISO-8601 timestamp — provenance metadata ONLY, never used as a seed."""
    return datetime.now(timezone.utc).isoformat()


class PhaseB2AResult(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    manifest: TaskInstanceRunManifest
    item_instances: List[GeneratedItemInstance]
    unsupported_template_ids: Tuple[str, ...]
    coverage: CoverageReport


def run_phase_b2a(
    config: Optional[GeneratorConfig] = None,
    catalogue_path: Path | str | None = None,
    strict: bool = False,
) -> PhaseB2AResult:
    """Full Phase-B2A smoke path: B1 opportunities -> deterministic task instances + manifest."""
    cfg = config or default_b1_config()
    b1 = run_phase_b1(cfg, catalogue_path)
    catalogue = load_catalogue(catalogue_path)
    checksum = catalogue_file_checksum(catalogue.source_path)

    instances, implemented_ids, unsupported_ids = generate_task_instances(
        b1.item_opportunities, catalogue, checksum, strict=strict
    )

    coverage = build_coverage_report(catalogue, supported_template_ids())

    manifest = TaskInstanceRunManifest(
        generation_phase=PHASE_B2A,
        implementation_phase=PHASE_B2A,
        generator_package_version=GENERATOR_PACKAGE_VERSION,
        global_seed=cfg.global_seed,
        config_version=cfg.config_version,
        config_hash=compute_config_hash(cfg),
        smoke_mode=cfg.smoke_mode,
        catalogue_version=catalogue.catalogue_version,
        catalogue_status=catalogue.catalogue_status,
        catalogue_source_path=catalogue.source_path,
        catalogue_checksum=checksum,
        sampler_registry_version=SAMPLER_REGISTRY_VERSION,
        answer_registry_version=ANSWER_REGISTRY_VERSION,
        distractor_registry_version=DISTRACTOR_REGISTRY_VERSION,
        guard_registry_version=GUARD_REGISTRY_VERSION,
        code_version=GENERATOR_PACKAGE_VERSION,
        git_commit=_git_commit(),
        python_version=_python_version(),
        run_timestamp_metadata=_timestamp_metadata(),
        n_item_opportunities=len(b1.item_opportunities),
        n_item_instances=len(instances),
        implemented_template_ids=coverage.implemented_template_ids,  # catalogue-wide (derived)
        unsupported_template_ids=unsupported_ids,  # run-scoped: skipped in THIS smoke run
        catalogue_count=coverage.catalogue_count,
        implemented_count=coverage.implemented_count,
        deferred_count=coverage.deferred_count,
        deferred_template_ids=coverage.deferred_template_ids,
        coverage_summary=tuple((d.template_id, d.coverage_status) for d in coverage.decisions),
    )
    return PhaseB2AResult(
        manifest=manifest,
        item_instances=instances,
        unsupported_template_ids=unsupported_ids,
        coverage=coverage,
    )
