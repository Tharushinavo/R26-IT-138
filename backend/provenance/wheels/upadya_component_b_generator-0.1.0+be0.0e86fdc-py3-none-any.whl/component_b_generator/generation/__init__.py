"""Minimal item-opportunity generation (Phase B1)."""

from __future__ import annotations

from .item_opportunities import (
    SELECTION_REASON_B1,
    build_scheduled_sessions,
    generate_item_opportunities,
)

__all__ = ["generate_item_opportunities", "build_scheduled_sessions", "SELECTION_REASON_B1"]
