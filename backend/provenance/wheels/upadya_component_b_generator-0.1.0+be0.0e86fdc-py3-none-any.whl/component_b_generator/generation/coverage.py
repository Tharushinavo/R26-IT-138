"""Catalogue coverage decision model + report (Phase B2A.2).

Produces a typed, machine-readable coverage decision for **every** authoritative catalogue
template: whether it is implemented (a deterministic sampler/answer/distractor/guard strategy
exists) or deferred (with a reason code + source reference). Counts are **derived** from the
catalogue and the sampler registry — never hardcoded — and the report enforces that every
template id appears exactly once and that implemented + deferred == the catalogue count.

Every non-implemented template has ``activation_allowed = False`` and, because activation also
requires ``implementation_supported`` (a registered sampler), a deferred template cannot become
active merely by existing in the catalogue. This binds coverage status to the runtime activation
policy (fail-closed).
"""

from __future__ import annotations

from typing import Dict, Tuple

from pydantic import BaseModel, ConfigDict

from ..models.catalogue import LoadedCatalogue

_SOURCE_SECTION = "§11 machine-readable catalogue (component_b_item_catalogue.item_sets)"

# Explicit, reviewed deferral decisions for the templates NOT implemented in Phase B2A.2. Every
# non-implemented catalogue template must have an entry here (the report fails closed otherwise),
# so deferral is always a recorded decision — never silent omission.
# template_id -> (coverage_status, decision_code, decision_reason, source_section_detail)
_DEFERRED_DECISIONS: Dict[str, Tuple[str, str, str, str]] = {
    "B-CNT05-FORWARD-FROM-N": (
        "calibration_restricted", "DEFER_CALIBRATION_PENDING",
        "Catalogue node status CALIBRATION_PENDING: count-forward-from-N ranges/thresholds are "
        "unresolved. Not generated until calibrated.",
        "item_sets: B-CNT05-FORWARD-FROM-N (status CALIBRATION_PENDING)",
    ),
    "B-NS01-READ-NUMERAL": (
        "insufficiently_specified", "DEFER_UNDERSPECIFIED",
        "match_numeral_to_number_name requires a deterministic number-name lexicon "
        "(numeral<->written-word rendering) that the authoritative sources do not specify; "
        "deferred rather than invented.",
        "item_sets: B-NS01-READ-NUMERAL (task match_numeral_to_number_name)",
    ),
    "B-NS06-NUMBER-LINE": (
        "calibration_restricted", "DEFER_CALIBRATION_PENDING",
        "Catalogue node status CALIBRATION_PENDING: number-line placement tolerance is unresolved.",
        "item_sets: B-NS06-NUMBER-LINE (status CALIBRATION_PENDING)",
    ),
    "B-PV05-REGROUP-ONES": (
        "insufficiently_specified", "DEFER_UNDERSPECIFIED",
        "regroup_ten_ones is an interactive base-ten exchange (ten ones -> one ten) that is not "
        "specified as deterministic answerable content; deferred.",
        "item_sets: B-PV05-REGROUP-ONES (task regroup_ten_ones)",
    ),
    "B-PV06-UNGROUP-TEN": (
        "insufficiently_specified", "DEFER_UNDERSPECIFIED",
        "ungroup_one_ten is an interactive base-ten exchange (one ten -> ten ones) that is not "
        "specified as deterministic answerable content; deferred.",
        "item_sets: B-PV06-UNGROUP-TEN (task ungroup_one_ten)",
    ),
    "B-SUB02-DIFFERENCE": (
        "calibration_restricted", "DEFER_CALIBRATION_PENDING",
        "Catalogue node status CALIBRATION_PENDING: comparison-difference ranges/thresholds are "
        "unresolved.",
        "item_sets: B-SUB02-DIFFERENCE (status CALIBRATION_PENDING)",
    ),
    "B-DIV04-INVERSE-FACT": (
        "calibration_restricted", "DEFER_CALIBRATION_PENDING",
        "Catalogue node status CALIBRATION_PENDING: multiplication/division fact-family extension "
        "is unresolved.",
        "item_sets: B-DIV04-INVERSE-FACT (status CALIBRATION_PENDING)",
    ),
}

# Recognized coverage statuses (typed vocabulary; a subset is used by Phase B2A.2).
COVERAGE_STATUSES = (
    "implemented",
    "calibration_restricted",
    "insufficiently_specified",
    "grade_restricted",
    "curriculum_restricted",
    "inactive_by_catalogue",
    "deferred",
    "unsupported",
)


class CoverageDecision(BaseModel):
    """Typed coverage decision for one authoritative catalogue template."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    template_id: str
    coverage_status: str
    decision_code: str
    decision_reason: str
    source_file: str
    source_section: str
    implementation_supported: bool
    grade_eligible: bool
    curriculum_eligible: bool
    calibration_status: str
    activation_allowed: bool


class CoverageReport(BaseModel):
    """Full 36-template coverage report with derived, self-consistent counts."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    catalogue_count: int
    implemented_count: int
    deferred_count: int
    implemented_template_ids: Tuple[str, ...]
    deferred_template_ids: Tuple[str, ...]
    decisions: Tuple[CoverageDecision, ...]

    def decision_for(self, template_id: str) -> CoverageDecision:
        for d in self.decisions:
            if d.template_id == template_id:
                return d
        raise KeyError(template_id)


def build_coverage_report(catalogue: LoadedCatalogue, supported_template_ids: Tuple[str, ...]) -> CoverageReport:
    """Derive the coverage decision for every catalogue template from the sampler registry.

    Raises ``ValueError`` if any non-implemented template lacks an explicit deferral decision, or
    if the derived implemented/deferred partition does not exactly cover the catalogue (fail-closed
    so the report can never silently under- or over-count).
    """
    supported = set(supported_template_ids)
    catalogue_ids = {t.item_template_id for t in catalogue.templates}

    unknown_supported = supported - catalogue_ids
    if unknown_supported:
        raise ValueError(f"supported templates not in catalogue: {sorted(unknown_supported)}")
    unknown_deferred = set(_DEFERRED_DECISIONS) - catalogue_ids
    if unknown_deferred:
        raise ValueError(f"deferred decisions reference unknown templates: {sorted(unknown_deferred)}")

    decisions = []
    for template in sorted(catalogue.templates, key=lambda t: t.item_template_id):
        tid = template.item_template_id
        implemented = tid in supported
        grade_eligible = bool(template.eligible_grades)
        curriculum_eligible = template.is_active()
        if implemented:
            status, code, reason, section_detail = (
                "implemented", "IMPLEMENTED_DETERMINISTIC",
                "Deterministic sampler + pure answer rule + mathematical distractors + guards are "
                "registered for this template.",
                f"item_sets: {tid}",
            )
        else:
            if tid not in _DEFERRED_DECISIONS:
                raise ValueError(
                    f"template {tid} is not implemented and has no explicit deferral decision"
                )
            status, code, reason, section_detail = _DEFERRED_DECISIONS[tid]
        decisions.append(
            CoverageDecision(
                template_id=tid,
                coverage_status=status,
                decision_code=code,
                decision_reason=reason,
                source_file=catalogue.source_path,
                source_section=f"{_SOURCE_SECTION} — {section_detail}",
                implementation_supported=implemented,
                grade_eligible=grade_eligible,
                curriculum_eligible=curriculum_eligible,
                calibration_status=template.evidence_status,
                activation_allowed=implemented,  # deferred templates are fail-closed
            )
        )

    implemented_ids = tuple(sorted(d.template_id for d in decisions if d.coverage_status == "implemented"))
    deferred_ids = tuple(sorted(d.template_id for d in decisions if d.coverage_status != "implemented"))
    catalogue_count = len(catalogue.templates)

    # Derived invariants (never assume the expected 29/7 — verify it).
    if len(decisions) != catalogue_count:
        raise ValueError("coverage decisions do not cover every catalogue template exactly once")
    if len(implemented_ids) + len(deferred_ids) != catalogue_count:
        raise ValueError("implemented + deferred count != catalogue count")
    if set(implemented_ids) & set(deferred_ids):
        raise ValueError("a template is both implemented and deferred")

    return CoverageReport(
        catalogue_count=catalogue_count,
        implemented_count=len(implemented_ids),
        deferred_count=len(deferred_ids),
        implemented_template_ids=implemented_ids,
        deferred_template_ids=deferred_ids,
        decisions=tuple(decisions),
    )
