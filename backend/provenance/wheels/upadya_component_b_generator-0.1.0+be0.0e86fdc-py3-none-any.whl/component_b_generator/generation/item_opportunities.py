"""Minimal, deterministic grade-gated item-opportunity generation (SPEC §5, §7) — Phase B1.

Emits the ``b_item_opportunities`` canonical stream only. Attempt simulation, answers,
distractors, errors, hints, BKT, guess-guard, certification, and adaptive sequencing are
later phases — their fields are carried as explicit ``None`` placeholders (never fabricated).

SF-039: the only hard eligibility filter is the **grade gate** (SPEC §7.2). Selection uses a
seeded RNG over a deterministically ordered candidate set; **no** branch on population /
dd_subtype; item count is drawn from a single learner-level distribution (population never
shifts it in B1).
"""

from __future__ import annotations

from typing import List

from ..config.loader import GeneratorConfig
from ..cohort.builder import CohortMember
from ..models.catalogue import LoadedCatalogue
from ..models.opportunity import GeneratedItemOpportunity
from ..models.session import ScheduledSessionContext
from ..seeds import SeedManager, rng_from

SELECTION_REASON_B1 = "phase_b1_seeded_grade_gated_placeholder"


def _draw_item_count(rng, config: GeneratorConfig) -> int:
    """Item count from a single (population-independent) reference distribution.

    Placeholder overlapping distribution for Phase B1 (CALIBRATION_PENDING). Population is
    NOT consulted; once calibrated, population may only *shift* this distribution.
    """
    span = config.item_count_reference_span
    return config.item_count_reference_min + rng.randrange(span)  # [min, min+span-1]


def build_scheduled_sessions(member: CohortMember, config: GeneratorConfig, seeds: SeedManager) -> List[ScheduledSessionContext]:
    """The learner's scheduled B-sessions (Phase B1 assumes every scheduled slot is B-attended)."""
    sid = member.identity.student_id
    grade = member.identity.grade
    sessions: List[ScheduledSessionContext] = []
    for n in range(1, config.scheduled_session_count + 1):
        sessions.append(
            ScheduledSessionContext(
                student_id=sid,
                grade=grade,
                scheduled_session_number=n,
                b_scheduled=True,
                scheduled_session_seed=seeds.scheduled_session(sid, n).seed,
                component_b_session_seed=seeds.component_b_session(sid, n, n).seed,
            )
        )
    return sessions


def generate_item_opportunities(
    catalogue: LoadedCatalogue,
    cohort: List[CohortMember],
    config: GeneratorConfig,
    seeds: SeedManager,
) -> List[GeneratedItemOpportunity]:
    """Generate the ``b_item_opportunities`` stream for the whole cohort, chronologically."""
    opportunities: List[GeneratedItemOpportunity] = []

    # Deterministic learner order (by student_id) — output does not depend on cohort order.
    for member in sorted(cohort, key=lambda m: m.identity.student_id):
        sid = member.identity.student_id
        grade = member.identity.grade
        candidates = catalogue.eligible_for(grade)  # grade-gated, deterministically ordered
        if not candidates:
            raise RuntimeError(f"No grade-{grade}-eligible templates for {sid}; catalogue defect.")

        for session in build_scheduled_sessions(member, config, seeds):
            b_session_index = session.scheduled_session_number  # all scheduled slots attended in B1
            count_rng = rng_from(seeds.component_b_session(sid, session.scheduled_session_number, b_session_index))
            item_count = _draw_item_count(count_rng, config)

            for item_index in range(1, item_count + 1):
                lineage = seeds.item_opportunity(sid, session.scheduled_session_number, b_session_index, item_index)
                pick_rng = rng_from(lineage)
                template = pick_rng.choice(candidates)  # seeded, deterministic; population-independent

                opportunities.append(
                    GeneratedItemOpportunity(
                        item_opportunity_id=f"{sid}-B{b_session_index:03d}-I{item_index:03d}",
                        student_id=sid,
                        grade=grade,
                        scheduled_session_number=session.scheduled_session_number,
                        b_session_index=b_session_index,
                        item_index=item_index,
                        event_order=item_index,
                        item_template_id=template.item_template_id,
                        skill_id=template.skill_id,
                        curriculum_node_id=template.curriculum_node_id,
                        selection_reason_internal=SELECTION_REASON_B1,
                        seed_lineage=lineage,
                    )
                )

    return opportunities
