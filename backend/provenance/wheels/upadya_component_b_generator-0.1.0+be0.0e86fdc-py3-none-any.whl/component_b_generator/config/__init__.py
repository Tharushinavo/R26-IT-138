"""Read-only configuration for the Component B generator (Phase B1)."""

from __future__ import annotations

from .loader import (
    CALIBRATION_PENDING_FIELDS,
    GeneratorConfig,
    compute_config_hash,
    default_b1_config,
)

__all__ = [
    "GeneratorConfig",
    "default_b1_config",
    "compute_config_hash",
    "CALIBRATION_PENDING_FIELDS",
]
