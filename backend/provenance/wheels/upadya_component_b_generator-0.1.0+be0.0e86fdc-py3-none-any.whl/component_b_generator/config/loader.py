"""Read-only generator configuration (Phase B1).

SF-039: this config contains **no** TD/MLD/DD-keyed behaviour selector. The one permitted
population construct is the **cohort composition** control (SF-008 / Population Influence
Register S6) — represented as an ordered ``(label, weight)`` list used ONLY to assign each
learner's audit-only group label, never to drive generation behaviour.

Values not fixed by an approved source are Phase-B1 **smoke placeholders** and are marked
``CALIBRATION_PENDING``. They are NOT the approved per-population operational tables (item
counts, ceilings, etc.), which remain reference priors in the catalogue / B Parameters and
are NON-EXECUTABLE as direct group rules (SF-039).
"""

from __future__ import annotations

import hashlib
import json
from typing import Tuple

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

# Fields whose numeric values are placeholders awaiting calibration.
CALIBRATION_PENDING_FIELDS: Tuple[str, ...] = (
    "grade_2_fraction",
    "item_count_reference_min",
    "item_count_reference_span",
)


class GeneratorConfig(BaseModel):
    """Immutable Phase-B1 generator configuration."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    config_version: str
    global_seed: int
    n_learners: int
    scheduled_session_count: int

    # Explicit smoke-run flag. When True (default), the CALIBRATION_PENDING fields below may use
    # their Phase-B1 engineering placeholders. When False, the caller MUST supply calibrated
    # values for those fields (see the ``_calibrated_values_required_outside_smoke`` validator)
    # so smoke placeholders are never silently promoted to scientific defaults.
    smoke_mode: bool = True

    # Cohort composition control (SF-008 / S6) — audit-only membership sampling, ordered so
    # it never becomes an unordered dict keyed by TD/MLD/DD. NOT a behaviour selector.
    population_cohort_weights: Tuple[Tuple[str, float], ...] = (
        ("TD", 0.70),
        ("MLD", 0.20),
        ("DD", 0.10),
    )

    # --- CALIBRATION_PENDING Phase-B1 smoke placeholders (single distribution for ALL
    #     learners; population never shifts these in B1 and never keys them) ---
    grade_2_fraction: float = Field(
        default=0.5, description="ENGINEERING_ASSUMPTION / CALIBRATION_PENDING (grade-2 share; population-independent)"
    )
    item_count_reference_min: int = Field(
        default=2, description="CALIBRATION_PENDING smoke placeholder — overlapping item-count distribution lower bound"
    )
    item_count_reference_span: int = Field(
        default=3, description="CALIBRATION_PENDING smoke placeholder — overlapping item-count distribution span"
    )

    @field_validator("n_learners")
    @classmethod
    def _n_learners(cls, v: int) -> int:
        if v < 1:
            raise ValueError("n_learners must be >= 1")
        return v

    @field_validator("scheduled_session_count")
    @classmethod
    def _sessions(cls, v: int) -> int:
        if not 1 <= v <= 25:  # SF-014: at most 25 scheduled intervention sessions
            raise ValueError("scheduled_session_count must be in 1..25")
        return v

    @field_validator("grade_2_fraction")
    @classmethod
    def _fraction(cls, v: float) -> float:
        if not 0.0 <= v <= 1.0:
            raise ValueError("grade_2_fraction must be in [0, 1]")
        return v

    @field_validator("item_count_reference_min", "item_count_reference_span")
    @classmethod
    def _nonneg(cls, v: int) -> int:
        if v < 1:
            raise ValueError("item-count reference bounds must be >= 1")
        return v

    @model_validator(mode="after")
    def _calibrated_values_required_outside_smoke(self) -> "GeneratorConfig":
        # Outside a smoke run the caller must consciously supply calibrated values; refusing to
        # run with the exact Phase-B1 engineering placeholders keeps CALIBRATION_PENDING smoke
        # numbers from being mistaken for approved scientific defaults (SF-039).
        if not self.smoke_mode:
            is_placeholder = (
                abs(self.grade_2_fraction - 0.5) < 1e-9
                and self.item_count_reference_min == 2
                and self.item_count_reference_span == 3
            )
            if is_placeholder:
                raise ValueError(
                    "smoke_mode=False requires caller-supplied calibrated values for "
                    f"{CALIBRATION_PENDING_FIELDS}; the Phase-B1 smoke placeholders "
                    "(grade_2_fraction=0.5, item_count_reference_min=2, item_count_reference_span=3) "
                    "must not be promoted to scientific defaults."
                )
        return self

    @model_validator(mode="after")
    def _weights_sum_to_one(self) -> "GeneratorConfig":
        total = sum(w for _, w in self.population_cohort_weights)
        if abs(total - 1.0) > 1e-9:
            raise ValueError(f"population_cohort_weights must sum to 1.0, got {total}")
        labels = [lbl for lbl, _ in self.population_cohort_weights]
        if labels != ["TD", "MLD", "DD"]:
            raise ValueError("population_cohort_weights must be exactly TD, MLD, DD in that order")
        return self


def default_b1_config(global_seed: int = 20260716, n_learners: int = 8, scheduled_session_count: int = 3) -> GeneratorConfig:
    """A small deterministic Phase-B1 smoke configuration (5–10 learners recommended)."""
    return GeneratorConfig(
        config_version="b1-smoke-0.1.0",
        global_seed=int(global_seed),
        n_learners=int(n_learners),
        scheduled_session_count=int(scheduled_session_count),
    )


def compute_config_hash(config: GeneratorConfig) -> str:
    """Stable SHA-256 over the canonical config (reproducibility provenance, SPEC §8)."""
    payload = json.dumps(config.model_dump(), sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()
