"""Phase-B1 smoke runner (SPEC §5 minimal path).

Loads the authoritative catalogue, builds a small deterministic cohort, generates the
``b_item_opportunities`` stream, and returns them with a reproducibility manifest. Emits
**no** B->C / B->3 boundary payloads (those are derived by later ``adapters/``).
"""

from __future__ import annotations

from pathlib import Path
from typing import List, Optional

from pydantic import BaseModel, ConfigDict

from . import GENERATOR_PACKAGE_VERSION, PHASE
from .audits.population_neutrality import scan_source_for_population_branching
from .catalogue.loader import load_catalogue
from .cohort.builder import CohortMember, build_cohort
from .config.loader import GeneratorConfig, compute_config_hash, default_b1_config
from .generation.item_opportunities import generate_item_opportunities
from .models.manifest import GeneratorRunManifest
from .models.opportunity import GeneratedItemOpportunity
from .seeds import SeedManager


class PhaseB1Result(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    manifest: GeneratorRunManifest
    cohort: List[CohortMember]
    item_opportunities: List[GeneratedItemOpportunity]


def run_phase_b1(config: Optional[GeneratorConfig] = None, catalogue_path: Path | str | None = None) -> PhaseB1Result:
    cfg = config or default_b1_config()
    seeds = SeedManager(cfg.global_seed)

    catalogue = load_catalogue(catalogue_path)
    cohort = build_cohort(cfg, seeds)
    opportunities = generate_item_opportunities(catalogue, cohort, cfg, seeds)

    populations_present = tuple(sorted({m.identity.population for m in cohort}))
    manifest = GeneratorRunManifest(
        generation_phase=PHASE,
        generator_package_version=GENERATOR_PACKAGE_VERSION,
        global_seed=cfg.global_seed,
        config_version=cfg.config_version,
        config_hash=compute_config_hash(cfg),
        catalogue_version=catalogue.catalogue_version,
        catalogue_status=catalogue.catalogue_status,
        catalogue_source_path=catalogue.source_path,
        n_learners=len(cohort),
        scheduled_session_count=cfg.scheduled_session_count,
        n_item_opportunities=len(opportunities),
        populations_present=populations_present,
    )
    return PhaseB1Result(manifest=manifest, cohort=cohort, item_opportunities=opportunities)


def selfcheck() -> None:
    """Convenience: run a smoke generation and assert the SF-039 source scan is clean."""
    offenders = scan_source_for_population_branching()
    if offenders:
        raise AssertionError("Forbidden population-conditioned constructs found:\n" + "\n".join(offenders))
    run_phase_b1()


if __name__ == "__main__":  # pragma: no cover
    result = run_phase_b1()
    m = result.manifest
    print(
        f"[Phase {m.generation_phase}] learners={m.n_learners} "
        f"item_opportunities={m.n_item_opportunities} "
        f"catalogue={m.catalogue_version} seed={m.global_seed} config_hash={m.config_hash[:12]}…"
    )
    print(m.disclosure)
