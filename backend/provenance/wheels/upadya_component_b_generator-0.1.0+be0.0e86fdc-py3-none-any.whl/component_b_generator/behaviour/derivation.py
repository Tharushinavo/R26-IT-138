"""Phase B2B.0 pure opportunity-response derivation (spec §24, §8).

:func:`derive_opportunity_response_summary` folds a set of validated observable
:class:`BAttemptEvent` rows for a *single* item opportunity into one
:class:`BOpportunityResponseSummary`. It is a **pure function of the events**:

- it consumes attempt events only (never :class:`BLearnerSkillTruth`);
- it uses no randomness, no BKT, no ``population``/``dd_subtype``, no future information;
- it validates chronology deterministically and is independent of input order;
- every summary field is *derived* from the events — no summary value may be supplied.

It performs no event generation and no session-level aggregation.
"""

from __future__ import annotations

from typing import Sequence

from ..models.behaviour import (
    OPPORTUNITY_SUMMARY_SCHEMA_VERSION,
    BAttemptEvent,
    BOpportunityResponseSummary,
)

B2B_DERIVATION_VERSION = "b2b0-1.0.0"

# Shared-identity fields: every event in one opportunity must agree on these.
_SHARED_KEYS = (
    "learner_id",
    "session_id",
    "scheduled_session_index",
    "item_opportunity_id",
    "task_instance_id",
    "item_template_id",
    "skill_id",
)


class OpportunityDerivationError(ValueError):
    """Raised when a set of attempt events cannot form one coherent opportunity summary."""


def derive_opportunity_response_summary(
    events: Sequence[BAttemptEvent],
) -> BOpportunityResponseSummary:
    """Derive the opportunity-response summary from one opportunity's attempt events."""
    if not events:
        raise OpportunityDerivationError("no attempt events provided")
    if any(not isinstance(e, BAttemptEvent) for e in events):
        raise OpportunityDerivationError("all inputs must be BAttemptEvent instances")

    # Single coherent opportunity: every shared-identity field must match across events.
    first = events[0]
    for key in _SHARED_KEYS:
        expected = getattr(first, key)
        if any(getattr(e, key) != expected for e in events):
            raise OpportunityDerivationError(f"attempt events disagree on {key!r} (mixed opportunity)")

    # One schema version across the events (provenance for the derived record).
    schema_versions = {e.schema_version for e in events}
    if len(schema_versions) != 1:
        raise OpportunityDerivationError(f"attempt events span multiple schema versions: {sorted(schema_versions)}")

    # Chronology: attempt indices must be exactly 1..n, unique, no gaps (order-independent).
    ordered = sorted(events, key=lambda e: e.attempt_index)
    indices = [e.attempt_index for e in ordered]
    n = len(ordered)
    if indices != list(range(1, n + 1)):
        raise OpportunityDerivationError(
            f"attempt indices must be exactly 1..{n} with no gaps or duplicates, got {indices}"
        )

    first_attempt = ordered[0]
    final_attempt = ordered[-1]

    # A hint is only "used" when it was actually PRESENTED. A request that was never presented
    # still sets hint_requested (evidence of help-seeking) but must NOT make completion assisted.
    hint_count = sum(1 for e in ordered if e.hint_level_presented is not None)
    final_item_completed = bool(final_attempt.attempt_completed and final_attempt.correct)
    assisted_completion = final_item_completed and hint_count > 0
    unassisted_completion = final_item_completed and hint_count == 0

    return BOpportunityResponseSummary(
        learner_id=first.learner_id,
        session_id=first.session_id,
        scheduled_session_index=first.scheduled_session_index,
        item_opportunity_id=first.item_opportunity_id,
        task_instance_id=first.task_instance_id,
        item_template_id=first.item_template_id,
        skill_id=first.skill_id,
        first_attempt_correct=first_attempt.correct,
        first_attempt_error_pattern=first_attempt.supported_error_pattern,
        total_attempts=n,
        retry_count=max(n - 1, 0),
        hint_requested=any(e.hint_requested for e in ordered),
        hint_count=hint_count,
        final_item_completed=final_item_completed,
        assisted_completion=assisted_completion,
        unassisted_completion=unassisted_completion,
        total_response_time_ms=sum(e.response_time_ms for e in ordered),
        first_attempt_response_time_ms=first_attempt.response_time_ms,
        final_submitted_answer=final_attempt.submitted_answer,
        derivation_version=B2B_DERIVATION_VERSION,
        source_event_schema_version=next(iter(schema_versions)),
    )
