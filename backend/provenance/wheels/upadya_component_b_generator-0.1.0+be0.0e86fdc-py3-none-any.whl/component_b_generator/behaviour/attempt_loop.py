"""Phase B2B.3.3 — retry/exit decision + termination classification (pure helpers only).
Phase B2B.3.4 — the bounded-opportunity orchestrator (``generate_opportunity_attempts``), which
composes the B2B.3.1-.3 building blocks into the full chronology and returns exactly one
``BOpportunityAttemptResult`` per (task_instance, learner_truth) opportunity.

Two pure, deterministic decision/classification functions (``_retry_or_exit``,
``_classify_termination``) plus the public orchestrator that wires them together with
``_generate_attempt_outcome``/``_assemble_attempt_event`` (Phase B2B.3.2) and
``get_catalogue_hint`` (Phase B2B.3.1). Neither decision helper generates an attempt, assembles an
event, or runs the loop itself — ``generate_opportunity_attempts`` is the only place those are
composed.

Both decision helpers are trait-only and population-neutral: they read the caller-supplied
``BAttemptLoopConfig`` and the learner's audit-only B2B.1 truth traits (``retry_persistence``,
``completion_persistence``); they never read ``population``/``dd_subtype``. The orchestrator
itself reuses the frozen ``compute_first_attempt_correct_probability`` (via
``_generate_attempt_outcome``) with an unmutated ``learner_truth.true_mastery_before`` on every
attempt — it performs no mastery mutation, no BKT, and no hidden growth.

--------------------------------------------------------------------------------------
SPEC §C.2 compatibility note — compact rows <-> lifecycle grammar (recorded before the
B2B.3.4 freeze, per the roadmap plan §C.2; this is the required note, not a spec amendment).
--------------------------------------------------------------------------------------

- **Submission + evaluation -> one attempt row.** Each ``BAttemptEvent`` is exactly one
  ``{present -> submit -> evaluate}`` cycle: ``submitted_answer``/``normalized_submitted_answer``
  is the submission; ``correct``/``supported_error_pattern``/``attempt_completed`` is the
  evaluation; a timeout is a null submission evaluated ``correct=False,
  supported_error_pattern="timeout_no_response"``.
- **Hint fields on attempt k = post-evaluation help.** ``hint_requested``/``hint_level_presented``
  on attempt ``k`` represent help sought *after* ``k``'s unsuccessful evaluation and *before* the
  retry/exit decision — exactly the order ``generate_opportunity_attempts`` implements below (hint
  decision, then retry/exit decision, then the loop either continues to ``k+1`` or terminates).
  They are the projection of the lifecycle "hint" event onto its triggering attempt; there is no
  separate hint event row.
- **Retry k+1 linked to k** by ``attempt_index == k+1`` plus an identical ``item_opportunity_id``
  (``BOpportunityAttemptResult``'s result-invariant validator enforces consecutive ``1..n``).
- **Exactly one presentation + one terminal.** ``generate_opportunity_attempts`` emits exactly one
  ordered ``attempts`` tuple per opportunity; ``termination_reason`` is single-valued; the result
  validator requires the *final* attempt to match the terminal (correct => completed; else => not
  completed; ``timeout_terminated`` => a timeout final attempt).
- **No attempt after termination**: attempt indices are exactly ``1..n``, the terminal is always
  ``attempts[-1]``, and the loop below ``return``s immediately once a terminal branch is taken —
  there is no code path that appends another attempt afterward.
- **Amendment status:** this compatibility note (recorded here, in the module implementing the
  orchestrator, and standing in for a build-log entry) is sufficient. **No full spec amendment is
  needed** — the compact ``BAttemptEvent`` model was already approved as design decision D1, and
  this note only documents how that compact model maps onto the ``{present, submit, evaluate,
  hint, retry}`` lifecycle grammar; it changes no field, no schema, and no validator.
"""

from __future__ import annotations

import random
from typing import List

from ..catalogue.loader import catalogue_file_checksum, load_catalogue
from ..models.behaviour import (
    B2B_ATTEMPT_LOOP_VERSION,
    OPPORTUNITY_RESULT_SCHEMA_VERSION,
    BAttemptEvent,
    BAttemptLoopConfig,
    BInitialLearnerSkillTruth,
    BOpportunityAttemptResult,
    TerminationReason,
)
from ..models.session import SeedLineage
from ..models.task_instance import GeneratedItemInstance
from .derivation import derive_opportunity_response_summary
from .first_attempt import (
    AttemptOutcome,
    _assemble_attempt_event,
    _generate_attempt_outcome,
    _hint_level_for_unsuccessful,
    _hint_request_decision,
)
from .hints import get_catalogue_hint
from .seeds import (
    attempt_lineage,
    hint_decision_lineage,
    response_process_lineage,
    retry_decision_lineage,
)


def _retry_or_exit(
    config: BAttemptLoopConfig,
    learner_truth: BInitialLearnerSkillTruth,
    retry_lineage: SeedLineage,
) -> bool:
    """Deterministic Bernoulli retry-vs-exit decision (trait-only, population-neutral).

    ``p_retry = clamp(retry_base + retry_persistence_weight*retry_persistence
                       - completion_persistence_weight*(1 - completion_persistence), 0, 1)``,
    drawn from the independent ``retry_decision`` seed domain
    (``behaviour.seeds.retry_decision_lineage``). ``True`` = retry (continue to the next attempt);
    ``False`` = voluntary exit.

    A hint request never forces a retry: this decision is independent of hint state and does not
    read ``hint_requested``/``hint_level_presented`` at all. Reads only the explicit config and the
    learner's audit-only ``retry_persistence``/``completion_persistence`` traits — never
    population/dd_subtype.
    """
    p = (
        config.retry_base
        + config.retry_persistence_weight * learner_truth.retry_persistence
        - config.completion_persistence_weight * (1.0 - learner_truth.completion_persistence)
    )
    p = min(1.0, max(0.0, p))
    return random.Random(retry_lineage.seed).random() < p


def _classify_termination(
    final_outcome: AttemptOutcome,
    exited: bool,
    config: BAttemptLoopConfig,
) -> TerminationReason:
    """Classify the terminal attempt into exactly one committed ``TerminationReason``.

    Must be called only on the attempt after which the bounded loop actually stops. Priority
    order (mirrors ``BOpportunityAttemptResult``'s result-invariant validator):

    1. ``final_outcome.correct`` -> ``"correct_response"`` (a correct answer always halts the
       loop and completes the opportunity).
    2. a timeout final attempt, when ``config.timeout_terminates_opportunity`` is set ->
       ``"timeout_terminated"``.
    3. ``final_outcome.attempt_index >= config.max_attempts`` -> ``"max_attempts_exhausted"`` (no
       attempts remain — decisive regardless of what the retry decision would have been).
    4. otherwise, ``exited`` (the learner chose not to retry, with attempts still remaining) ->
       ``"voluntary_exit"``.

    Raises ``ValueError`` if none of these hold: a non-correct, non-terminating-timeout final
    attempt with attempts still remaining and ``exited=False`` is not actually terminal — the loop
    should have continued to another attempt instead of calling this classifier.
    """
    if final_outcome.correct:
        return "correct_response"
    if final_outcome.supported_error_pattern == "timeout_no_response" and config.timeout_terminates_opportunity:
        return "timeout_terminated"
    if final_outcome.attempt_index >= config.max_attempts:
        return "max_attempts_exhausted"
    if exited:
        return "voluntary_exit"
    raise ValueError(
        "not a terminal attempt: non-correct, non-terminating-timeout, attempts remain "
        "(attempt_index < max_attempts), and the learner did not exit — the loop should have "
        "continued to another attempt instead of classifying termination here"
    )


# ======================================================================================
# Phase B2B.3.4 — the bounded-opportunity orchestrator.
# ======================================================================================


def generate_opportunity_attempts(
    task_instance: GeneratedItemInstance,
    learner_truth: BInitialLearnerSkillTruth,
    config: BAttemptLoopConfig,
    session_id: str,
) -> BOpportunityAttemptResult:
    """Generate the full bounded attempt sequence for one item opportunity.

    Composes the existing B2B.3.1-.3 building blocks (it does not reimplement any of them):
    ``_generate_attempt_outcome`` for each attempt's latency/correctness/answer/error-pattern,
    ``_hint_request_decision`` + ``_hint_level_for_unsuccessful`` + ``get_catalogue_hint`` for
    post-evaluation help, ``_retry_or_exit`` for the continue-vs-stop decision,
    ``_assemble_attempt_event`` to build each frozen row, ``derive_opportunity_response_summary``
    for the pure summary, and ``_classify_termination`` for the single control-flow reason.

    Per attempt ``k = 1..config.max_attempts``, in canonical precedence:

    1. ``correct`` -> assemble (no hint), terminal ``correct_response``.
    2. a timeout with ``config.timeout_terminates_opportunity`` -> assemble (no hint), terminal
       ``timeout_terminated`` (this preempts the max-attempts check even when ``k`` is the last
       attempt).
    3. ``k == config.max_attempts`` (non-correct) -> assemble (no hint), terminal
       ``max_attempts_exhausted``.
    4. otherwise (``k < max_attempts``, non-correct, non-terminating timeout): decide whether to
       present a hint (``min(k, 3)``, fail-closed via ``get_catalogue_hint`` if the catalogue
       content is missing), assemble the attempt with whatever hint fields resulted, then decide
       retry vs. exit — retry continues to ``k+1``; exit terminates ``voluntary_exit``.

    Reuses the frozen correctness model with **unmutated** ``learner_truth.true_mastery_before``
    on every attempt (no mastery mutation, no BKT, no hidden growth — ``learner_truth`` is only
    ever read). ``assisted_completion`` is derived, provenance-only, by
    ``derive_opportunity_response_summary`` from whether any presented hint preceded a completed
    opportunity — never asserted or forced here. Population/dd_subtype are never read anywhere in
    this function. Runs only on an already-activated ``task_instance``; a deferred/unimplemented
    template fails closed inside ``_generate_attempt_outcome`` (``UnsupportedTemplateError``)
    before any hint is ever requested for it.
    """
    catalogue = load_catalogue()
    catalogue_checksum = catalogue_file_checksum(catalogue.source_path)

    response_process = response_process_lineage(task_instance.seed_lineage)
    first_attempt_config = config.first_attempt_config

    events: List[BAttemptEvent] = []
    exclude: set = set()
    exited = False
    final_outcome: AttemptOutcome

    for k in range(1, config.max_attempts + 1):
        attempt = attempt_lineage(response_process, k)
        outcome = _generate_attempt_outcome(
            task_instance, learner_truth, first_attempt_config, session_id, attempt, k,
            exclude=(exclude if config.avoid_repeat_wrong_answers else None),
        )
        final_outcome = outcome
        if not outcome.correct and outcome.normalized_submitted_answer is not None:
            exclude.add(outcome.normalized_submitted_answer)

        is_timeout = outcome.supported_error_pattern == "timeout_no_response"

        # Precedence 1-3: terminal without any hint decision.
        if outcome.correct or (is_timeout and config.timeout_terminates_opportunity) or k == config.max_attempts:
            events.append(_assemble_attempt_event(outcome, hint_requested=False, hint_level=None))
            break

        # Precedence 4: k < max_attempts, non-correct, non-terminating timeout.
        hint_requested = False
        hint_level = None
        wants_hint = _hint_request_decision(
            config, learner_truth.help_seeking_tendency, hint_decision_lineage(attempt)
        )
        if wants_hint:
            level = _hint_level_for_unsuccessful(k)
            # Fail-closed: a missing/blank catalogue hint raises HintContentError, which
            # propagates uncaught (no generated fallback, no silent skip).
            get_catalogue_hint(catalogue, catalogue_checksum, task_instance.item_template_id, level)
            hint_requested = True
            hint_level = level

        events.append(_assemble_attempt_event(outcome, hint_requested=hint_requested, hint_level=hint_level))

        retry = _retry_or_exit(config, learner_truth, retry_decision_lineage(attempt))
        if not retry:
            exited = True
            break
        # else: retry -> the `for` loop continues to attempt k+1.

    summary = derive_opportunity_response_summary(events)
    termination_reason = _classify_termination(final_outcome, exited=exited, config=config)

    return BOpportunityAttemptResult(
        attempts=tuple(events),
        summary=summary,
        termination_reason=termination_reason,
        generator_version=B2B_ATTEMPT_LOOP_VERSION,
        schema_version=OPPORTUNITY_RESULT_SCHEMA_VERSION,
        config_version=config.config_version,
        catalogue_version=catalogue.catalogue_version,
        catalogue_checksum=catalogue_checksum,
        seed_lineage=task_instance.seed_lineage,
    )
