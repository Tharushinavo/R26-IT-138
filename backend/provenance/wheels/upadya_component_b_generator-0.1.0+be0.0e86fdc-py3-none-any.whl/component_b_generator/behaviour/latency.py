"""Phase B2B.2 — first-attempt response-time (latency) generation (pure).

Deterministic positively-skewed (lognormal) latency from a caller-supplied explicit spec and the
learner's audit-only speed traits, seeded from the B2B ``latency`` domain. A draw above the
configured timeout threshold is a timeout/no-response; otherwise it is clamped to the explicit
bounds and rounded to a non-negative integer millisecond. No population, no estimator input, no
item difficulty, no global RNG, no timestamps. Numeric parameters are CALIBRATION_PENDING and are
supplied by the caller — none are invented here.
"""

from __future__ import annotations

import math
import random
from typing import NamedTuple

from ..models.behaviour import LognormalLatencySpec

B2B_LATENCY_MODEL_VERSION = "b2b2-1.0.0"


class LatencyOutcome(NamedTuple):
    response_time_ms: int   # observable, non-negative integer
    is_timeout: bool        # True => no-response (raw draw exceeded the timeout threshold)
    raw_ms: float           # raw sampled latency (audit-side; NOT placed on the observable event)


def generate_latency(
    spec: LognormalLatencySpec,
    response_speed_tendency: float,
    response_speed_variability: float,
    latency_seed: int,
) -> LatencyOutcome:
    """Deterministically sample one first-attempt latency outcome from the latency seed."""
    rng = random.Random(latency_seed)  # local RNG only; global state untouched
    z = rng.normalvariate(0.0, 1.0)

    # Higher speed tendency => lower log-location => faster. Higher variability => wider spread.
    mu_eff = spec.location_mu - spec.speed_tendency_weight * response_speed_tendency
    sigma_eff = spec.scale_sigma * (1.0 + spec.variability_weight * response_speed_variability)
    raw_ms = math.exp(mu_eff + sigma_eff * z)

    if raw_ms > spec.timeout_threshold_ms:
        # Timeout/no-response: the learner waited until the max-time rule was met.
        return LatencyOutcome(response_time_ms=int(spec.timeout_threshold_ms), is_timeout=True, raw_ms=raw_ms)

    clamped = min(max(raw_ms, float(spec.floor_ms)), float(spec.cap_ms))
    return LatencyOutcome(response_time_ms=int(round(clamped)), is_timeout=False, raw_ms=raw_ms)
