"""Phase B2B.0 observable serialization boundary (spec §10, §22, §23).

The only records that may cross an observable / deployable boundary are :class:`BAttemptEvent`
and :class:`BOpportunityResponseSummary`. This module enforces that **fail-closed**:

- audit-only records (:class:`AuditOnlyModel`, e.g. :class:`BLearnerSkillTruth`) are refused by
  **type** — they can never be serialized through the observable path by accident;
- the resulting mapping is checked against an explicit **forbidden-key allow-list gate**, so a
  ``population`` / ``dd_subtype`` / hidden-truth / BKT / future-outcome key is rejected rather
  than silently stripped.

Nothing here generates behaviour. It only guards serialization.
"""

from __future__ import annotations

from typing import Any, Mapping

from pydantic import BaseModel

from ..models.behaviour import (
    AuditOnlyModel,
    BAttemptEvent,
    BOpportunityResponseSummary,
)

# Keys that must NEVER appear in an observable/deployable payload (spec §10). This is a
# defence-in-depth gate on top of the strict ``extra="forbid"`` models: even a hand-built dict
# containing any of these is rejected.
FORBIDDEN_OBSERVABLE_KEYS = frozenset(
    {
        # audit-only labels
        "population",
        "dd_subtype",
        # hidden simulation truth
        "true_mastery_before",
        "true_mastery_after",
        "behavioural_slip_tendency",
        "behavioural_guess_tendency",
        "response_speed_tendency",
        "response_speed_variability",
        "careless_error_tendency",
        "help_seeking_tendency",
        "retry_persistence",
        "completion_persistence",
        "behaviour_consistency",
        # estimator-side (B3) fields
        "bkt_mastery_prior",
        "bkt_mastery_posterior",
        "bkt_predicted_correct_probability",
        "mastery_certified",
        "guess_guard_triggered",
        # downstream / future
        "future_outcome",
        "risk_label",
    }
)

# The only model types permitted through the observable serializer.
_OBSERVABLE_TYPES = (BAttemptEvent, BOpportunityResponseSummary)


class ObservableSerializationError(ValueError):
    """Raised when a record or mapping is not safe to cross an observable boundary."""


def assert_observable_safe(data: Mapping[str, Any]) -> None:
    """Fail closed if a mapping contains any forbidden observable key."""
    if not isinstance(data, Mapping):
        raise ObservableSerializationError("observable payload must be a mapping")
    offending = sorted(set(data.keys()) & FORBIDDEN_OBSERVABLE_KEYS)
    if offending:
        raise ObservableSerializationError(f"forbidden observable field(s): {offending}")


def to_observable_dict(model: BaseModel) -> dict[str, Any]:
    """Serialize an observable model to a plain dict, fail-closed.

    Refuses audit-only records by type (never by post-hoc field deletion), refuses any model
    that is not an approved observable type, and re-checks the emitted keys against the
    forbidden-key gate. Version/schema fields are preserved.
    """
    if isinstance(model, AuditOnlyModel):
        raise ObservableSerializationError(
            f"{type(model).__name__} is audit-only and must never be serialized to an observable payload"
        )
    if not isinstance(model, _OBSERVABLE_TYPES):
        raise ObservableSerializationError(
            f"{type(model).__name__} is not an approved observable record type"
        )
    data = model.model_dump()
    assert_observable_safe(data)  # defence in depth (strict models already exclude these)
    return data
