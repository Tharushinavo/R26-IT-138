"""Phase B2B.1 — population-neutral learner-truth initialization (audit-only).

Pure, deterministic construction of :class:`BInitialLearnerSkillTruth` records from an explicit,
versioned :class:`BTruthInitializationConfig`. Each learner x skill x trait value is sampled from
its **own** independent seed domain (spec §25; §12), so traits are mutually independent and
skill/learner/registry order never affects a value.

This module initializes **truth only** — it generates no learner responses, correctness, timing,
hints, retries, completion, attempt events, mastery progression, or BKT. Population / dd_subtype
are never inputs: the API accepts only B-local identifiers, a learner seed lineage, and the config.
``fixed_hidden_growth_g`` is configuration and is **not applied** here (initial before == after).
"""

from __future__ import annotations

from typing import Tuple

from models.contracts import SKILLS  # canonical seven-skill order (single source of truth)

from ..models.behaviour import BInitialLearnerSkillTruth, BTruthInitializationConfig
from ..models.session import SeedLineage
from ..seeds import rng_from
from .seeds import skill_truth_lineage, trait_lineage, truth_initialization_lineage

B2B_TRUTH_INITIALIZATION_VERSION = "b2b1-1.0.0"

# Trait field on the config/record  <->  its independent seed domain name.
# (Mastery uses the "true_mastery" seed domain; the config field is ``initial_true_mastery``.)
_TRAIT_TO_DOMAIN = {
    "behavioural_slip_tendency": "behavioural_slip_tendency",
    "behavioural_guess_tendency": "behavioural_guess_tendency",
    "response_speed_tendency": "response_speed_tendency",
    "response_speed_variability": "response_speed_variability",
    "careless_error_tendency": "careless_error_tendency",
    "help_seeking_tendency": "help_seeking_tendency",
    "retry_persistence": "retry_persistence",
    "completion_persistence": "completion_persistence",
    "behaviour_consistency": "behaviour_consistency",
}


def initialize_learner_skill_truth(
    learner_id: str,
    learner_lineage: SeedLineage,
    skill_id: str,
    config: BTruthInitializationConfig,
) -> BInitialLearnerSkillTruth:
    """Initialize one learner's audit-only initial truth for a single skill (deterministic, pure).

    ``learner_lineage`` is the learner's seed lineage (e.g. ``SeedManager(seed).learner(id)``); the
    function accepts no population / dd_subtype and reads no external audit labels.
    """
    skill_root = skill_truth_lineage(truth_initialization_lineage(learner_lineage), skill_id)

    # Initial true mastery from its own "true_mastery" domain; no growth applied (before==after).
    mastery = config.initial_true_mastery.sample(rng_from(trait_lineage(skill_root, "true_mastery")))

    # Each behavioural trait from its own independent domain (order-independent).
    trait_values = {
        field: getattr(config, field).sample(rng_from(trait_lineage(skill_root, domain)))
        for field, domain in _TRAIT_TO_DOMAIN.items()
    }

    return BInitialLearnerSkillTruth(
        learner_id=learner_id,
        skill_id=skill_id,
        true_mastery_initial=mastery,
        true_mastery_before=mastery,
        true_mastery_after=mastery,
        truth_parameter_version=config.parameter_source_status,
        initialization_version=B2B_TRUTH_INITIALIZATION_VERSION,
        config_version=config.initialization_version,
        seed_lineage=skill_root,
        **trait_values,
    )


def initialize_learner_truth_for_all_skills(
    learner_id: str,
    learner_lineage: SeedLineage,
    config: BTruthInitializationConfig,
) -> Tuple[BInitialLearnerSkillTruth, ...]:
    """Initialize all seven skills for one learner, in canonical skill order (exactly seven records)."""
    return tuple(
        initialize_learner_skill_truth(learner_id, learner_lineage, skill_id, config)
        for skill_id in SKILLS
    )
