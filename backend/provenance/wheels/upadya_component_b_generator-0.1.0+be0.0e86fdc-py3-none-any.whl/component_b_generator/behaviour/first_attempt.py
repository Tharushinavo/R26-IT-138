"""Phase B2B.2 — first-attempt behaviour generation (one observable event per task instance).
Phase B2B.3.2 — attempt-outcome refactor (reusable across attempt indices) + hint-request
decision + the frozen §5.7 hint-level rule.

Given a validated B2A.2 :class:`GeneratedItemInstance` and the learner's audit-only truth, this
produces one attempt's behavioural outcome: latency, then (unless a timeout) a Bernoulli
correctness draw from the frozen correctness model, then a canonical correct answer or a
validated wrong answer, with an evidence-gated error pattern. Assembling that outcome into a
frozen :class:`BAttemptEvent` (with or without hint fields) is a separate, reusable step so later
slices (retry/exit, orchestration) can generate attempt_index > 1 outcomes and attach hint
presentation without duplicating this logic.

Strict boundaries: reads current hidden truth but **never mutates** it; applies **no** hidden
growth; produces **no** retries, completion orchestration, mastery progression, or estimator-side
updates. No population, no population-subtype, and no item-difficulty inputs; no global RNG; no
timestamps. The hint-request decision is trait-only (``help_seeking_tendency``) and never reads
population/dd_subtype.
"""

from __future__ import annotations

import random
from typing import NamedTuple, Optional

from ..answers.rules import normalize_answer
from ..generation.errors import UnsupportedTemplateError
from ..models.behaviour import (
    ATTEMPT_EVENT_SCHEMA_VERSION,
    BAttemptEvent,
    BAttemptLoopConfig,
    BFirstAttemptBehaviourConfig,
    BInitialLearnerSkillTruth,
    ErrorPattern,
)
from ..models.session import SeedLineage
from ..models.task_instance import GeneratedItemInstance
from ..samplers.registry import get_sampler
from .latency import generate_latency
from .seeds import (
    attempt_lineage,
    correctness_decision_lineage,
    latency_lineage,
    response_process_lineage,
    submitted_response_lineage,
)
from .wrong_answers import generate_typed_wrong_answer, select_mc_wrong_answer

B2B_FIRST_ATTEMPT_GENERATOR_VERSION = "b2b2-1.0.0"

# Frozen SPEC §5.7 hint-level rule cap: level presented never exceeds L3.
_HINT_LEVEL_CAP = 3


def compute_first_attempt_correct_probability(
    true_mastery: float,
    behavioural_slip: float,
    behavioural_guess: float,
) -> float:
    """Frozen correctness model (pure; no sampling):

    ``P(correct) = true_mastery*(1 - slip) + (1 - true_mastery)*guess``, clamped to ``[0, 1]``.
    Uses hidden true mastery only — never estimator mastery, item difficulty, population, or
    population subtype.
    """
    p = true_mastery * (1.0 - behavioural_slip) + (1.0 - true_mastery) * behavioural_guess
    return min(1.0, max(0.0, p))


def _sample_correct(probability: float, seed: int) -> bool:
    """Deterministic Bernoulli draw from the correctness-decision seed (local RNG only)."""
    return random.Random(seed).random() < probability


# ======================================================================================
# Phase B2B.3.2 — reusable attempt-outcome building blocks.
# ======================================================================================


class AttemptOutcome(NamedTuple):
    """One attempt's fully-generated behavioural outcome, minus hint presentation.

    Carries every field ``BAttemptEvent`` needs except ``hint_requested``/``hint_level_presented``
    — :func:`_assemble_attempt_event` adds those. Produced by :func:`_generate_attempt_outcome`,
    which has no hint logic at all (hint request/level are separate, later decisions).
    """

    learner_id: str
    session_id: str
    scheduled_session_index: int
    item_opportunity_id: str
    task_instance_id: str
    item_template_id: str
    skill_id: str
    attempt_index: int
    response_time_ms: int
    submitted_answer: Optional[str]
    normalized_submitted_answer: Optional[str]
    correct: bool
    selected_distractor_rule_id: Optional[str]
    supported_error_pattern: ErrorPattern
    attempt_completed: bool
    event_seed_lineage: SeedLineage
    generator_version: str
    schema_version: str


def _generate_attempt_outcome(
    task_instance: GeneratedItemInstance,
    learner_truth: BInitialLearnerSkillTruth,
    config: BFirstAttemptBehaviourConfig,
    session_id: str,
    attempt_lineage: SeedLineage,
    attempt_index: int,
    exclude: Optional[set] = None,
) -> AttemptOutcome:
    """Generate one attempt's outcome: latency -> correctness -> submitted answer -> error
    pattern -> timeout. No hint logic (hint request/level are decided and attached separately).

    ``attempt_lineage`` is the already-branched per-attempt seed lineage (``attempt_lineage(...)``
    from ``behaviour.seeds``, keyed by ``attempt_index``) — this function only derives the
    independent-sibling decision domains off it; it never derives the attempt lineage itself, so
    callers control lineage derivation for any attempt index. ``exclude`` (optional normalized
    prior wrong submissions) is forwarded to the wrong-answer generators to avoid repeating an
    already-seen wrong answer on a retry.
    """
    # --- input / identity consistency (no invented sentinels; frozen models untouched) ---
    if learner_truth.learner_id != task_instance.learner_id:
        raise ValueError("learner_truth.learner_id does not match the task instance")
    if learner_truth.skill_id != task_instance.skill_id:
        raise ValueError("learner_truth.skill_id does not match the task instance")
    if get_sampler(task_instance.item_template_id) is None:
        # Deferred / unimplemented templates fail closed (no fabrication).
        raise UnsupportedTemplateError(
            f"no implemented template strategy for {task_instance.item_template_id!r}"
        )

    latency = generate_latency(
        config.latency,
        learner_truth.response_speed_tendency,
        learner_truth.response_speed_variability,
        latency_lineage(attempt_lineage).seed,
    )

    identity = dict(
        learner_id=task_instance.learner_id,
        session_id=session_id,
        scheduled_session_index=task_instance.scheduled_session_index,
        item_opportunity_id=task_instance.item_opportunity_id,
        task_instance_id=task_instance.item_instance_id,
        item_template_id=task_instance.item_template_id,
        skill_id=task_instance.skill_id,
        attempt_index=attempt_index,
    )
    provenance = dict(
        event_seed_lineage=attempt_lineage,
        generator_version=B2B_FIRST_ATTEMPT_GENERATOR_VERSION,
        schema_version=ATTEMPT_EVENT_SCHEMA_VERSION,
    )

    if latency.is_timeout:
        return AttemptOutcome(
            **identity, **provenance,
            response_time_ms=latency.response_time_ms,
            submitted_answer=None, normalized_submitted_answer=None, correct=False,
            selected_distractor_rule_id=None, supported_error_pattern="timeout_no_response",
            attempt_completed=False,
        )

    probability = compute_first_attempt_correct_probability(
        learner_truth.true_mastery_before,
        learner_truth.behavioural_slip_tendency,
        learner_truth.behavioural_guess_tendency,
    )
    is_correct = _sample_correct(probability, correctness_decision_lineage(attempt_lineage).seed)

    if is_correct:
        answer = task_instance.correct_answer  # canonical accepted answer (already normalized)
        return AttemptOutcome(
            **identity, **provenance,
            response_time_ms=latency.response_time_ms,
            submitted_answer=answer, normalized_submitted_answer=normalize_answer(answer),
            correct=True, selected_distractor_rule_id=None, supported_error_pattern="correct",
            attempt_completed=True,
        )

    # Incorrect: multiple-choice selection when validated distractors exist, else typed transform.
    resp_seed = submitted_response_lineage(attempt_lineage).seed
    if task_instance.distractor_candidates:
        submitted, rule_id, pattern = select_mc_wrong_answer(task_instance, resp_seed, exclude=exclude)
        distractor_rule_id = rule_id
    elif config.enable_typed_wrong_answers:
        submitted, pattern = generate_typed_wrong_answer(task_instance, resp_seed, exclude=exclude)
        distractor_rule_id = None
    else:
        raise UnsupportedTemplateError(
            f"typed wrong answers disabled but no distractors for {task_instance.item_template_id!r}"
        )

    return AttemptOutcome(
        **identity, **provenance,
        response_time_ms=latency.response_time_ms,
        submitted_answer=submitted, normalized_submitted_answer=normalize_answer(submitted),
        correct=False, selected_distractor_rule_id=distractor_rule_id,
        supported_error_pattern=pattern, attempt_completed=True,
    )


def _assemble_attempt_event(
    outcome: AttemptOutcome,
    hint_requested: bool,
    hint_level: Optional[int],
) -> BAttemptEvent:
    """Build the frozen compact ``BAttemptEvent`` from a generated outcome plus hint presentation.

    The only fields this adds beyond ``outcome`` are ``hint_requested``/``hint_level_presented``;
    everything else is carried through unchanged.
    """
    return BAttemptEvent(
        learner_id=outcome.learner_id,
        session_id=outcome.session_id,
        scheduled_session_index=outcome.scheduled_session_index,
        item_opportunity_id=outcome.item_opportunity_id,
        task_instance_id=outcome.task_instance_id,
        item_template_id=outcome.item_template_id,
        skill_id=outcome.skill_id,
        attempt_index=outcome.attempt_index,
        submitted_answer=outcome.submitted_answer,
        normalized_submitted_answer=outcome.normalized_submitted_answer,
        correct=outcome.correct,
        response_time_ms=outcome.response_time_ms,
        hint_requested=hint_requested,
        hint_level_presented=hint_level,
        selected_distractor_rule_id=outcome.selected_distractor_rule_id,
        supported_error_pattern=outcome.supported_error_pattern,
        attempt_completed=outcome.attempt_completed,
        event_seed_lineage=outcome.event_seed_lineage,
        generator_version=outcome.generator_version,
        schema_version=outcome.schema_version,
    )


def generate_first_attempt_event(
    task_instance: GeneratedItemInstance,
    learner_truth: BInitialLearnerSkillTruth,
    config: BFirstAttemptBehaviourConfig,
    session_id: str,
) -> BAttemptEvent:
    """Generate exactly one first-attempt ``BAttemptEvent`` (attempt_index=1).

    Recomposed (Phase B2B.3.2) from the two reusable building blocks; byte-identical to the
    original B2B.2 implementation for the same inputs (no hint request/level on a first attempt).
    """
    attempt = attempt_lineage(response_process_lineage(task_instance.seed_lineage), 1)
    outcome = _generate_attempt_outcome(task_instance, learner_truth, config, session_id, attempt, 1)
    return _assemble_attempt_event(outcome, hint_requested=False, hint_level=None)


# ======================================================================================
# Phase B2B.3.2 — hint-request decision + frozen §5.7 hint-level rule.
#
# Both are pure, deterministic, and trait-only: the request decision reads only the caller-
# supplied config and the learner's audit-only ``help_seeking_tendency``; the level rule reads
# only the unsuccessful-attempt count. Neither ever reads population/dd_subtype.
# ======================================================================================


def _hint_request_decision(
    config: BAttemptLoopConfig,
    help_seeking_tendency: float,
    hint_lineage: SeedLineage,
) -> bool:
    """Deterministic Bernoulli hint-request decision (trait-only, population-neutral).

    ``p = clamp(hint_request_base + hint_request_weight * help_seeking_tendency, 0, 1)``, drawn
    from the independent ``hint_decision`` seed domain (``behaviour.seeds.hint_decision_lineage``).
    Never reads population/dd_subtype — only the explicit config and the one trait value.
    """
    p = config.hint_request_base + config.hint_request_weight * help_seeking_tendency
    p = min(1.0, max(0.0, p))
    return random.Random(hint_lineage.seed).random() < p


def _hint_level_for_unsuccessful(u_k: int) -> int:
    """Frozen SPEC §5.7 hint-level rule: presented level = ``min(u_k, 3)``.

    ``u_k`` is the count of unsuccessful attempts so far (timeouts count as unsuccessful).
    """
    if not isinstance(u_k, int) or isinstance(u_k, bool) or u_k < 1:
        raise ValueError(f"u_k must be a positive integer, got {u_k!r}")
    return min(u_k, _HINT_LEVEL_CAP)
