"""Component B Phase B2B behaviour layer.

Phase B2B.0 provides infrastructure only: the observable/audit models (defined in
``component_b_generator.models.behaviour``), deterministic seed-path construction, the pure
opportunity-response derivation, and the fail-closed observable serialization boundary. No
learner-response value is generated in B2B.0 (no traits, probabilities, answers, timing, hints,
retries, completion, or BKT).
"""

from __future__ import annotations

from ..models.behaviour import (
    ATTEMPT_EVENT_SCHEMA_VERSION,
    BEHAVIOUR_MODEL_VERSION,
    ERROR_PATTERNS,
    HINT_LEVELS,
    OPPORTUNITY_SUMMARY_SCHEMA_VERSION,
    AuditOnlyModel,
    BAttemptEvent,
    BInitialLearnerSkillTruth,
    BLearnerSkillTruth,
    BOpportunityResponseSummary,
    BoundedBetaSpec,
    BoundedNormalSpec,
    BTruthInitializationConfig,
)
from ..models.behaviour import (
    MAX_ATTEMPTS_SAFETY_BOUND,
    OPPORTUNITY_RESULT_SCHEMA_VERSION,
    TERMINATION_REASONS,
    BAttemptLoopConfig,
    BFirstAttemptBehaviourConfig,
    BOpportunityAttemptResult,
    LognormalLatencySpec,
)
from .hints import (
    B2B_HINT_LOOKUP_VERSION,
    CatalogueHintReference,
    HintContentError,
    get_catalogue_hint,
)
from .attempt_loop import generate_opportunity_attempts
from .initialization import (
    B2B_TRUTH_INITIALIZATION_VERSION,
    initialize_learner_skill_truth,
    initialize_learner_truth_for_all_skills,
)
from .first_attempt import (
    B2B_FIRST_ATTEMPT_GENERATOR_VERSION,
    AttemptOutcome,
    compute_first_attempt_correct_probability,
    generate_first_attempt_event,
)
from .latency import B2B_LATENCY_MODEL_VERSION, LatencyOutcome, generate_latency
from .wrong_answers import (
    B2B_ERROR_MAPPING_VERSION,
    B2B_WRONG_ANSWER_RULESET_VERSION,
    WrongAnswerGenerationError,
    generate_typed_wrong_answer,
    map_error_pattern,
    select_mc_wrong_answer,
)
from .derivation import (
    B2B_DERIVATION_VERSION,
    OpportunityDerivationError,
    derive_opportunity_response_summary,
)
from .seeds import (
    ATTEMPT_DECISION_DOMAINS,
    B2B_SEED_SCHEMA_VERSION,
    TRAIT_SEED_DOMAINS,
    attempt_decision_lineages,
    attempt_lineage,
    completion_decision_lineage,
    correctness_decision_lineage,
    hint_decision_lineage,
    latency_lineage,
    response_process_lineage,
    retry_decision_lineage,
    skill_truth_lineage,
    submitted_response_lineage,
    trait_lineage,
    truth_initialization_lineage,
)
from .validation import (
    FORBIDDEN_OBSERVABLE_KEYS,
    ObservableSerializationError,
    assert_observable_safe,
    to_observable_dict,
)

__all__ = [
    "BLearnerSkillTruth",
    "BAttemptEvent",
    "BOpportunityResponseSummary",
    "AuditOnlyModel",
    "BEHAVIOUR_MODEL_VERSION",
    "ATTEMPT_EVENT_SCHEMA_VERSION",
    "OPPORTUNITY_SUMMARY_SCHEMA_VERSION",
    "ERROR_PATTERNS",
    "HINT_LEVELS",
    "B2B_SEED_SCHEMA_VERSION",
    "ATTEMPT_DECISION_DOMAINS",
    "response_process_lineage",
    "attempt_lineage",
    "latency_lineage",
    "submitted_response_lineage",
    "hint_decision_lineage",
    "retry_decision_lineage",
    "completion_decision_lineage",
    "attempt_decision_lineages",
    "derive_opportunity_response_summary",
    "OpportunityDerivationError",
    "B2B_DERIVATION_VERSION",
    "to_observable_dict",
    "assert_observable_safe",
    "FORBIDDEN_OBSERVABLE_KEYS",
    "ObservableSerializationError",
    # --- Phase B2B.1 initialization ---
    "BTruthInitializationConfig",
    "BoundedBetaSpec",
    "BoundedNormalSpec",
    "BInitialLearnerSkillTruth",
    "B2B_TRUTH_INITIALIZATION_VERSION",
    "initialize_learner_skill_truth",
    "initialize_learner_truth_for_all_skills",
    "TRAIT_SEED_DOMAINS",
    "truth_initialization_lineage",
    "skill_truth_lineage",
    "trait_lineage",
    # --- Phase B2B.2 first-attempt behaviour ---
    "BFirstAttemptBehaviourConfig",
    "LognormalLatencySpec",
    "compute_first_attempt_correct_probability",
    "generate_first_attempt_event",
    # --- Phase B2B.3.2 attempt-outcome refactor (reusable building block) ---
    "AttemptOutcome",
    "generate_latency",
    "LatencyOutcome",
    "select_mc_wrong_answer",
    "generate_typed_wrong_answer",
    "map_error_pattern",
    "WrongAnswerGenerationError",
    "correctness_decision_lineage",
    "B2B_FIRST_ATTEMPT_GENERATOR_VERSION",
    "B2B_LATENCY_MODEL_VERSION",
    "B2B_WRONG_ANSWER_RULESET_VERSION",
    "B2B_ERROR_MAPPING_VERSION",
    # --- Phase B2B.3 attempt-loop (models + B2B.3.4 orchestrator) ---
    "BAttemptLoopConfig",
    "BOpportunityAttemptResult",
    "OPPORTUNITY_RESULT_SCHEMA_VERSION",
    "TERMINATION_REASONS",
    "MAX_ATTEMPTS_SAFETY_BOUND",
    "generate_opportunity_attempts",
    # --- Phase B2B.3.1 catalogue hint exposure + provenance ---
    "CatalogueHintReference",
    "HintContentError",
    "get_catalogue_hint",
    "B2B_HINT_LOOKUP_VERSION",
]
