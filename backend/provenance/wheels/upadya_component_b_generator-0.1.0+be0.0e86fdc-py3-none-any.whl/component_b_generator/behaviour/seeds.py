"""Phase B2B.0 deterministic seed-path definitions (spec §25).

This module **only constructs seed lineages** — it never samples behaviour. It extends the
existing hierarchy (``global -> learner -> scheduled_session -> component_b_session ->
item_opportunity -> task_instance``) by branching named B2B domains off a parent lineage, reusing
the canonical BLAKE2b derivation in :func:`component_b_generator.seeds.derive_child_lineage` (no
duplicate seed-derivation logic; no Python built-in hashing; no timestamps).

Domain shape (per item opportunity)::

    item_opportunity
        -> response_process
            -> attempt (keyed by attempt_index)
                -> latency               (independent sibling)
                -> submitted_response    (independent sibling)
                -> hint_decision         (independent sibling)
                -> retry_decision        (independent sibling)
                -> completion_decision   (independent sibling)

Each per-attempt decision is an **independent sibling** derived directly off the attempt lineage,
so changing one decision's draw cannot perturb another's (they are not a dependent chain). The
seed API accepts only lineages + a positive ``attempt_index``; it never accepts ``population`` or
``dd_subtype``, so audit labels can never influence a seed path.
"""

from __future__ import annotations

from ..models.session import SeedLineage
from ..seeds import derive_child_lineage

B2B_SEED_SCHEMA_VERSION = "b2b0-1.0.0"

# Stable named domains (also used by tests to assert independence).
RESPONSE_PROCESS_DOMAIN = "response_process"
ATTEMPT_DOMAIN = "attempt"
LATENCY_DOMAIN = "latency"
SUBMITTED_RESPONSE_DOMAIN = "submitted_response"
CORRECTNESS_DECISION_DOMAIN = "correctness_decision"  # added in B2B.2 (independent sibling)
HINT_DECISION_DOMAIN = "hint_decision"
RETRY_DECISION_DOMAIN = "retry_decision"
COMPLETION_DECISION_DOMAIN = "completion_decision"

# All per-attempt decision domains. ``correctness_decision`` is an ADDITIVE B2B.2 sibling: it is a
# new independent branch off the attempt lineage, so every pre-existing domain's seed is byte-
# identical to B2B.0 (backward compatible; B2B_SEED_SCHEMA_VERSION unchanged for existing domains).
ATTEMPT_DECISION_DOMAINS = (
    LATENCY_DOMAIN,
    CORRECTNESS_DECISION_DOMAIN,
    SUBMITTED_RESPONSE_DOMAIN,
    HINT_DECISION_DOMAIN,
    RETRY_DECISION_DOMAIN,
    COMPLETION_DECISION_DOMAIN,
)

_FIXED_KEY = "1"  # single response process / single decision instance per attempt


def response_process_lineage(opportunity_lineage: SeedLineage) -> SeedLineage:
    """Branch the response-process domain off an item-opportunity (or task-instance) lineage."""
    return derive_child_lineage(opportunity_lineage, RESPONSE_PROCESS_DOMAIN, _FIXED_KEY)


def attempt_lineage(response_process: SeedLineage, attempt_index: int) -> SeedLineage:
    """Branch a specific attempt (keyed by ``attempt_index``) off the response process."""
    if not isinstance(attempt_index, int) or isinstance(attempt_index, bool) or attempt_index < 1:
        raise ValueError(f"attempt_index must be an integer >= 1, got {attempt_index!r}")
    return derive_child_lineage(response_process, ATTEMPT_DOMAIN, str(attempt_index))


def _decision(attempt: SeedLineage, domain: str) -> SeedLineage:
    return derive_child_lineage(attempt, domain, _FIXED_KEY)


def latency_lineage(attempt: SeedLineage) -> SeedLineage:
    return _decision(attempt, LATENCY_DOMAIN)


def correctness_decision_lineage(attempt: SeedLineage) -> SeedLineage:
    return _decision(attempt, CORRECTNESS_DECISION_DOMAIN)


def submitted_response_lineage(attempt: SeedLineage) -> SeedLineage:
    return _decision(attempt, SUBMITTED_RESPONSE_DOMAIN)


def hint_decision_lineage(attempt: SeedLineage) -> SeedLineage:
    return _decision(attempt, HINT_DECISION_DOMAIN)


def retry_decision_lineage(attempt: SeedLineage) -> SeedLineage:
    return _decision(attempt, RETRY_DECISION_DOMAIN)


def completion_decision_lineage(attempt: SeedLineage) -> SeedLineage:
    return _decision(attempt, COMPLETION_DECISION_DOMAIN)


def attempt_decision_lineages(attempt: SeedLineage) -> dict[str, SeedLineage]:
    """All five independent per-attempt decision lineages, keyed by domain name."""
    return {domain: _decision(attempt, domain) for domain in ATTEMPT_DECISION_DOMAINS}


# --------------------------------------------------------------------------------------
# Phase B2B.1 — truth-initialization seed domains (spec §25; B2B.1 §12).
#
# learner -> truth_initialization -> skill:<skill_id> -> <trait_domain>
#
# Each trait is an independent sibling branch off the per-skill lineage, so a trait is a pure
# function of (global_seed, learner, skill, trait) — adding or reordering traits/skills never
# perturbs an unrelated trait's draw. Seed semantics are unchanged from B2B.0
# (B2B_SEED_SCHEMA_VERSION stays the same); these are additional named domains.
# --------------------------------------------------------------------------------------

TRUTH_INITIALIZATION_DOMAIN = "truth_initialization"
SKILL_DOMAIN = "skill"
TRAIT_DOMAIN = "trait"

# The independent per-skill trait seed domains (one BLAKE2b branch each).
TRAIT_SEED_DOMAINS = (
    "true_mastery",
    "behavioural_slip_tendency",
    "behavioural_guess_tendency",
    "response_speed_tendency",
    "response_speed_variability",
    "careless_error_tendency",
    "help_seeking_tendency",
    "retry_persistence",
    "completion_persistence",
    "behaviour_consistency",
)


def truth_initialization_lineage(learner_lineage: SeedLineage) -> SeedLineage:
    """Branch the truth-initialization domain off a learner lineage."""
    return derive_child_lineage(learner_lineage, TRUTH_INITIALIZATION_DOMAIN, _FIXED_KEY)


def skill_truth_lineage(truth_init: SeedLineage, skill_id: str) -> SeedLineage:
    """Branch a specific skill's truth-initialization lineage (keyed by skill_id)."""
    return derive_child_lineage(truth_init, SKILL_DOMAIN, str(skill_id))


def trait_lineage(skill_truth: SeedLineage, trait_domain: str) -> SeedLineage:
    """Branch one independent trait domain off a skill's truth lineage."""
    if trait_domain not in TRAIT_SEED_DOMAINS:
        raise ValueError(f"unknown trait seed domain {trait_domain!r}")
    return derive_child_lineage(skill_truth, TRAIT_DOMAIN, trait_domain)
