"""Phase B2B.2 — first-attempt wrong-answer generation + evidence-gated error mapping (pure).

Two strategies, dispatched by whether the validated B2A.2 instance carries distractor candidates:

- **Multiple-choice**: select deterministically from the instance's own validated
  ``distractor_candidates`` (canonical-ordered, correct/equivalent excluded), preserving the
  aligned ``distractor_rule_id``.
- **Typed (non-MC)**: for the zero-distractor templates (make-set, decompose-2D/3D), apply typed,
  response-format-preserving mathematical transformations, validated against the canonical B2A.2
  answer logic (never equal/equivalent to the correct answer). Fail closed if none is valid.

Error patterns are mapped only from supported evidence (distractor rule id or the applied typed
transformation); everything else maps to the neutral ``random``. No diagnosis, no ``eval``/``exec``,
no population/dd_subtype, no global RNG.
"""

from __future__ import annotations

import random
from typing import List, Optional, Tuple

from ..answers.rules import normalize_answer
from ..answers.structured import structured_equivalent_forms
from ..models.behaviour import ErrorPattern
from ..models.task_instance import GeneratedItemInstance

B2B_WRONG_ANSWER_RULESET_VERSION = "b2b2-1.0.0"
B2B_ERROR_MAPPING_VERSION = "b2b2-1.0.0"


class WrongAnswerGenerationError(ValueError):
    """Raised when no valid wrong answer can be produced for a supported task (fail-closed)."""


# --------------------------------------------------------------------------------------
# Evidence-gated error mapping (frozen non-diagnostic vocabulary).
# --------------------------------------------------------------------------------------


def map_error_pattern(rule_id: str) -> ErrorPattern:
    """Map a distractor rule id to a supported error pattern, else the neutral ``random``."""
    rid = rule_id.upper()
    if "OFF-BY-ONE" in rid or "NEARBY" in rid:
        return "off_by_one"
    if "MISCOUNT" in rid:
        return "off_by_one" if rid.endswith("ONE") else "random"
    if "OPERATOR-CONFUSION" in rid:
        return "operator_confusion"
    if "OTHER-DIGIT" in rid or "OTHER-PLACE" in rid:
        return "place_value"
    if "SWAP" in rid or "REVERS" in rid:
        return "transposition"
    return "random"


# --------------------------------------------------------------------------------------
# Multiple-choice selection.
# --------------------------------------------------------------------------------------


def _excluded_forms(instance: GeneratedItemInstance) -> set:
    excluded = {instance.correct_answer}
    excluded.update(normalize_answer(e) for e in instance.allowed_equivalent_answers)
    return excluded


def select_mc_wrong_answer(
    instance: GeneratedItemInstance,
    seed: int,
    exclude: Optional[set] = None,
) -> Tuple[str, str, ErrorPattern]:
    """Deterministically pick one validated distractor (candidate-order independent).

    Returns ``(normalized_answer, distractor_rule_id, error_pattern)``. Fails closed if there is no
    valid distractor left after excluding the correct answer and accepted equivalents (this never
    changes with ``exclude`` — the correct answer and its equivalents are never selectable).

    ``exclude`` (optional; default ``None``, backward-compatible) is a set of normalized prior
    wrong submissions — e.g. from earlier attempts in the same bounded opportunity — additionally
    excluded so a retry avoids repeating an already-seen wrong answer. If applying ``exclude``
    would remove every remaining candidate (exhaustion of the distractor bank), the ``exclude``
    filter is dropped and selection falls back to the full correct/equivalent-excluded candidate
    set — repetition is allowed rather than failing closed, since a bounded item bank is expected
    to run out of distinct wrong answers before it runs out of retries.
    """
    pairs = list(zip(instance.distractor_candidates, instance.distractor_rule_ids))
    if not pairs:
        raise WrongAnswerGenerationError(f"no distractor candidates for {instance.item_template_id}")

    excluded = _excluded_forms(instance)
    # Canonical ordering by candidate string so selection is candidate-order independent.
    valid = sorted(((c, r) for c, r in pairs if c not in excluded), key=lambda p: (p[0], p[1]))
    if not valid:
        raise WrongAnswerGenerationError(f"all distractors excluded for {instance.item_template_id}")

    pool = valid
    if exclude:
        narrowed = [p for p in valid if p[0] not in exclude]
        if narrowed:
            pool = narrowed  # else: exhaustion — repetition allowed, keep the full `valid` pool

    candidate, rule_id = random.Random(seed).choice(pool)
    return candidate, rule_id, map_error_pattern(rule_id)


# --------------------------------------------------------------------------------------
# Typed (non-MC) wrong-answer generators for the zero-distractor templates.
# --------------------------------------------------------------------------------------


def _expanded(value: int) -> Optional[str]:
    """Numeric expanded form (e.g. 203 -> '200 + 3'); None for a non-representable value."""
    if value <= 0:
        return None
    forms = structured_equivalent_forms(value)
    return forms[0] if forms else None


def _typed_candidates(instance: GeneratedItemInstance) -> List[Tuple[str, int, ErrorPattern]]:
    """Ordered (form_string, denoted_value, error_pattern) candidates for a typed template."""
    o = instance.generated_operands
    tid = instance.item_template_id
    out: List[Tuple[str, int, ErrorPattern]] = []

    if tid == "B-CNT04-MAKE-SET":
        target = int(o["target"])
        for delta, patt in ((-1, "off_by_one"), (1, "off_by_one")):
            v = target + delta
            if 1 <= v <= 20:
                out.append((str(v), v, patt))
        return out

    if tid in ("B-PV02-DECOMPOSE-2D", "B-PV04-DECOMPOSE-3D"):
        n = int(o["n"])
        # off-by-one numerals rendered in the same expanded-form response type
        for delta, patt in ((-1, "off_by_one"), (1, "off_by_one")):
            v = n + delta
            form = _expanded(v)
            if form is not None:
                out.append((form, v, patt))
        # digit transposition (swap outermost places)
        if tid == "B-PV02-DECOMPOSE-2D":
            tens, ones = int(o["tens"]), int(o["ones"])
            swapped = ones * 10 + tens
            form = _expanded(swapped)
            if form is not None:
                out.append((form, swapped, "transposition"))
            # place-value error: keep only the tens contribution
            pv = tens * 10
            form = _expanded(pv)
            if form is not None:
                out.append((form, pv, "place_value"))
        else:  # B-PV04-DECOMPOSE-3D
            hundreds, tens, ones = int(o["hundreds"]), int(o["tens"]), int(o["ones"])
            swapped = ones * 100 + tens * 10 + hundreds
            form = _expanded(swapped)
            if form is not None:
                out.append((form, swapped, "transposition"))
            pv = hundreds * 100 + ones  # omit the tens place
            form = _expanded(pv)
            if form is not None:
                out.append((form, pv, "place_value"))
        return out

    return out


def generate_typed_wrong_answer(
    instance: GeneratedItemInstance,
    seed: int,
    exclude: Optional[set] = None,
) -> Tuple[str, ErrorPattern]:
    """Deterministically produce one typed, format-preserving wrong answer (fail-closed).

    Returns ``(submitted_answer, error_pattern)``. Every candidate is validated against the
    canonical B2A.2 answer logic so it is never equal or equivalent to the correct answer (this
    never changes with ``exclude``).

    ``exclude`` (optional; default ``None``, backward-compatible) is a set of normalized prior
    wrong submissions additionally excluded so a retry avoids repeating an already-seen wrong
    answer. If applying ``exclude`` would remove every remaining candidate (exhaustion of the
    typed-transform bank), the ``exclude`` filter is dropped and selection falls back to the full
    validated candidate set — repetition is allowed rather than failing closed.
    """
    n_correct = None
    o = instance.generated_operands
    if "target" in o:
        n_correct = int(o["target"])
    elif "n" in o:
        n_correct = int(o["n"])

    excluded = _excluded_forms(instance)
    valid: List[Tuple[str, ErrorPattern]] = []
    for form, value, patt in _typed_candidates(instance):
        if n_correct is not None and value == n_correct:
            continue  # denotes the correct value
        if normalize_answer(form) in excluded:
            continue  # equals the correct answer or an accepted equivalent
        valid.append((form, patt))

    if not valid:
        raise WrongAnswerGenerationError(f"no valid typed wrong answer for {instance.item_template_id}")

    # Canonical ordering before selection (order-independent, deterministic).
    valid.sort(key=lambda p: (p[0], p[1]))

    pool = valid
    if exclude:
        narrowed = [p for p in valid if normalize_answer(p[0]) not in exclude]
        if narrowed:
            pool = narrowed  # else: exhaustion — repetition allowed, keep the full `valid` pool

    return random.Random(seed).choice(pool)
