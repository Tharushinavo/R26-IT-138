"""Generator run manifest (reproducibility provenance, SPEC §8)."""

from __future__ import annotations

from typing import Tuple

from pydantic import BaseModel, ConfigDict

DISCLOSURE = "Literature-informed synthetic data — not clinical evidence."


class GeneratorRunManifest(BaseModel):
    """Provenance for one generator run — everything needed to reproduce it (SPEC §8).

    Deliberately contains **no wall-clock timestamp** so a run is reproducible from
    ``(global_seed, config_version, config_hash, catalogue_version)`` alone.
    """

    model_config = ConfigDict(frozen=True, extra="forbid")

    generation_phase: str
    generator_package_version: str
    global_seed: int
    config_version: str
    config_hash: str
    catalogue_version: str
    catalogue_status: str
    catalogue_source_path: str
    n_learners: int
    scheduled_session_count: int
    n_item_opportunities: int
    populations_present: Tuple[str, ...]  # audit-only summary; not a driver
    disclosure: str = DISCLOSURE
