"""Learner B-local hidden-state placeholder (SPEC §4, §6.10).

Phase B1 defines the container and its seed lineage but leaves the latent trait *values*
as explicit ``CALIBRATION_PENDING`` placeholders (``None``). Later phases will populate
them from **overlapping B-local learner-level distributions** whose exact parameters are
`CALIBRATION_PENDING` (SF-039: population may only shift the distribution; it never keys a
runtime lookup). No field here is population-conditioned.
"""

from __future__ import annotations

from typing import Optional

from pydantic import BaseModel, ConfigDict, Field


class LearnerBLocalState(BaseModel):
    """B-kernel-owned local hidden state for one learner (SF-041).

    All latent values are Phase-B1 placeholders (``None`` = not yet drawn). They are NOT
    fabricated and NOT population-keyed. `learner_seed` records the deterministic seed from
    which later phases will draw these traits reproducibly.
    """

    model_config = ConfigDict(frozen=True, extra="forbid")

    student_id: str
    learner_seed: int

    # --- CALIBRATION_PENDING latent-trait placeholders (drawn in a later phase) ---
    true_ability: Optional[float] = Field(default=None, description="CALIBRATION_PENDING")
    b_response_speed_baseline: Optional[float] = Field(default=None, description="CALIBRATION_PENDING")
    learner_random_effect_u: Optional[float] = Field(default=None, description="CALIBRATION_PENDING")
    guessing_propensity: Optional[float] = Field(default=None, description="CALIBRATION_PENDING")
    help_avoidance_trait: Optional[float] = Field(default=None, description="CALIBRATION_PENDING")
    # Per-skill initial mastery is B-kernel-owned (Population Influence Register B2/B6);
    # drawn later from an overlapping learner-level prior, not a per-group ceiling lookup.
    initial_mastery_by_skill: Optional[dict] = Field(default=None, description="CALIBRATION_PENDING")

    @property
    def is_calibrated(self) -> bool:
        """True only once the latent traits have been drawn (a later phase)."""
        return self.true_ability is not None
