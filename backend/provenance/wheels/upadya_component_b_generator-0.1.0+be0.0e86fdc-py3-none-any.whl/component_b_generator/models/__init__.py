"""Typed internal models for the Component B generator (Phase B1)."""

from __future__ import annotations

from .catalogue import ItemTemplate, LoadedCatalogue
from .enums import (
    SESSION_ATTENDANCE_STATUSES,
    CalibrationStatus,
    DDSubtype,
    Grade,
    PopulationLabel,
    SessionAttendanceStatus,
    TemplateStatus,
)
from .behaviour import (
    ATTEMPT_EVENT_SCHEMA_VERSION,
    BEHAVIOUR_MODEL_VERSION,
    ERROR_PATTERNS,
    OPPORTUNITY_RESULT_SCHEMA_VERSION,
    OPPORTUNITY_SUMMARY_SCHEMA_VERSION,
    AuditOnlyModel,
    BAttemptEvent,
    BInitialLearnerSkillTruth,
    BLearnerSkillTruth,
    BOpportunityResponseSummary,
    BAttemptLoopConfig,
    BFirstAttemptBehaviourConfig,
    BOpportunityAttemptResult,
    BoundedBetaSpec,
    BoundedNormalSpec,
    BTruthInitializationConfig,
    LognormalLatencySpec,
    MAX_ATTEMPTS_SAFETY_BOUND,
    TERMINATION_REASONS,
)
from .identity import LearnerAuditIdentity
from .manifest import DISCLOSURE, GeneratorRunManifest
from .opportunity import (
    PENDING_OPPORTUNITY_FIELDS,
    SESSION_ID_RE,
    SESSION_SUMMARY_SCHEMA_VERSION,
    SKILL_MASTERY_UPDATE_SCHEMA_VERSION,
    GeneratedItemOpportunity,
    SessionSummary,
    SkillMasteryUpdate,
)
from .session import ScheduledSessionContext, SeedLineage
from .state import LearnerBLocalState
from .task_instance import (
    DEFERRED_RESPONSE_FIELDS,
    FORBIDDEN_INSTANCE_FIELDS,
    ActivationDecision,
    GeneratedItemInstance,
    TaskInstanceRunManifest,
)

__all__ = [
    "Grade",
    "PopulationLabel",
    "DDSubtype",
    "TemplateStatus",
    "CalibrationStatus",
    "LearnerAuditIdentity",
    "LearnerBLocalState",
    "ScheduledSessionContext",
    "SeedLineage",
    "ItemTemplate",
    "LoadedCatalogue",
    "GeneratedItemOpportunity",
    "PENDING_OPPORTUNITY_FIELDS",
    "SkillMasteryUpdate",
    "SKILL_MASTERY_UPDATE_SCHEMA_VERSION",
    "SessionSummary",
    "SESSION_ID_RE",
    "SESSION_SUMMARY_SCHEMA_VERSION",
    "SessionAttendanceStatus",
    "SESSION_ATTENDANCE_STATUSES",
    "AuditOnlyModel",
    "BLearnerSkillTruth",
    "BAttemptEvent",
    "BOpportunityResponseSummary",
    "BInitialLearnerSkillTruth",
    "BTruthInitializationConfig",
    "BoundedBetaSpec",
    "BoundedNormalSpec",
    "BFirstAttemptBehaviourConfig",
    "LognormalLatencySpec",
    "BAttemptLoopConfig",
    "BOpportunityAttemptResult",
    "TERMINATION_REASONS",
    "MAX_ATTEMPTS_SAFETY_BOUND",
    "BEHAVIOUR_MODEL_VERSION",
    "ATTEMPT_EVENT_SCHEMA_VERSION",
    "OPPORTUNITY_SUMMARY_SCHEMA_VERSION",
    "OPPORTUNITY_RESULT_SCHEMA_VERSION",
    "ERROR_PATTERNS",
    "GeneratorRunManifest",
    "DISCLOSURE",
    "GeneratedItemInstance",
    "ActivationDecision",
    "TaskInstanceRunManifest",
    "DEFERRED_RESPONSE_FIELDS",
    "FORBIDDEN_INSTANCE_FIELDS",
]
