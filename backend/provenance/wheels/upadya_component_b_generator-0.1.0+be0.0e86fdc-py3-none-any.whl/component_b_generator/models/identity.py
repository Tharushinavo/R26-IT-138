"""Learner audit identity (audit-only; never a deployable output).

`population` and `dd_subtype` live here and ONLY here. They are audit-only generator
controls (SF-031/032/039): they never enter a deployable B->C / B->3 output model and
must never be used to branch runtime generation behaviour.
"""

from __future__ import annotations

import re

from pydantic import BaseModel, ConfigDict, field_validator

from .enums import DDSubtype, Grade, PopulationLabel

STUDENT_ID_RE = re.compile(r"^STU-[0-9]{4}$")


class LearnerAuditIdentity(BaseModel):
    """Audit-only identity for one synthetic learner.

    Retained only for SF-038 leakage testing, subgroup fidelity checks, and generator
    debugging (SPEC §8). Never exported across any boundary; never a model/feature input.
    """

    model_config = ConfigDict(frozen=True, extra="forbid")

    student_id: str
    grade: Grade
    # Audit-only labels — NOT drivers of generation behaviour (SF-039).
    population: PopulationLabel
    dd_subtype: DDSubtype = "none"

    @field_validator("student_id")
    @classmethod
    def _student_id_format(cls, v: str) -> str:
        if not STUDENT_ID_RE.match(v):
            raise ValueError(f"student_id must match ^STU-[0-9]{{4}}$, got {v!r}")
        return v
