"""Phase B2B.0 interaction models: audit-only truth, observable events, derived summary.

This module defines **schema and validation only** — it does NOT generate any learner-response
value (no trait sampling, no probabilities, no submitted answers, no timing, no hints/retries,
no BKT). See ``R26-IT-138_Component_B_Phase_B2B_Learner_Response_and_Attempt_Spec_v1.0.md``.

Three record families, strictly separated (spec §22/§23/§24):

- :class:`BLearnerSkillTruth` — audit-only hidden simulation truth. Subclasses
  :class:`AuditOnlyModel`, so the observable serializer boundary refuses it by type.
- :class:`BAttemptEvent` — the canonical observable ``b_attempt_events`` row.
- :class:`BOpportunityResponseSummary` — opportunity-level record *derived from* attempt events.

All models use Pydantic v2 with ``extra="forbid"`` and are frozen, so any unknown field —
including ``population``, ``dd_subtype``, hidden-truth traits, BKT estimates, or future-outcome
fields — is rejected on the observable models by construction.
"""

from __future__ import annotations

import random
from typing import ClassVar, Literal, Optional, Tuple

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

from models.contracts import SKILLS  # single source of truth: the seven frozen skills

from .opportunity import ITEM_OPPORTUNITY_ID_RE
from .session import SeedLineage
from .task_instance import ITEM_INSTANCE_ID_RE

# --- version constants (Phase B2B.0) ---
BEHAVIOUR_MODEL_VERSION = "b2b0-1.0.0"
ATTEMPT_EVENT_SCHEMA_VERSION = "b2b0-1.0.0"
OPPORTUNITY_SUMMARY_SCHEMA_VERSION = "b2b0-1.0.0"

# Frozen Component B error-evidence vocabulary (spec §17). B2B.0 only *validates* these; it
# never infers or generates them.
ERROR_PATTERNS: Tuple[str, ...] = (
    "correct",
    "off_by_one",
    "place_value",
    "operator_confusion",
    "transposition",
    "fact_retrieval",
    "timeout_no_response",
    "random",
)
ErrorPattern = Literal[
    "correct",
    "off_by_one",
    "place_value",
    "operator_confusion",
    "transposition",
    "fact_retrieval",
    "timeout_no_response",
    "random",
]

HINT_LEVELS: Tuple[int, ...] = (1, 2, 3)  # template-controlled L1/L2/L3

_SEVEN_SKILLS = frozenset(SKILLS)


def _require_skill(v: str) -> str:
    if v not in _SEVEN_SKILLS:
        raise ValueError(f"skill_id must be one of the seven frozen skills {tuple(SKILLS)}, got {v!r}")
    return v


class AuditOnlyModel(BaseModel):
    """Base for simulation-only records that must NEVER cross an observable/deployable boundary.

    The observable serializer (``behaviour.validation``) refuses any instance of this class by
    type, so audit-only truth cannot be exported by accident.
    """

    model_config = ConfigDict(frozen=True, extra="forbid")

    IS_AUDIT_ONLY: ClassVar[bool] = True


class BLearnerSkillTruth(AuditOnlyModel):
    """``b_learner_skill_truth`` — audit-only hidden truth for one learner x skill x opportunity.

    Simulation-only: never exported to Component C / Component 3 / any UI / deployable features.
    Phase B2B.0 defines and validates the schema; it does **not** sample or update any value here
    (trait initialization and the fixed-growth update are later phases). ``fixed_hidden_growth_g``
    is deliberately absent — it is configuration, not a per-learner trait (spec §13).
    """

    learner_id: str
    skill_id: str
    scheduled_session_index: int = Field(ge=1)
    item_opportunity_id: str

    # Hidden mastery (bounded; not generated here).
    true_mastery_before: float = Field(ge=0.0, le=1.0, allow_inf_nan=False)
    true_mastery_after: float = Field(ge=0.0, le=1.0, allow_inf_nan=False)

    # Behavioural traits (bounded; not generated here).
    behavioural_slip_tendency: float = Field(ge=0.0, le=1.0, allow_inf_nan=False)
    behavioural_guess_tendency: float = Field(ge=0.0, le=1.0, allow_inf_nan=False)
    response_speed_tendency: float = Field(allow_inf_nan=False)  # finite location shift
    response_speed_variability: float = Field(ge=0.0, allow_inf_nan=False)
    careless_error_tendency: float = Field(ge=0.0, le=1.0, allow_inf_nan=False)
    help_seeking_tendency: float = Field(ge=0.0, le=1.0, allow_inf_nan=False)
    retry_persistence: float = Field(ge=0.0, le=1.0, allow_inf_nan=False)
    completion_persistence: float = Field(ge=0.0, le=1.0, allow_inf_nan=False)
    behaviour_consistency: float = Field(ge=0.0, le=1.0, allow_inf_nan=False)

    truth_parameter_version: str
    seed_lineage: SeedLineage

    _skill = field_validator("skill_id")(_require_skill)

    @field_validator("item_opportunity_id")
    @classmethod
    def _opp_id_format(cls, v: str) -> str:
        if not ITEM_OPPORTUNITY_ID_RE.match(v):
            raise ValueError(f"item_opportunity_id must match {ITEM_OPPORTUNITY_ID_RE.pattern}, got {v!r}")
        return v


class BAttemptEvent(BaseModel):
    """``b_attempt_events`` — one observable row per attempt (spec §22).

    Observable only: no hidden truth, no ``population``/``dd_subtype``, no BKT, no future
    information (all rejected by ``extra="forbid"``). Phase B2B.0 defines and validates the schema
    and its impossible-combination guards; it does **not** generate any event.
    """

    model_config = ConfigDict(frozen=True, extra="forbid")

    learner_id: str
    session_id: str
    scheduled_session_index: int = Field(ge=1)
    item_opportunity_id: str
    task_instance_id: str
    item_template_id: str
    skill_id: str
    attempt_index: int = Field(ge=1)

    submitted_answer: Optional[str] = None  # None only for timeout/no-response
    normalized_submitted_answer: Optional[str] = None
    correct: bool = False
    response_time_ms: int = Field(ge=0)

    hint_requested: bool = False
    hint_level_presented: Optional[int] = None
    selected_distractor_rule_id: Optional[str] = None
    supported_error_pattern: ErrorPattern = "random"
    attempt_completed: bool = False

    event_seed_lineage: SeedLineage
    generator_version: str = BEHAVIOUR_MODEL_VERSION
    schema_version: str = ATTEMPT_EVENT_SCHEMA_VERSION

    _skill = field_validator("skill_id")(_require_skill)

    @field_validator("item_opportunity_id")
    @classmethod
    def _opp_id_format(cls, v: str) -> str:
        if not ITEM_OPPORTUNITY_ID_RE.match(v):
            raise ValueError(f"item_opportunity_id must match {ITEM_OPPORTUNITY_ID_RE.pattern}, got {v!r}")
        return v

    @field_validator("task_instance_id")
    @classmethod
    def _instance_id_format(cls, v: str) -> str:
        if not ITEM_INSTANCE_ID_RE.match(v):
            raise ValueError(f"task_instance_id must match {ITEM_INSTANCE_ID_RE.pattern}, got {v!r}")
        return v

    @model_validator(mode="after")
    def _impossible_combinations(self) -> "BAttemptEvent":
        # correctness <-> error pattern must agree exactly.
        if self.correct != (self.supported_error_pattern == "correct"):
            raise ValueError("correct must be True iff supported_error_pattern == 'correct'")
        # a correct response necessarily ends (completes) the item attempt.
        if self.correct and not self.attempt_completed:
            raise ValueError("a correct response must have attempt_completed=True")
        # a distractor selection is only meaningful for an incorrect response.
        if self.selected_distractor_rule_id is not None and self.correct:
            raise ValueError("selected_distractor_rule_id cannot accompany a correct response")
        # timeout / no-response: no normal submitted answer, cannot be correct.
        if self.supported_error_pattern == "timeout_no_response":
            if self.correct:
                raise ValueError("timeout_no_response cannot be marked correct")
            if self.submitted_answer is not None or self.normalized_submitted_answer is not None:
                raise ValueError("timeout_no_response cannot carry a submitted answer")
        else:
            # a real (correct or wrong) attempt must carry a submission and its normalization.
            if self.submitted_answer is None or self.normalized_submitted_answer is None:
                raise ValueError("a non-timeout attempt must carry submitted + normalized answer")
        # hint level presence is coupled to a hint request; level must be L1/L2/L3.
        if not self.hint_requested and self.hint_level_presented is not None:
            raise ValueError("hint_level_presented requires hint_requested=True")
        if self.hint_level_presented is not None and self.hint_level_presented not in HINT_LEVELS:
            raise ValueError(f"hint_level_presented must be one of {HINT_LEVELS}")
        return self


class BOpportunityResponseSummary(BaseModel):
    """Opportunity-level record derived from ``b_attempt_events`` (spec §24).

    This is NOT a session summary; it is local opportunity-level derivation only. It is produced
    by ``behaviour.derivation.derive_opportunity_response_summary`` and never carries hidden
    truth, ``population``/``dd_subtype``, BKT, certification, sequencing, or downstream data.
    """

    model_config = ConfigDict(frozen=True, extra="forbid")

    learner_id: str
    session_id: str
    scheduled_session_index: int = Field(ge=1)
    item_opportunity_id: str
    task_instance_id: str
    item_template_id: str
    skill_id: str

    first_attempt_correct: bool
    first_attempt_error_pattern: ErrorPattern
    total_attempts: int = Field(ge=1)
    retry_count: int = Field(ge=0)
    hint_requested: bool
    hint_count: int = Field(ge=0)
    final_item_completed: bool
    assisted_completion: bool
    unassisted_completion: bool
    total_response_time_ms: int = Field(ge=0)
    first_attempt_response_time_ms: int = Field(ge=0)
    final_submitted_answer: Optional[str] = None

    derivation_version: str
    source_event_schema_version: str

    _skill = field_validator("skill_id")(_require_skill)

    @model_validator(mode="after")
    def _summary_invariants(self) -> "BOpportunityResponseSummary":
        if self.retry_count != self.total_attempts - 1:
            raise ValueError("retry_count must equal total_attempts - 1")
        if self.hint_count > self.total_attempts:
            raise ValueError("hint_count cannot exceed total_attempts (one hint per attempt max)")
        if self.total_response_time_ms < self.first_attempt_response_time_ms:
            raise ValueError("total_response_time_ms cannot be less than first_attempt_response_time_ms")
        if self.first_attempt_correct != (self.first_attempt_error_pattern == "correct"):
            raise ValueError("first_attempt_correct must agree with first_attempt_error_pattern")
        if self.assisted_completion and self.unassisted_completion:
            raise ValueError("assisted_completion and unassisted_completion cannot both be true")
        if self.final_item_completed:
            if not (self.assisted_completion ^ self.unassisted_completion):
                raise ValueError("a completed item must be exactly one of assisted / unassisted")
            if self.assisted_completion and self.hint_count < 1:
                raise ValueError("assisted_completion requires hint_count >= 1")
            if self.unassisted_completion and self.hint_count != 0:
                raise ValueError("unassisted_completion requires hint_count == 0")
        else:
            if self.assisted_completion or self.unassisted_completion:
                raise ValueError("an incomplete item cannot be assisted or unassisted completed")
        return self


# ======================================================================================
# Phase B2B.1 — population-neutral learner-truth INITIALIZATION (config, specs, initial model).
#
# These define the schema for *explicit, versioned* initialization configuration and the
# audit-only pre-opportunity initial-truth record. All scientific parameters are supplied by the
# caller (CALIBRATION_PENDING) — no production defaults are embedded. No population/dd_subtype.
# ======================================================================================


class BoundedBetaSpec(BaseModel):
    """A bounded Beta distribution spec for a unit-interval trait, scaled onto ``[lower, upper]``.

    All parameters are explicit; there are no scientific defaults. Sampling is deterministic from
    a caller-supplied local RNG (never the global random state).
    """

    model_config = ConfigDict(frozen=True, extra="forbid")

    family: Literal["bounded_beta"] = "bounded_beta"
    alpha: float = Field(gt=0.0, allow_inf_nan=False)
    beta: float = Field(gt=0.0, allow_inf_nan=False)
    lower: float = Field(ge=0.0, le=1.0, allow_inf_nan=False)
    upper: float = Field(ge=0.0, le=1.0, allow_inf_nan=False)

    @model_validator(mode="after")
    def _bounds(self) -> "BoundedBetaSpec":
        if not (self.lower < self.upper):
            raise ValueError("bounded_beta requires 0 <= lower < upper <= 1")
        return self

    def sample(self, rng: random.Random) -> float:
        x = rng.betavariate(self.alpha, self.beta)  # in [0,1]
        return self.lower + x * (self.upper - self.lower)


class BoundedNormalSpec(BaseModel):
    """A truncated (clamped) Normal spec for a real-valued trait bounded to ``[lower, upper]``.

    Used for traits that are not unit-interval (e.g. a response-speed location shift, or a
    non-negative variability). Explicit parameters only; deterministic from a local RNG.
    """

    model_config = ConfigDict(frozen=True, extra="forbid")

    family: Literal["bounded_normal"] = "bounded_normal"
    mean: float = Field(allow_inf_nan=False)
    std: float = Field(gt=0.0, allow_inf_nan=False)
    lower: float = Field(allow_inf_nan=False)
    upper: float = Field(allow_inf_nan=False)

    @model_validator(mode="after")
    def _bounds(self) -> "BoundedNormalSpec":
        if not (self.lower < self.upper):
            raise ValueError("bounded_normal requires lower < upper")
        return self

    def sample(self, rng: random.Random) -> float:
        x = rng.normalvariate(self.mean, self.std)
        return min(max(x, self.lower), self.upper)  # deterministic clamp into bounds


class BTruthInitializationConfig(BaseModel):
    """Explicit, versioned Phase-B2B.1 initialization configuration.

    Every distribution is supplied explicitly (no scientific production defaults). Scientific
    values remain CALIBRATION_PENDING; ``parameter_source_status`` records that provenance.
    ``fixed_hidden_growth_g`` lives here (configuration), NOT on any learner trait model, and is
    NOT applied during initialization. Unknown fields — including ``population``, ``dd_subtype``,
    per-population dictionaries, BKT, item_difficulty, or Component C/3 parameters — are rejected.
    """

    model_config = ConfigDict(frozen=True, extra="forbid")

    initialization_version: str
    parameter_source_status: str  # e.g. "CALIBRATION_PENDING" or a clearly-named test fixture tag

    initial_true_mastery: BoundedBetaSpec
    behavioural_slip_tendency: BoundedBetaSpec
    behavioural_guess_tendency: BoundedBetaSpec
    careless_error_tendency: BoundedBetaSpec
    help_seeking_tendency: BoundedBetaSpec
    retry_persistence: BoundedBetaSpec
    completion_persistence: BoundedBetaSpec
    behaviour_consistency: BoundedBetaSpec
    response_speed_tendency: BoundedNormalSpec
    response_speed_variability: BoundedNormalSpec

    # Configuration-level fixed hidden growth (CALIBRATION_PENDING value; not applied at init).
    fixed_hidden_growth_g: float = Field(ge=0.0, allow_inf_nan=False)

    @field_validator("initialization_version", "parameter_source_status")
    @classmethod
    def _non_empty(cls, v: str) -> str:
        if not str(v).strip():
            raise ValueError("version / source-status strings must be non-empty")
        return v


class BInitialLearnerSkillTruth(AuditOnlyModel):
    """``b_initial_learner_skill_truth`` — audit-only PRE-opportunity initial truth (Phase B2B.1).

    A dedicated initial-state record for one learner x skill *before any opportunity exists*. It
    deliberately carries **no** ``item_opportunity_id`` / ``scheduled_session_index`` (those are
    opportunity-scoped and belong to the per-opportunity :class:`BLearnerSkillTruth`, produced by
    a later approved progression slice). At initialization there is no growth:
    ``true_mastery_before == true_mastery_after == true_mastery_initial``. Simulation-only; blocked
    from every observable/deployable serializer by the :class:`AuditOnlyModel` boundary.
    """

    learner_id: str
    skill_id: str

    true_mastery_initial: float = Field(ge=0.0, le=1.0, allow_inf_nan=False)
    true_mastery_before: float = Field(ge=0.0, le=1.0, allow_inf_nan=False)
    true_mastery_after: float = Field(ge=0.0, le=1.0, allow_inf_nan=False)

    behavioural_slip_tendency: float = Field(ge=0.0, le=1.0, allow_inf_nan=False)
    behavioural_guess_tendency: float = Field(ge=0.0, le=1.0, allow_inf_nan=False)
    response_speed_tendency: float = Field(allow_inf_nan=False)
    response_speed_variability: float = Field(ge=0.0, allow_inf_nan=False)
    careless_error_tendency: float = Field(ge=0.0, le=1.0, allow_inf_nan=False)
    help_seeking_tendency: float = Field(ge=0.0, le=1.0, allow_inf_nan=False)
    retry_persistence: float = Field(ge=0.0, le=1.0, allow_inf_nan=False)
    completion_persistence: float = Field(ge=0.0, le=1.0, allow_inf_nan=False)
    behaviour_consistency: float = Field(ge=0.0, le=1.0, allow_inf_nan=False)

    truth_parameter_version: str
    initialization_version: str
    config_version: str
    seed_lineage: SeedLineage

    _skill = field_validator("skill_id")(_require_skill)

    @model_validator(mode="after")
    def _no_growth_at_init(self) -> "BInitialLearnerSkillTruth":
        if not (self.true_mastery_before == self.true_mastery_after == self.true_mastery_initial):
            raise ValueError("at initialization true_mastery_before == after == initial (no growth applied)")
        return self


# ======================================================================================
# Phase B2B.2 — first-attempt behaviour configuration (latency spec + strict config).
#
# Explicit + versioned. The response-time transform STRUCTURE is fixed by the B2B spec (§15:
# positively-skewed lognormal, location shifted by learner speed, spread scaled by learner
# variability, clipped to explicit bounds, integer ms, timeout when a max-time is exceeded); the
# numeric PARAMETERS are supplied by the caller and remain CALIBRATION_PENDING. No population/
# dd_subtype/BKT/item_difficulty — rejected by extra="forbid".
# ======================================================================================


class LognormalLatencySpec(BaseModel):
    """Explicit lognormal latency spec (all numeric parameters caller-supplied; no defaults).

    ``response_time = exp(location_mu - speed_tendency_weight*speed_tendency
                          + scale_sigma*(1 + variability_weight*variability)*Z)`` in ms,
    with a deterministic ``Z`` from the latency seed; a draw above ``timeout_threshold_ms`` is a
    timeout/no-response, otherwise the value is clamped into ``[floor_ms, cap_ms]`` and rounded to
    a non-negative integer. Higher ``speed_tendency`` yields a monotonically faster response.
    """

    model_config = ConfigDict(frozen=True, extra="forbid")

    family: Literal["lognormal"] = "lognormal"
    location_mu: float = Field(allow_inf_nan=False)
    scale_sigma: float = Field(gt=0.0, allow_inf_nan=False)
    speed_tendency_weight: float = Field(ge=0.0, allow_inf_nan=False)
    variability_weight: float = Field(ge=0.0, allow_inf_nan=False)
    floor_ms: int = Field(ge=0)
    cap_ms: int = Field(gt=0)
    timeout_threshold_ms: int = Field(gt=0)

    @model_validator(mode="after")
    def _bounds(self) -> "LognormalLatencySpec":
        if not (self.floor_ms < self.cap_ms):
            raise ValueError("latency requires floor_ms < cap_ms")
        if not (self.timeout_threshold_ms > self.floor_ms):
            raise ValueError("latency requires timeout_threshold_ms > floor_ms")
        return self


class BFirstAttemptBehaviourConfig(BaseModel):
    """Strict, versioned Phase-B2B.2 first-attempt behaviour configuration.

    Explicit parameters only; scientific values are CALIBRATION_PENDING (recorded via
    ``parameter_source_status``). Rejects population/dd_subtype/BKT/item_difficulty/unknown fields.
    ``enable_typed_wrong_answers`` gates the typed (non-multiple-choice) wrong-answer generators.
    """

    model_config = ConfigDict(frozen=True, extra="forbid")

    config_version: str
    parameter_source_status: str
    latency: LognormalLatencySpec
    enable_typed_wrong_answers: bool

    @field_validator("config_version", "parameter_source_status")
    @classmethod
    def _non_empty(cls, v: str) -> str:
        if not str(v).strip():
            raise ValueError("version / source-status strings must be non-empty")
        return v


# ======================================================================================
# Phase B2B.3 — bounded attempt-loop config, control-flow termination, opportunity result.
#
# Compact model (no lifecycle-event grammar): the opportunity is an ordered tuple of the frozen
# B2B.0 ``BAttemptEvent`` rows plus a derived ``BOpportunityResponseSummary`` and a non-duplicative
# control-flow ``termination_reason``. No hidden truth / population / dd_subtype / BKT / Component
# C/3. All scientific parameters are explicit and CALIBRATION_PENDING; no numeric defaults.
# ======================================================================================

B2B_ATTEMPT_LOOP_VERSION = "b2b3-1.0.0"
# Result-model schema version (independent of B2B_ATTEMPT_LOOP_VERSION, which versions the
# generator/orchestrator). Bumped b2b3-1.0.0 -> b2b3-1.1.0 in Phase B2B.3.1: added the required
# ``catalogue_checksum`` field to ``BOpportunityAttemptResult`` (SPEC correction 3 — hint/result
# provenance must be reconstructable via (item_template_id, hint_level, catalogue_version,
# catalogue_checksum), since the free-text catalogue_version alone is not guaranteed unique).
OPPORTUNITY_RESULT_SCHEMA_VERSION = "b2b3-1.1.0"
# Hard engineering safety limit on attempts per opportunity — an ENGINEERING_SAFETY_BOUND, NOT a
# clinical or empirically-calibrated value.
MAX_ATTEMPTS_SAFETY_BOUND = 10

# Control-flow-only termination reasons (deliberately NOT duplicating the summary's
# assisted/unassisted/completion fields).
TERMINATION_REASONS: Tuple[str, ...] = (
    "correct_response",
    "voluntary_exit",
    "max_attempts_exhausted",
    "timeout_terminated",
)
TerminationReason = Literal[
    "correct_response",
    "voluntary_exit",
    "max_attempts_exhausted",
    "timeout_terminated",
]


class BAttemptLoopConfig(BaseModel):
    """Strict, versioned Phase-B2B.3 bounded-attempt-loop configuration.

    Explicit parameters only; scientific values are CALIBRATION_PENDING (recorded via
    ``parameter_source_status``). Composes the B2B.2 first-attempt config for the per-attempt
    response kernel. Rejects population/dd_subtype/BKT/item_difficulty/unknown fields. There is no
    probabilistic-hint-presentation parameter (baseline presents deterministically) and no
    help-avoidance weight (that trait is deferred).
    """

    model_config = ConfigDict(frozen=True, extra="forbid")

    config_version: str
    parameter_source_status: str
    first_attempt_config: BFirstAttemptBehaviourConfig
    # 1 <= max_attempts <= MAX_ATTEMPTS_SAFETY_BOUND (ENGINEERING_SAFETY_BOUND).
    max_attempts: int = Field(ge=1, le=MAX_ATTEMPTS_SAFETY_BOUND)
    hint_request_base: float = Field(ge=0.0, le=1.0, allow_inf_nan=False)
    hint_request_weight: float = Field(ge=0.0, allow_inf_nan=False)
    retry_base: float = Field(ge=0.0, le=1.0, allow_inf_nan=False)
    retry_persistence_weight: float = Field(ge=0.0, allow_inf_nan=False)
    completion_persistence_weight: float = Field(ge=0.0, allow_inf_nan=False)
    timeout_terminates_opportunity: bool
    avoid_repeat_wrong_answers: bool
    ruleset_version: str

    @field_validator("config_version", "parameter_source_status", "ruleset_version")
    @classmethod
    def _non_empty(cls, v: str) -> str:
        if not str(v).strip():
            raise ValueError("version / source-status strings must be non-empty")
        return v


class BOpportunityAttemptResult(BaseModel):
    """The complete bounded opportunity: ordered attempt rows + derived summary + termination.

    ``summary`` is derived from ``attempts`` only (existing pure derivation). ``termination_reason``
    is control-flow provenance from the orchestrator and does not duplicate the summary. Carries no
    hidden truth / population / dd_subtype / BKT / Component C/3.
    """

    model_config = ConfigDict(frozen=True, extra="forbid")

    attempts: Tuple["BAttemptEvent", ...]
    summary: "BOpportunityResponseSummary"
    termination_reason: TerminationReason
    generator_version: str = B2B_ATTEMPT_LOOP_VERSION
    schema_version: str = OPPORTUNITY_RESULT_SCHEMA_VERSION
    config_version: str
    catalogue_version: str
    # Required (Phase B2B.3.1, SPEC correction 3): SHA-256 provenance from
    # ``catalogue.loader.catalogue_file_checksum`` — the free-text ``catalogue_version`` alone is
    # not guaranteed immutable/unique, so hint/result reconstruction requires both.
    catalogue_checksum: str
    seed_lineage: SeedLineage

    @field_validator("catalogue_checksum")
    @classmethod
    def _non_empty_checksum(cls, v: str) -> str:
        if not str(v).strip():
            raise ValueError("catalogue_checksum must be non-empty (SPEC correction 3)")
        return v

    @model_validator(mode="after")
    def _result_invariants(self) -> "BOpportunityAttemptResult":
        n = len(self.attempts)
        if n < 1:
            raise ValueError("an opportunity result must contain at least one attempt")
        if [a.attempt_index for a in self.attempts] != list(range(1, n + 1)):
            raise ValueError("attempts must be ordered with consecutive indices 1..n")
        if self.summary.total_attempts != n:
            raise ValueError("summary.total_attempts must equal the number of attempts")
        if self.summary.item_opportunity_id != self.attempts[0].item_opportunity_id:
            raise ValueError("summary must describe the same opportunity as its attempts")
        final = self.attempts[-1]
        # termination_reason must agree with the final attempt + derived completion.
        if self.termination_reason == "correct_response":
            if not (final.correct and self.summary.final_item_completed):
                raise ValueError("correct_response requires a correct, completed final attempt")
        else:  # any incomplete termination
            if final.correct or self.summary.final_item_completed:
                raise ValueError(f"{self.termination_reason} requires a non-completed opportunity")
            if self.termination_reason == "timeout_terminated" and \
                    final.supported_error_pattern != "timeout_no_response":
                raise ValueError("timeout_terminated requires the final attempt to be a timeout")
        return self
